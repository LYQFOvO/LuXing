import asyncio
import math
import unittest
from worker import Worker, usb_devices


class FakeDevice:
    def __init__(self):
        self.calls = []
        self.connected = False
        self.clear_error = False
        self.close_error = False
        self.set_error = False
        self.route_error = False
        self.sensor = True

    async def connect(self, udid):
        self.connected = True
        self.calls.append(("connect", udid))
        return {"name": "Test phone", "version": "27.0.1", "sensor": self.sensor}

    async def set(self, latitude, longitude):
        self.calls.append(("set", latitude, longitude))
        if self.set_error:
            raise RuntimeError("reply lost after coordinate write")

    async def hold(self, latitude, longitude):
        self.calls.append(("hold", latitude, longitude))

    async def route(self, waypoints, speed):
        self.calls.append(("route", len(waypoints), speed))
        if self.route_error:
            raise RuntimeError("Apple 定位仿真服务拒绝路线。")

    async def stop_route(self):
        self.calls.append(("stop_route",))

    async def clear(self):
        self.calls.append(("clear",))
        if self.clear_error:
            raise RuntimeError("USB disconnected")

    async def disconnect(self):
        self.connected = False
        self.calls.append(("disconnect",))
        if self.close_error:
            raise RuntimeError("session close failed")


class DeviceRecord:
    def __init__(self, kind):
        self.connection_type = kind
        self.serial = kind + "-id"


class WorkerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.device = FakeDevice()
        self.worker = Worker(self.device)

    async def request(self, action, **kwargs):
        return await self.worker.handle({"id": "t", "action": action, **kwargs})

    async def test_set_requires_connection(self):
        response = await self.request("set", latitude=1, longitude=2)
        self.assertFalse(response["ok"])
        self.assertEqual(self.device.calls, [])

    async def test_coordinates_are_validated_before_device_write(self):
        await self.request("connect", udid="test-id")
        for latitude, longitude in [(91, 0), (0, 181), (math.nan, 0), (0, math.inf)]:
            self.assertFalse((await self.request("set", latitude=latitude, longitude=longitude))["ok"])
        self.assertEqual(len(self.device.calls), 1)

    async def test_updates_share_persistent_session(self):
        await self.request("connect", udid="test-id")
        for lat in [1, 2, 3]:
            self.assertTrue((await self.request("set", latitude=lat, longitude=2))["ok"])
        self.assertEqual(sum(call[0] == "connect" for call in self.device.calls), 1)

    async def test_clear_failure_is_not_reported_as_restored(self):
        await self.request("connect", udid="test-id")
        self.device.clear_error = True
        response = await self.request("clear")
        self.assertFalse(response["ok"])
        self.assertIn("USB disconnected", response["error"])

    async def test_clear_releases_session_and_blocks_further_updates(self):
        await self.request("connect", udid="test-id")
        await self.request("set", latitude=1, longitude=2)
        response = await self.request("clear")
        self.assertTrue(response["ok"])
        self.assertEqual(self.device.calls[-2:], [("clear",), ("disconnect",)])
        self.assertFalse(self.worker.connected)
        self.assertTrue(response["result"]["session_closed"])
        self.assertFalse(response["result"]["verified"])
        self.assertFalse((await self.request("set", latitude=1, longitude=2))["ok"])

    async def test_lost_set_reply_keeps_restore_obligation(self):
        await self.request("connect", udid="test-id")
        self.device.set_error = True
        self.assertFalse((await self.request("set", latitude=1, longitude=2))["ok"])
        self.assertTrue(self.worker.simulated, "a coordinate may have reached the phone before its reply was lost")
        self.assertTrue((await self.request("shutdown"))["ok"])
        self.assertEqual(self.device.calls[-2:], [("clear",), ("disconnect",)])

    async def test_failed_close_is_not_reported_as_restored(self):
        await self.request("connect", udid="test-id")
        await self.request("set", latitude=1, longitude=2)
        self.device.close_error = True
        response = await self.request("clear")
        self.assertFalse(response["ok"])
        self.assertIn("session close failed", response["error"])
        self.assertFalse(self.worker.connected)
        self.assertTrue(self.worker.simulated)
        self.device.close_error = False
        await self.request("connect", udid="test-id")
        self.assertTrue((await self.request("shutdown"))["ok"])
        self.assertEqual(self.device.calls[-2:], [("clear",), ("disconnect",)])
        self.assertFalse(self.worker.simulated)

    async def test_failed_clear_closes_session_and_can_retry(self):
        await self.request("connect", udid="test-id")
        await self.request("set", latitude=1, longitude=2)
        self.device.clear_error = True
        self.assertFalse((await self.request("clear"))["ok"])
        self.assertTrue(self.worker.simulated)
        self.assertFalse(self.worker.connected)
        self.assertEqual(self.device.calls[-1], ("disconnect",))
        self.device.clear_error = False
        await self.request("connect", udid="test-id")
        self.assertTrue((await self.request("clear"))["ok"])
        self.assertFalse(self.worker.simulated)

    async def test_shutdown_clears_and_disconnects(self):
        await self.request("connect", udid="test-id")
        await self.request("set", latitude=1, longitude=2)
        response = await self.request("shutdown")
        self.assertTrue(response["ok"])
        self.assertEqual(self.device.calls[-2:], [("clear",), ("disconnect",)])

    async def test_reconnected_shutdown_honours_outstanding_restore(self):
        await self.request("connect", udid="test-id")
        response = await self.request("shutdown", restore=True)
        self.assertTrue(response["ok"])
        self.assertEqual(self.device.calls[-2:], [("clear",), ("disconnect",)])

    async def test_missing_udid_and_unknown_action_are_rejected(self):
        self.assertFalse((await self.request("connect"))["ok"])
        self.assertFalse((await self.request("nonsense"))["ok"])
        self.assertFalse((await self.worker.handle({}))["ok"])

    def test_only_usb_devices_are_selected(self):
        selected = usb_devices([DeviceRecord("USB"), DeviceRecord("Network")])
        self.assertEqual([d.serial for d in selected], ["USB-id"])

    async def test_route_requires_connection_and_valid_points(self):
        points = [{"latitude": 1, "longitude": 2}, {"latitude": 3, "longitude": 4}]
        self.assertFalse((await self.request("route", waypoints=points, speed=2.8))["ok"])
        await self.request("connect", udid="test-id")
        for speed in [0, -1, math.inf, 40]:
            self.assertFalse((await self.request("route", waypoints=points, speed=speed))["ok"])
        for bad in [[], [points[0]], "nonsense", [{"latitude": 91, "longitude": 0}, points[1]]]:
            self.assertFalse((await self.request("route", waypoints=bad, speed=2.8))["ok"])
        self.assertEqual(self.device.calls, [("connect", "test-id")])

    async def test_route_is_forwarded_with_its_speed(self):
        await self.request("connect", udid="test-id")
        points = [{"latitude": 1, "longitude": 2}, {"latitude": 3, "longitude": 4}]
        response = await self.request("route", waypoints=points, speed=2.7778)
        self.assertTrue(response["ok"])
        self.assertEqual(self.device.calls[-1], ("route", 2, 2.7778))
        self.assertEqual(response["result"]["points"], 2)
        self.assertTrue(self.worker.simulated, "a route is a simulated location and needs restoration")

    async def test_hold_pins_one_coordinate_through_the_sensor_service(self):
        await self.request("connect", udid="test-id")
        response = await self.request("hold", latitude=1, longitude=2)
        self.assertTrue(response["ok"])
        self.assertEqual(self.device.calls[-1], ("hold", 1.0, 2.0))
        self.assertFalse((await self.request("hold", latitude=91, longitude=2))["ok"])

    async def test_clear_stops_an_on_device_route(self):
        await self.request("connect", udid="test-id")
        await self.request("route", waypoints=[{"latitude": 1, "longitude": 2}, {"latitude": 3, "longitude": 4}], speed=2.8)
        self.assertTrue((await self.request("clear"))["ok"])
        self.assertEqual(self.device.calls[-3:], [("stop_route",), ("clear",), ("disconnect",)])

    async def test_route_failure_is_reported_and_keeps_restore(self):
        await self.request("connect", udid="test-id")
        self.device.route_error = True
        response = await self.request("route", waypoints=[{"latitude": 1, "longitude": 2}, {"latitude": 3, "longitude": 4}], speed=2.8)
        self.assertFalse(response["ok"])
        self.assertIn("拒绝路线", response["error"])
        self.assertTrue(self.worker.simulated)


if __name__ == "__main__":
    unittest.main()
