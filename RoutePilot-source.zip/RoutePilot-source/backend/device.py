"""USB-only iPhone adapter. Library imports are delayed until a device action.

Two location channels are used:

* ``LocationSimulation`` (DVT) writes one coordinate at a time. This is the
  original, always-available path.
* ``com.apple.coredevice.locationservice`` drives Apple's own simulation
  controller (the engine behind the Simulator's "City Run" scenario). It plays
  a whole waypoint route on the phone at a given speed, so the fixes are
  produced on-device at 1 Hz with a valid ``speed`` field instead of the
  ``speed = -1`` markers the single-coordinate channel produces.
"""
import asyncio
from contextlib import AsyncExitStack, suppress

LOCATION_FEATURE = "com.apple.coredevice.feature.simulatelocation"
START_ROUTE_ACTION = "com.apple.coredevice.action.startlocationsimulation"
HOLD_ACTION = "com.apple.coredevice.action.setsimulatedlocation"
CLEAR_ACTION = "com.apple.coredevice.action.clearsimulatedlocation"


class IPhoneDevice:
    def __init__(self):
        self.stack = None
        self.location = None
        self.sensor = None
        self.rsd = None
        self.sensor_detail = ""

    async def devices(self):
        from pymobiledevice3.usbmux import list_devices
        from pymobiledevice3.lockdown import create_using_usbmux
        from worker import usb_devices
        result = []
        for record in usb_devices(await list_devices()):
            entry = {"udid": record.serial, "name": "iPhone（请解锁并信任）", "version": "", "trusted": False}
            try:
                lockdown = await asyncio.wait_for(create_using_usbmux(serial=record.serial, connection_type="USB", autopair=False), 5)
                try:
                    entry.update(name=lockdown.all_values.get("DeviceName", "iPhone"),
                                 version=lockdown.product_version, trusted=True)
                finally:
                    await lockdown.close()
            except Exception as error:
                entry["detail"] = str(error) or type(error).__name__
            result.append(entry)
        return result

    async def _open_usb(self, udid):
        from pymobiledevice3.lockdown import create_using_usbmux
        lockdown = await create_using_usbmux(serial=udid, connection_type="USB", pair_timeout=20)
        try:
            if not await lockdown.get_developer_mode_status():
                raise RuntimeError("请在 iPhone 的“设置 → 隐私与安全性 → 开发者模式”中开启，按提示重启并确认，然后重新连接。")
            parts = lockdown.product_version.split(".")
            version = tuple(int(part) for part in parts[:2])
            if version < (17, 4):
                raise RuntimeError("此版本面向 iOS 17.4 及以上 USB 连接，请使用对应系统的其他连接方案。")
            info = {"name": lockdown.all_values.get("DeviceName", "iPhone"), "version": lockdown.product_version}
            return lockdown, info
        except BaseException:
            await lockdown.close()
            raise

    async def prepare(self, udid):
        from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
        from pymobiledevice3.services.mobile_image_mounter import auto_mount_personalized
        from pymobiledevice3.exceptions import AlreadyMountedError
        async with AsyncExitStack() as stack:
            lockdown, info = await self._open_usb(udid)
            stack.push_async_callback(lockdown.close)
            rsd = await stack.enter_async_context(UserspaceRsdTunnel(serial=udid, remotepairing_fallback=False))
            try:
                await auto_mount_personalized(rsd)
            except AlreadyMountedError:
                pass
            return {**info, "prepared": True}

    async def _open_sensor(self, rsd):
        """Open Apple's own location-simulation service; None when unavailable."""
        try:
            from pymobiledevice3.remote.core_device.location_service import LocationService
            service = LocationService(rsd)
            await asyncio.wait_for(service.connect(), 20)
            self.sensor_detail = ""
            return service
        except Exception as error:  # noqa: BLE001 - optional channel
            self.sensor_detail = str(error) or type(error).__name__
            return None

    async def connect(self, udid):
        from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
        from pymobiledevice3.services.dvt.instruments.dvt_provider import DvtProvider
        from pymobiledevice3.services.dvt.instruments.location_simulation import LocationSimulation
        if self.stack is not None:
            raise RuntimeError("设备会话已连接。")
        stack = AsyncExitStack()
        try:
            lockdown, info = await self._open_usb(udid)
            stack.push_async_callback(lockdown.close)
            rsd = await stack.enter_async_context(UserspaceRsdTunnel(serial=udid, remotepairing_fallback=False))
            dvt = await stack.enter_async_context(DvtProvider(rsd))
            location = await stack.enter_async_context(LocationSimulation(dvt))
        except BaseException:
            await stack.aclose()
            raise
        self.stack, self.location, self.rsd = stack, location, rsd
        self.sensor = await self._open_sensor(rsd)
        return {**info, "sensor": self.sensor is not None, "sensor_detail": self.sensor_detail}

    async def set(self, latitude, longitude):
        if self.location is None:
            raise RuntimeError("定位会话未连接。")
        await asyncio.wait_for(self.location.set(latitude, longitude), 8)

    def _require_sensor(self):
        if self.sensor is None:
            raise RuntimeError("这台 iPhone 没有提供 Apple 定位仿真服务，请先“准备设备”并确认开发者组件已挂载。")
        return self.sensor

    async def hold(self, latitude, longitude):
        """Pin the phone to one coordinate through Apple's simulation service."""
        service = self._require_sensor()
        await asyncio.wait_for(service.invoke(
            LOCATION_FEATURE,
            {"latitude": latitude, "longitude": longitude},
            action_identifier=HOLD_ACTION), 12)

    async def route(self, waypoints, speed):
        """Play a waypoint route on the phone at ``speed`` metres per second."""
        service = self._require_sensor()
        payload = {"waypoints": waypoints, "pacing": {"distance": {"_0": speed}}, "speed": speed}
        await asyncio.wait_for(service.invoke(
            LOCATION_FEATURE, payload, action_identifier=START_ROUTE_ACTION), 25)

    async def stop_route(self):
        if self.sensor is None:
            return
        await asyncio.wait_for(self.sensor.invoke(LOCATION_FEATURE, {}, action_identifier=CLEAR_ACTION), 10)

    async def clear(self):
        if self.location is None:
            raise RuntimeError("定位会话未连接，无法确认恢复。")
        await asyncio.wait_for(self.location.clear(), 8)

    async def disconnect(self):
        stack, self.stack = self.stack, None
        self.location = None
        self.rsd = None
        sensor, self.sensor = self.sensor, None
        if sensor is not None:
            with suppress(Exception):
                await asyncio.wait_for(sensor.close(), 10)
        if stack is not None:
            await asyncio.wait_for(stack.aclose(), 10)
