"""Private, serialized JSON Lines protocol over stdin/stdout; no HTTP server."""
import asyncio
import contextlib
import json
import logging
import math
import sys


MAX_REQUEST_BYTES = 4 * 1024 * 1024
MAX_ROUTE_POINTS = 6000


def usb_devices(records):
    return [record for record in records if record.connection_type == "USB"]


def finite(value, limit):
    number = float(value)
    if not math.isfinite(number) or abs(number) > limit:
        raise ValueError("定位坐标无效，要求 WGS-84 纬度 ±90、经度 ±180。")
    return number


def route_points(records):
    """Validate the waypoint list sent to Apple's on-device simulation."""
    if not isinstance(records, list) or not 2 <= len(records) <= MAX_ROUTE_POINTS:
        raise ValueError(f"路径点数量无效，需要 2 至 {MAX_ROUTE_POINTS} 个点。")
    points = []
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("路径点格式无效。")
        points.append({"latitude": finite(record["latitude"], 90), "longitude": finite(record["longitude"], 180)})
    return points


class Worker:
    def __init__(self, device):
        self.device = device
        self.connected = False
        self.simulated = False
        self.udid = None

    async def handle(self, request):
        request_id = request.get("id") if isinstance(request, dict) else None
        try:
            if not isinstance(request, dict) or not isinstance(request_id, str):
                raise ValueError("请求必须包含字符串 id。")
            action = request.get("action")
            if action == "hello":
                result = {"protocol": 1, "backend": "pymobiledevice3", "version": "11.26.0"}
            elif action == "devices":
                result = await self.device.devices()
            elif action in ("prepare", "connect"):
                udid = request.get("udid")
                if not isinstance(udid, str) or not udid.strip():
                    raise ValueError("请先选择通过 USB 连接的 iPhone。")
                if self.connected:
                    raise ValueError("设备已经连接，请先恢复定位并断开后重试。")
                if action == "prepare":
                    result = await self.device.prepare(udid)
                else:
                    result = await self.device.connect(udid)
                    self.connected = True
                    self.udid = udid
            elif action == "set":
                if not self.connected:
                    raise ValueError("设备尚未连接，请先连接 iPhone。")
                latitude = finite(request["latitude"], 90)
                longitude = finite(request["longitude"], 180)
                # A reply failure cannot prove the location was never applied.
                self.simulated = True
                await self.device.set(latitude, longitude)
                result = {"latitude": latitude, "longitude": longitude}
            elif action == "hold":
                if not self.connected:
                    raise ValueError("设备尚未连接，请先连接 iPhone。")
                latitude = finite(request["latitude"], 90)
                longitude = finite(request["longitude"], 180)
                self.simulated = True
                await self.device.hold(latitude, longitude)
                result = {"latitude": latitude, "longitude": longitude, "sensor": True}
            elif action == "route":
                if not self.connected:
                    raise ValueError("设备尚未连接，请先连接 iPhone。")
                speed = float(request["speed"])
                if not math.isfinite(speed) or speed <= 0 or speed > 30:
                    raise ValueError("仿真速度无效，要求 0 至 30 米每秒。")
                points = route_points(request.get("waypoints"))
                self.simulated = True
                await self.device.route(points, speed)
                result = {"points": len(points), "speed": speed, "sensor": True}
            elif action == "route_stop":
                if not self.connected:
                    raise ValueError("设备未连接，无法停止路线仿真。")
                await self.device.stop_route()
                result = {"stopped": True}
            elif action == "clear":
                if not self.connected:
                    raise ValueError("设备未连接，无法确认真实定位是否恢复。")
                try:
                    # An on-device route is part of the session being restored;
                    # a failed stop must not skip the coordinate clear below.
                    with contextlib.suppress(Exception):
                        await self.device.stop_route()
                    await self.device.clear()
                finally:
                    # Ending the developer session is part of restoration, not just
                    # transport cleanup. Even a failed clear must release its owner.
                    try:
                        await self.device.disconnect()
                    finally:
                        self.connected = False
                self.simulated = False
                result = {"restore_sent": True, "session_closed": True, "verified": False}
            elif action in ("disconnect", "shutdown"):
                restore_requested = request.get("restore") is True
                if (restore_requested or self.simulated) and not self.connected:
                    raise ValueError("设备未连接，无法确认真实定位是否恢复。")
                try:
                    if self.connected and (self.simulated or restore_requested):
                        with contextlib.suppress(Exception):
                            await self.device.stop_route()
                        await self.device.clear()
                finally:
                    try:
                        await self.device.disconnect()
                    finally:
                        self.connected = False
                        self.udid = None
                self.simulated = False
                result = {"restore_sent": not self.simulated, "verified": False}
            else:
                raise ValueError("不支持的操作。")
            return {"id": request_id, "ok": True, "result": result}
        except Exception as error:
            message = str(error) or type(error).__name__
            return {"id": request_id, "ok": False, "error": message}


async def serve():
    # Dependencies occasionally print status text. Reserve stdout for protocol bytes.
    protocol_output = sys.stdout
    sys.stdout = sys.stderr
    from device import IPhoneDevice
    worker = Worker(IPhoneDevice())
    try:
        while True:
            line = await asyncio.to_thread(sys.stdin.buffer.readline, MAX_REQUEST_BYTES + 1)
            if not line:
                break
            try:
                if len(line) > MAX_REQUEST_BYTES:
                    raise ValueError("请求过大。")
                request = json.loads(line)
                response = await worker.handle(request)
            except Exception as error:
                request = {}
                response = {"id": None, "ok": False, "error": str(error)}
            protocol_output.write(json.dumps(response, ensure_ascii=False, allow_nan=False) + "\n")
            protocol_output.flush()
            if isinstance(request, dict) and request.get("action") == "shutdown":
                break
    finally:
        with contextlib.suppress(Exception):
            await asyncio.wait_for(worker.handle({"id": "cleanup", "action": "shutdown"}), 10)


def main():
    logging.basicConfig(level=logging.WARNING, stream=sys.stderr)
    if len(sys.argv) > 1 and sys.argv[1] == "--pmd-cli":
        sys.argv = [sys.argv[0], *sys.argv[2:]]
        from pymobiledevice3.__main__ import main as pmd_main
        pmd_main()
    else:
        asyncio.run(serve())


if __name__ == "__main__":
    main()
