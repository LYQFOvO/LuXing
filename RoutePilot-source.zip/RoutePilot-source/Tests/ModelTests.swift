import Foundation
import RouteCore
import MapKit

@main struct ModelTests {
    @MainActor static func main() async throws {
        setenv("ROUTEPILOT_WORKER", CommandLine.arguments[1], 1)
        setenv("ROUTEPILOT_TEST_LOG", CommandLine.arguments[2], 1)
        let logURL = URL(fileURLWithPath: CommandLine.arguments[2])
        try? FileManager.default.removeItem(at: logURL)
        func events() throws -> [[String: Any]] {
            let content = try String(contentsOf: logURL, encoding: .utf8)
            return try content.split(separator: "\n").map { line in
                try JSONSerialization.jsonObject(with: Data(line.utf8)) as! [String: Any]
            }
        }
        let rawSDKPoint = GeoPoint(latitude: 31.2419577, longitude: 121.4951742)
        let coordinateModel = AppModel()
        precondition(coordinateModel.gpsPoint(rawSDKPoint) == rawSDKPoint,
                     "MapKit GPS coordinates must not be inversely transformed a second time")
        print("PASS: system map selection retains the SDK GPS coordinate")
        for layer in MapLayer.allCases {
            coordinateModel.mapLayer = layer
            coordinateModel.mapCenterCoordinate = rawSDKPoint
            precondition(coordinateModel.mapCenterPoint == rawSDKPoint && coordinateModel.mapPoint(rawSDKPoint) == rawSDKPoint,
                         "changing map imagery must never change GPS coordinates")
        }
        print("PASS: all map layers and crosshair preserve GPS coordinates")
        let mapItem = MKMapItem(placemark: MKPlacemark(coordinate: rawSDKPoint.coordinate))
        coordinateModel.selectSearchResult(mapItem)
        precondition(coordinateModel.waypoints[0].point == rawSDKPoint, "search coordinates must not be converted twice")
        print("PASS: search result retains SDK coordinates")
        let secondSDKPoint = GeoPoint(latitude: 31.2423, longitude: 121.4955)
        let rawPoints = [rawSDKPoint, secondSDKPoint]
        let oldPoints = rawPoints.map(MapCoordinates.toWGS84)
        let oldWaypoints = oldPoints.enumerated().map { Waypoint(name: "Old \($0.offset)", point: $0.element) }
        let legacy = SavedRoute(schema: 1, waypoints: oldWaypoints, path: oldPoints, mode: .loop, distanceKM: 1, paceMinutes: 6)
        try coordinateModel.loadSavedRoute(legacy, repairLegacyMapPoints: true)
        precondition(zip(coordinateModel.waypoints.map(\.point), rawPoints).allSatisfy { $0.distance(to: $1) < 0.01 }, "legacy repair must retain old map selections")
        precondition(zip(coordinateModel.walkingPath, rawPoints).allSatisfy { $0.distance(to: $1) < 0.01 }, "legacy walking path must be repaired too")
        precondition(coordinateModel.waypoints.map(\.id) == oldWaypoints.map(\.id), "migration preserves waypoint identity")
        print("PASS: legacy repair restores waypoint and walking-path map positions")
        let current = SavedRoute(waypoints: coordinateModel.waypoints, path: coordinateModel.walkingPath, mode: .loop, distanceKM: 1, paceMinutes: 6)
        let reopened = try JSONDecoder().decode(SavedRoute.self, from: JSONEncoder().encode(current))
        try coordinateModel.loadSavedRoute(reopened, repairLegacyMapPoints: true)
        precondition(reopened.schema == 4 && coordinateModel.waypoints == current.waypoints && coordinateModel.walkingPath == current.path, "new files must not be repaired twice")
        print("PASS: saved corrected route reloads without a second conversion")
        try coordinateModel.loadSavedRoute(legacy, repairLegacyMapPoints: false)
        precondition(coordinateModel.waypoints == oldWaypoints && coordinateModel.walkingPath == oldPoints, "legacy GPS file must be retained when correction was off")
        print("PASS: legacy GPS coordinates are preserved when requested")
        var invalid = legacy
        invalid.schema = 99
        do {
            try coordinateModel.loadSavedRoute(invalid, repairLegacyMapPoints: true)
            preconditionFailure("unsupported schema accepted")
        } catch {
            precondition(coordinateModel.waypoints == oldWaypoints, "failed import must preserve current route")
        }
        print("PASS: invalid import preserves current route")
        setenv("ROUTEPILOT_TEST_SET_DELAYS", "[0.01]", 1)
        func completedUSBRun() async throws -> AppModel {
            let run = AppModel()
            run.selectedUDID = "test-usb"
            run.sensorMode = false
            run.parameterMode = 0
            run.waypoints = rawPoints.map { Waypoint(name: "Restart point", point: $0) }
            run.distanceKM = 0.001
            await run.connectDevice()
            await run.prepareStartPoint()
            run.start()
            precondition(!run.canPrepareStartPoint, "running playback must disable preparation")
            for _ in 0..<40 {
                if run.state == .finished { break }
                try await Task.sleep(nanoseconds: 100_000_000)
            }
            precondition(run.state == .finished && run.needsRestore, "short USB run must finish while retaining restoration")
            return run
        }
        let repeatRun = try await completedUSBRun()
        precondition(repeatRun.canPrepareStartPoint, "completed movement must allow another preparation without a manual stop")
        let beforeRepeat = try events().count
        await repeatRun.prepareStartPoint()
        let repeatActions = try events().dropFirst(beforeRepeat)
        precondition(repeatActions.compactMap { $0["action"] as? String } == ["clear", "connect", "set"],
                     "restarting must clear the previous session before reconnecting and preparing")
        precondition(repeatActions.first { $0["action"] as? String == "connect" }?["udid"] as? String == "test-usb",
                     "restart must reconnect the same selected phone")
        precondition(repeatRun.state == .idle && repeatRun.startPointReady && repeatRun.canStart && repeatRun.needsRestore,
                     "completed run must return to a ready stationary start")
        precondition(repeatRun.currentPoint == rawSDKPoint && repeatRun.confirmedElapsed == 0 && repeatRun.travelledMetres == 0 && repeatRun.estimatedSteps == 0,
                     "restart preparation must reset previous movement totals")
        print("PASS: completed USB run can prepare again on the same phone with reset totals")
        await repeatRun.stop()
        precondition(repeatRun.canPrepareStartPoint && !repeatRun.deviceConnected, "restored idle run must allow preparation to reconnect automatically")
        let beforeStoppedRepeat = try events().count
        await repeatRun.prepareStartPoint()
        let stoppedRepeatActions = try events().dropFirst(beforeStoppedRepeat).compactMap { $0["action"] as? String }
        precondition(stoppedRepeatActions == ["connect", "set"],
                     "restored idle preparation must reconnect without a redundant clear")
        precondition(repeatRun.startPointReady && repeatRun.canStart, "restored run must be ready after automatic reconnection")
        print("PASS: after stopping and restoring, preparation automatically reconnects")
        await repeatRun.stop()
        try await repeatRun.shutdown()
        setenv("ROUTEPILOT_TEST_FAIL_REQUESTS", "{\"clear\":[1]}", 1)
        let failedClearRun = try await completedUSBRun()
        let beforeFailedClear = try events().count
        await failedClearRun.prepareStartPoint()
        precondition(failedClearRun.needsRestore && !failedClearRun.startPointReady && !failedClearRun.canStart,
                     "failed clear must preserve restoration and prevent a new run")
        let failedClearActions = try events().dropFirst(beforeFailedClear).compactMap { $0["action"] as? String }
        precondition(failedClearActions == ["clear"],
                     "failed clear must not send a new starting position")
        print("PASS: failed cleanup prevents restart and retains restoration")
        unsetenv("ROUTEPILOT_TEST_FAIL_REQUESTS")
        await failedClearRun.stop(forceRestore: true)
        try await failedClearRun.shutdown()
        let failedReconnectRun = try await completedUSBRun()
        setenv("ROUTEPILOT_TEST_FAIL_REQUESTS", "{\"connect\":[1]}", 1)
        await failedReconnectRun.prepareStartPoint()
        precondition(!failedReconnectRun.needsRestore && !failedReconnectRun.deviceConnected && !failedReconnectRun.startPointReady,
                     "a reconnect failure after successful clear must not claim a new simulation")
        precondition(failedReconnectRun.canPrepareStartPoint, "reconnect failure must allow another preparation attempt")
        unsetenv("ROUTEPILOT_TEST_FAIL_REQUESTS")
        await failedReconnectRun.prepareStartPoint()
        precondition(failedReconnectRun.state == .idle && failedReconnectRun.canStart, "retry must prepare without manual state reset")
        print("PASS: failed reconnect after cleanup can retry preparation")
        await failedReconnectRun.stop()
        try await failedReconnectRun.shutdown()
        unsetenv("ROUTEPILOT_TEST_FAIL_REQUESTS")
        setenv("ROUTEPILOT_TEST_FAIL_REQUESTS", "{\"set\":[1]}", 1)
        let failedSetRun = AppModel()
        failedSetRun.selectedUDID = "test-usb"
        failedSetRun.sensorMode = false
        failedSetRun.parameterMode = 0
        failedSetRun.waypoints = repeatRun.waypoints
        failedSetRun.previewOnly = false
        await failedSetRun.prepareStartPoint()
        precondition(failedSetRun.needsRestore && !failedSetRun.canStart, "uncertain start set must retain restoration")
        unsetenv("ROUTEPILOT_TEST_FAIL_REQUESTS")
        await failedSetRun.prepareStartPoint()
        precondition(failedSetRun.canStart && failedSetRun.startPointReady, "uncertain set can recover through clear and reconnect")
        print("PASS: failed start-point delivery can recover without abandoning restoration")
        await failedSetRun.stop()
        try await failedSetRun.shutdown()
        unsetenv("ROUTEPILOT_TEST_FAIL_REQUESTS")
        unsetenv("ROUTEPILOT_TEST_SET_DELAYS")
        let model = AppModel()
        let validationModel = AppModel()
        let original = GeoPoint(latitude: 31.230416, longitude: 121.473701)
        validationModel.addPoint(original)
        validationModel.walkingPath = [original, .init(latitude: 31.231, longitude: 121.474)]
        let savedPath = validationModel.walkingPath
        validationModel.updatePoint(id: validationModel.waypoints[0].id, point: .init(latitude: 91, longitude: 121))
        precondition(validationModel.waypoints[0].point == original && validationModel.walkingPath == savedPath, "invalid precision edit must preserve point and route")
        print("PASS: invalid precision edit preserves waypoint and walking route")
        let precisePoint = GeoPoint(latitude: 31.230417, longitude: 121.473702)
        validationModel.updatePoint(id: validationModel.waypoints[0].id, point: precisePoint)
        precondition(validationModel.waypoints[0].point == precisePoint && validationModel.walkingPath.isEmpty, "precision edit must preserve fractional coordinates and invalidate walking route")
        print("PASS: precision edit retains coordinates and clears stale walking route")
        validationModel.state = .running
        validationModel.updatePoint(id: validationModel.waypoints[0].id, point: original)
        precondition(validationModel.waypoints[0].point == precisePoint, "playback must lock precision editing")
        print("PASS: playback locks precision editing")
        model.selectedUDID = "test-usb"
        model.sensorMode = false
        await model.connectDevice()
        precondition(model.deviceConnected, "test transport connection")
        model.waypoints = rawPoints.map { Waypoint(name: "Map point", point: model.gpsPoint($0)) }
        precondition(!model.canStart, "USB movement must require a separately prepared starting point")
        await model.prepareStartPoint()
        precondition(model.startPointReady && model.canStart && !model.editable && model.needsRestore,
                     "prepared starting point must enable movement, lock edits and retain restoration")
        precondition(model.currentPoint == rawSDKPoint && model.confirmedElapsed == 0 && model.travelledMetres == 0 && model.estimatedSteps == 0,
                     "preparing a starting point must not count as movement")
        print("PASS: USB movement requires a separately prepared stationary starting point")
        model.start()
        for _ in 0..<3 {
            try await Task.sleep(nanoseconds: 100_000_000)
            model.pause()
            model.resume()
        }
        try await Task.sleep(nanoseconds: 1_000_000_000)
        let firstSet = try events().first { $0["action"] as? String == "set" }!
        precondition(firstSet["latitude"] as? Double == rawSDKPoint.latitude && firstSet["longitude"] as? Double == rawSDKPoint.longitude, "USB must receive the original SDK coordinate")
        print("PASS: USB request uses the original system map coordinate")
        let startingSets = try events().filter { $0["action"] as? String == "set" }.prefix(2)
        precondition(startingSets.count == 2 && startingSets.allSatisfy {
            $0["latitude"] as? Double == rawSDKPoint.latitude && $0["longitude"] as? Double == rawSDKPoint.longitude
        }, "starting movement must repeat the prepared point without a new displacement")
        print("PASS: movement starts from the prepared coordinate without an extra jump")
        let overlap = try events().contains { ($0["active_sets"] as? Int ?? 0) > 1 }
        precondition(!overlap, "pause/resume must never queue overlapping set requests")
        print("PASS: pause/resume has one in-flight position update")
        model.deviceConnected = false
        await model.stop()
        precondition(model.needsRestore, "failed stop must preserve recovery obligation")
        await model.connectDevice()
        let setsBeforeRecovery = try events().filter { $0["action"] as? String == "set" }.count
        model.resume()
        try await Task.sleep(nanoseconds: 1_000_000_000)
        let setsAfterRecovery = try events().filter { $0["action"] as? String == "set" }.count
        precondition(setsAfterRecovery > setsBeforeRecovery, "reconnect/resume must restart after failed stop")
        print("PASS: failed-stop recovery can resume the route")
        await model.stop()
        precondition(model.state == .idle && !model.needsRestore && !model.deviceConnected, "stop must clear and release the simulated session")
        precondition(!model.startPointReady, "restoration must invalidate the prepared starting point")
        print("PASS: stop sends clear before returning to edit mode")
        let previousSets = try events().filter { $0["action"] as? String == "set" }.count
        model.previewOnly = true
        model.start()
        try await Task.sleep(nanoseconds: 1_200_000_000)
        await model.stop()
        let previewSets = try events().filter { $0["action"] as? String == "set" }.count
        precondition(previousSets == previewSets, "preview must never send a device position")
        print("PASS: preview never changes device location")
        let motionModel = AppModel()
        let humanSettings = MotionSettings(cadence: 172, humanVariation: true, paceVariationSeconds: 15, cadenceVariation: 7)
        let savedHuman = SavedRoute(waypoints: model.waypoints, path: [], mode: .loop, distanceKM: 5, paceMinutes: 6, motion: humanSettings)
        let decodedHuman = try JSONDecoder().decode(SavedRoute.self, from: JSONEncoder().encode(savedHuman))
        try motionModel.loadSavedRoute(decodedHuman, repairLegacyMapPoints: false)
        precondition(motionModel.motionSettings == humanSettings && decodedHuman.schema == 4, "save/reload must retain cadence and variation settings")
        print("PASS: cadence and variation settings survive route save/reload")
        let oldJSON = "{\"schema\":2,\"waypoints\":[],\"path\":[],\"mode\":\"loop\",\"distanceKM\":5,\"paceMinutes\":6}"
        var oldRoute = try JSONDecoder().decode(SavedRoute.self, from: Data(oldJSON.utf8))
        oldRoute.waypoints = model.waypoints
        try motionModel.loadSavedRoute(oldRoute, repairLegacyMapPoints: false)
        precondition(motionModel.motionSettings == MotionSettings(), "old files default to constant pace and cadence")
        print("PASS: older routes open with constant motion settings")
        var badHuman = savedHuman
        badHuman.motion!.cadenceVariation = 200
        do {
            try motionModel.loadSavedRoute(badHuman, repairLegacyMapPoints: false)
            preconditionFailure("invalid cadence range accepted")
        } catch {
            precondition(motionModel.motionSettings == MotionSettings(), "invalid motion settings must not replace current route")
        }
        print("PASS: invalid saved motion settings preserve the current route")
        motionModel.motionSettings = humanSettings
        motionModel.previewOnly = true
        motionModel.start()
        try await Task.sleep(nanoseconds: 1_200_000_000)
        precondition(abs(motionModel.livePaceMinutes - 6) > 0.000001 && motionModel.estimatedSteps > 0, "playback must apply the actual motion profile")
        let confirmedMotion = (motionModel.confirmedElapsed, motionModel.estimatedSteps, motionModel.travelledMetres)
        motionModel.pause()
        try await Task.sleep(nanoseconds: 1_200_000_000)
        precondition(motionModel.confirmedElapsed == confirmedMotion.0 && motionModel.estimatedSteps == confirmedMotion.1 && motionModel.travelledMetres == confirmedMotion.2, "paused motion and steps must not advance")
        print("PASS: human motion changes playback pace and freezes steps on pause")
        await motionModel.stop()
        try await motionModel.shutdown()
        let fractionalPlan = try MotionPlan(distanceKM: 1.001, paceMinutes: 6)
        let fractionalProfile = try MotionProfile(plan: fractionalPlan, settings: humanSettings, seed: 1)
        let gpxStart = Date(timeIntervalSince1970: 1_800_000_000)
        let gpx = AppModel.gpxDocument(route: motionModel.route!, plan: fractionalPlan, profile: fractionalProfile, start: gpxStart)
        let dateParser = ISO8601DateFormatter()
        dateParser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let times = gpx.components(separatedBy: "<time>").dropFirst().compactMap { dateParser.date(from: $0.components(separatedBy: "</time>")[0]) }
        precondition(times.count == 362 && zip(times, times.dropFirst()).allSatisfy { $1 > $0 }, "GPX timestamps must retain fractional seconds and increase strictly")
        precondition(abs(times.last!.timeIntervalSince(gpxStart) - fractionalPlan.durationSeconds) < 0.001, "GPX must preserve noninteger total duration")
        precondition(gpx.contains("<rp:cadence") && gpx.contains("<rp:steps>"), "GPX must include simulated motion extensions")
        print("PASS: GPX preserves fractional duration and simulated motion extensions")
        let retryModel = AppModel()
        retryModel.selectedUDID = "test-usb"
        await retryModel.stop(forceRestore: true)
        precondition(retryModel.restoreSent && !retryModel.deviceConnected && !retryModel.needsRestore,
                     "restore without a current session must connect, clear and disconnect")
        let actionsBeforeRetry = try events().count
        await retryModel.stop(forceRestore: true)
        let retryActions = try events().dropFirst(actionsBeforeRetry).compactMap { $0["action"] as? String }
        precondition(retryActions == ["connect", "clear"], "retry must create a fresh session and clear again")
        print("PASS: restoration can be retried from idle without previous simulation")
        try await retryModel.shutdown()
        try await model.shutdown()
        setenv("ROUTEPILOT_TEST_SET_DELAYS", "[0.01,0.01,2,0.01,0.01]", 1)
        let delayedModel = AppModel()
        delayedModel.selectedUDID = "test-usb"
        delayedModel.sensorMode = false
        delayedModel.waypoints = rawPoints.map { Waypoint(name: "Latency point", point: $0) }
        await delayedModel.connectDevice()
        await delayedModel.prepareStartPoint()
        let priorEvents = try events().count
        delayedModel.start()
        for _ in 0..<80 {
            if try events().dropFirst(priorEvents).filter({ $0["action"] as? String == "set" }).count >= 4 { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        delayedModel.pause()
        let deliveries = try events().dropFirst(priorEvents).filter { $0["action"] as? String == "set" }
        precondition(deliveries.count >= 4, "latency test must observe four coordinate deliveries")
        let requestedSpeed = delayedModel.plan!.speedMetresPerSecond
        for (previous, next) in zip(deliveries, deliveries.dropFirst()) {
            let a = GeoPoint(latitude: previous["latitude"] as! Double, longitude: previous["longitude"] as! Double)
            let b = GeoPoint(latitude: next["latitude"] as! Double, longitude: next["longitude"] as! Double)
            let actualSeconds = (next["applied_at"] as! Double) - (previous["applied_at"] as! Double)
            let deliveredSpeed = a.distance(to: b) / actualSeconds
            print("Delivery speed: \(deliveredSpeed) m/s; requested \(requestedSpeed) m/s")
            precondition(deliveredSpeed <= requestedSpeed * 1.03, "variable USB latency must not turn waiting time into a speed spike")
        }
        await delayedModel.stop()
        try await delayedModel.shutdown()
        unsetenv("ROUTEPILOT_TEST_SET_DELAYS")
        print("PASS: variable USB latency does not cause coordinate speed spikes")

        // Apple's on-device location simulation ("City Run" engine).
        setenv("ROUTEPILOT_TEST_SET_DELAYS", "[0.01]", 1)
        let sensorModel = AppModel()
        sensorModel.selectedUDID = "test-usb"
        sensorModel.waypoints = rawPoints.map { Waypoint(name: "Sensor point", point: $0) }
        sensorModel.parameterMode = 0
        sensorModel.distanceKM = 0.005
        await sensorModel.connectDevice()
        precondition(sensorModel.sensorAvailable, "the test transport must advertise Apple's simulation service")
        let beforeSensorPrepare = try events().count
        await sensorModel.prepareStartPoint()
        let prepareActions = try events().dropFirst(beforeSensorPrepare).compactMap { $0["action"] as? String }
        precondition(prepareActions == ["hold"], "sensor mode must pin the start point through Apple's service")
        precondition(sensorModel.startPointReady && sensorModel.canStart, "a pinned start point must allow movement")
        print("PASS: sensor mode pins the starting point on the phone without per-second coordinates")
        let beforeSensorStart = try events().count
        sensorModel.start()
        precondition(sensorModel.sensorRun, "sensor mode must drive the on-device route")
        for _ in 0..<50 {
            if try events().dropFirst(beforeSensorStart).contains(where: { $0["action"] as? String == "route" }) { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        let startEvents = try events().dropFirst(beforeSensorStart)
        let routeEvent = startEvents.first { $0["action"] as? String == "route" }!
        precondition(abs((routeEvent["speed"] as! Double) - 1000 / (sensorModel.paceMinutes * 60)) < 0.001,
                     "the phone must be told the planned speed")
        precondition((routeEvent["points"] as! Int) > 1, "the phone must receive the whole waypoint route")
        precondition(startEvents.allSatisfy { ($0["action"] as? String) != "set" },
                     "sensor mode must not fall back to one coordinate per second")
        print("PASS: sensor mode hands the whole route to the phone at the planned speed")
        for _ in 0..<80 {
            if sensorModel.state == .finished { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        precondition(sensorModel.state == .finished && sensorModel.needsRestore,
                     "a sensor run must finish and keep its restoration obligation")
        precondition(abs(sensorModel.travelledMetres - 5) < 0.05, "a sensor run must account the planned distance")
        print("PASS: sensor run advances the planned distance without USB round trips")
        await sensorModel.stop()
        precondition(sensorModel.state == .idle && !sensorModel.needsRestore && !sensorModel.sensorRun,
                     "stopping a sensor run must clear the simulated location")
        print("PASS: sensor run stop clears the on-device simulation")
        await sensorModel.prepareStartPoint()
        let beforeSensorPause = try events().count
        sensorModel.start()
        for _ in 0..<30 {
            if sensorModel.state == .running && !sensorModel.locationBusy { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        try await Task.sleep(nanoseconds: 600_000_000)
        sensorModel.pause()
        for _ in 0..<30 {
            if !sensorModel.locationBusy { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        let pauseActions = try events().dropFirst(beforeSensorPause).compactMap { $0["action"] as? String }
        precondition(pauseActions.contains("hold"),
                     "pausing a sensor run must pin the phone instead of releasing the simulation")
        precondition(!pauseActions.contains("clear"),
                     "pausing must not clear the simulated location back to real GPS")
        let pausedMetres = sensorModel.travelledMetres
        try await Task.sleep(nanoseconds: 700_000_000)
        precondition(sensorModel.travelledMetres == pausedMetres, "a paused sensor run must freeze distance")
        let beforeSensorResume = try events().count
        sensorModel.resume()
        for _ in 0..<30 {
            if try events().dropFirst(beforeSensorResume).contains(where: { $0["action"] as? String == "route" }) { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        let resumeEvents = try events().dropFirst(beforeSensorResume)
        let resumeRoute = resumeEvents.first { $0["action"] as? String == "route" }!
        precondition((resumeRoute["points"] as! Int) <= (routeEvent["points"] as! Int),
                     "resuming must continue with the remaining route")
        print("PASS: pausing pins the phone and resuming replays only the remaining route")
        await sensorModel.stop()
        try await sensorModel.shutdown()
        setenv("ROUTEPILOT_TEST_FAIL_REQUESTS", "{\"route\":[1]}", 1)
        let fallbackModel = AppModel()
        fallbackModel.selectedUDID = "test-usb"
        fallbackModel.waypoints = rawPoints.map { Waypoint(name: "Fallback point", point: $0) }
        fallbackModel.parameterMode = 0
        fallbackModel.distanceKM = 0.005
        await fallbackModel.connectDevice()
        await fallbackModel.prepareStartPoint()
        fallbackModel.start()
        for _ in 0..<60 {
            if !fallbackModel.sensorMode { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        precondition(!fallbackModel.sensorMode && fallbackModel.sensorAvailable == false,
                     "a rejected route must fall back to per-coordinate playback")
        for _ in 0..<80 {
            if fallbackModel.state == .finished { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        let fallbackEvents = try events()
        precondition(fallbackEvents.contains { $0["action"] as? String == "set" },
                     "the fallback must send coordinates again")
        print("PASS: a rejected on-device route falls back to coordinate playback")
        await fallbackModel.stop()
        try await fallbackModel.shutdown()
        unsetenv("ROUTEPILOT_TEST_FAIL_REQUESTS")
        unsetenv("ROUTEPILOT_TEST_SET_DELAYS")
        setenv("ROUTEPILOT_TEST_NO_SENSOR", "1", 1)
        let unavailableModel = AppModel()
        unavailableModel.selectedUDID = "test-usb"
        unavailableModel.waypoints = rawPoints.map { Waypoint(name: "No sensor", point: $0) }
        await unavailableModel.connectDevice()
        precondition(!unavailableModel.sensorAvailable && !unavailableModel.useSensorPlayback,
                     "a phone without the simulation service must stay on coordinate playback")
        let beforeUnavailable = try events().count
        await unavailableModel.prepareStartPoint()
        let unavailableActions = try events().dropFirst(beforeUnavailable).compactMap { $0["action"] as? String }
        precondition(unavailableActions == ["set"],
                     "coordinate playback must be used when the sensor service is missing")
        print("PASS: phones without Apple's simulation service keep coordinate playback")

        // Human gait model: two inputs (distance + finish time) describe the run.
        let gaitPlan = try MotionPlan(distanceKM: 5, paceMinutes: 6)
        let automaticSettings = MotionSettings(cadenceAutomatic: true)
        let gaitProfile = try MotionProfile(plan: gaitPlan, settings: automaticSettings, seed: 11)
        let gait = gaitProfile.metrics
        precondition(abs(gait.cadence - 180.2) < 0.2, "6:00 min/km must land on about 180 steps per minute")
        precondition(abs(gait.strideMetres - 1000 / (6 * 60) / (gait.cadence / 60)) < 1e-9,
                     "stride must satisfy speed = cadence x stride")
        precondition(abs(gait.steps - gait.cadence * 30) < 1e-6, "steps must be cadence times duration")
        precondition(gait.climbMetres == 0, "automatic climb must stay at zero instead of inventing terrain")
        print("PASS: distance and finish time generate pace, cadence, stride and steps")
        let slowGait = try MotionProfile(plan: try MotionPlan(distanceKM: 5, paceMinutes: 8),
                                         settings: automaticSettings, seed: 11).metrics
        let fastGait = try MotionProfile(plan: try MotionPlan(distanceKM: 5, paceMinutes: 5),
                                         settings: automaticSettings, seed: 11).metrics
        precondition(slowGait.cadence < gait.cadence && gait.cadence < fastGait.cadence,
                     "cadence must rise with speed")
        precondition(slowGait.strideMetres < gait.strideMetres && gait.strideMetres < fastGait.strideMetres,
                     "stride must rise with speed")
        print("PASS: generated cadence and stride follow the pace")
        let pinnedStride = try MotionProfile(plan: gaitPlan, settings: MotionSettings(
            cadenceAutomatic: true, strideMetres: 1.05, strideAutomatic: false), seed: 11).metrics
        precondition(abs(pinnedStride.strideMetres - 1.05) < 1e-9, "a pinned stride must be kept")
        precondition(abs(pinnedStride.cadence - 60 * gaitPlan.speedMetresPerSecond / 1.05) < 1e-6,
                     "pinning a stride must derive its own cadence")
        let pinnedSteps = try MotionProfile(plan: gaitPlan, settings: MotionSettings(
            cadenceAutomatic: true, steps: 5000, stepsAutomatic: false), seed: 11).metrics
        precondition(abs(pinnedSteps.steps - 5000) < 1e-9, "a pinned step count must be kept")
        precondition(abs(pinnedSteps.cadence - 5000 / 30) < 1e-6, "a pinned step count must derive its cadence")
        let pinnedClimb = try MotionProfile(plan: gaitPlan, settings: MotionSettings(
            cadenceAutomatic: true, climbMetres: 42, climbAutomatic: false), seed: 11)
        precondition(pinnedClimb.metrics.climbMetres == 42, "a pinned climb must be kept")
        precondition(abs(pinnedClimb.sample(elapsed: 900).climbMetres - 21) < 1e-6,
                     "cumulative climb must follow the distance")
        print("PASS: pinned stride, steps and climb are honoured and stay consistent")
        let inconsistent = AppModel()
        inconsistent.previewOnly = true
        inconsistent.waypoints = rawPoints.map { Waypoint(name: "Gait", point: $0) }
        inconsistent.distanceKM = 5
        inconsistent.paceMinutes = 6
        inconsistent.motionSettings = MotionSettings(cadence: 120, cadenceAutomatic: false,
                                                     strideMetres: 0.60, strideAutomatic: false)
        precondition(inconsistent.motionWarning != nil, "inconsistent cadence and stride must be reported")
        precondition(inconsistent.motionError == nil, "a mismatch must warn without blocking the run")
        inconsistent.motionSettings = MotionSettings(cadenceAutomatic: true, strideMetres: 9, strideAutomatic: false)
        precondition(inconsistent.motionError != nil, "an impossible stride must block the run")
        print("PASS: inconsistent gait values warn, impossible ones block")
        let gaitModel = AppModel()
        let gaitRoute = SavedRoute(waypoints: rawPoints.map { Waypoint(name: "Gait route", point: $0) },
                                   path: [], mode: .loop, distanceKM: 5, paceMinutes: 6,
                                   motion: MotionSettings(cadenceAutomatic: true, strideMetres: 0.95,
                                                          strideAutomatic: false, steps: 0, stepsAutomatic: true,
                                                          climbMetres: 30, climbAutomatic: false))
        try gaitModel.loadSavedRoute(try JSONDecoder().decode(SavedRoute.self,
                                                              from: JSONEncoder().encode(gaitRoute)),
                                     repairLegacyMapPoints: false)
        precondition(gaitModel.motionSettings == gaitRoute.motion, "gait settings must survive save and reload")
        let oldMotionJSON = "{\"cadence\":180,\"humanVariation\":true,\"paceVariationSeconds\":10,\"cadenceVariation\":5}"
        let oldMotion = try JSONDecoder().decode(MotionSettings.self, from: Data(oldMotionJSON.utf8))
        precondition(oldMotion.cadenceAutomatic == false && oldMotion.strideAutomatic
                     && oldMotion.stepsAutomatic && oldMotion.climbAutomatic && oldMotion.climbMetres == 0,
                     "settings saved before 0.1.7 must load with automatic stride, steps and climb")
        print("PASS: gait settings round-trip and older files load with automatic defaults")
        let spacingModel = AppModel()
        spacingModel.previewOnly = true
        spacingModel.parameterMode = 0
        spacingModel.distanceKM = 1
        spacingModel.paceMinutes = 6
        spacingModel.waypoints = [Waypoint(name: "A", point: GeoPoint(latitude: 31.0, longitude: 121.0)),
                                  Waypoint(name: "B", point: GeoPoint(latitude: 31.018, longitude: 121.0))]
        let spacingRoute = spacingModel.route!
        let spacingSpeed = spacingModel.plan!.speedMetresPerSecond
        let spacingPoints = spacingModel.sensorWaypoints(route: spacingRoute, from: 0, to: 1000, speed: spacingSpeed)
        let gaps = zip(spacingPoints, spacingPoints.dropFirst()).map { $0.distance(to: $1) }
        precondition(gaps.count > 300 && gaps.allSatisfy { abs($0 - spacingSpeed) < 0.01 },
                     "sensor waypoints must be one whole second of travel apart so the phone keeps the planned pace")
        let longPoints = spacingModel.sensorWaypoints(route: spacingRoute, from: 0, to: 42000, speed: spacingSpeed)
        precondition(longPoints.count <= 4000 && longPoints.count > 3000,
                     "long routes must stay inside the worker request limit by widening the spacing")
        let longGaps = zip(longPoints.prefix(100), longPoints.dropFirst().prefix(100)).map { $0.distance(to: $1) }
        let widened = longGaps[0]
        precondition(widened > spacingSpeed * 3.9 && widened < spacingSpeed * 4.1 && longGaps.allSatisfy { abs($0 - widened) < 0.01 },
                     "the widened spacing must stay a whole number of seconds of travel")
        precondition(abs(spacingModel.sensorWaypoints(route: spacingRoute, from: 40, to: 40, speed: spacingSpeed).count) == 0,
                     "an empty range must not produce waypoints")
        print("PASS: sensor waypoints are whole seconds of travel and stay within limits")
        await unavailableModel.stop(forceRestore: true)
        try await unavailableModel.shutdown()
        unsetenv("ROUTEPILOT_TEST_NO_SENSOR")
        let preparationModel = AppModel()
        preparationModel.selectedUDID = "test-usb"
        preparationModel.sensorMode = false
        preparationModel.waypoints = model.waypoints
        await preparationModel.connectDevice()
        await preparationModel.prepareStartPoint()
        precondition(preparationModel.startPointReady && preparationModel.canStart, "preparation should enable start")
        await preparationModel.stop(forceRestore: true)
        precondition(!preparationModel.startPointReady && !preparationModel.deviceConnected && !preparationModel.needsRestore,
                     "prepared but unstarted location must clear and disconnect")
        await preparationModel.connectDevice()
        precondition(!preparationModel.canStart && !preparationModel.startPointReady, "reconnected session must prepare its own starting point")
        print("PASS: unstarted preparation can restore and does not survive reconnection")
        try await preparationModel.shutdown()
        setenv("ROUTEPILOT_TEST_SET_DELAYS", "[0.01]", 1)
        let stalledModel = AppModel()
        stalledModel.selectedUDID = "test-usb"
        stalledModel.sensorMode = false
        stalledModel.waypoints = rawPoints.map { Waypoint(name: "Stall point", point: $0) }
        stalledModel.motionSettings.humanVariation = true
        await stalledModel.connectDevice()
        await stalledModel.prepareStartPoint()
        stalledModel.start()
        for _ in 0..<30 {
            if stalledModel.currentPoint != nil && !stalledModel.locationBusy { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        let beforeStall = stalledModel.travelledMetres
        usleep(2_000_000) // Simulate a stalled main loop / waking Mac.
        for _ in 0..<30 {
            if stalledModel.travelledMetres > beforeStall { break }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        stalledModel.pause()
        let maximumSpeed = 1000 / (stalledModel.paceMinutes * 60 - stalledModel.motionSettings.paceVariationSeconds)
        precondition(stalledModel.travelledMetres > beforeStall && stalledModel.travelledMetres - beforeStall <= maximumSpeed * 1.03,
                     "a stalled loop must advance at most one bounded motion interval, without catch-up")
        print("PASS: waking after a stalled loop does not jump ahead along the route")
        await stalledModel.stop()
        try await stalledModel.shutdown()
        unsetenv("ROUTEPILOT_TEST_SET_DELAYS")
        print("38 native integration checks passed.")
    }
}
