#!/usr/bin/env python3
"""A delayed protocol peer for native integration tests; never accesses devices."""
import json
import os
import sys
import threading
import time

lock = threading.Lock()
active_sets = 0
set_number = 0
action_counts = {}
fail_requests = json.loads(os.environ.get("ROUTEPILOT_TEST_FAIL_REQUESTS", "{}"))
set_delays = json.loads(os.environ.get("ROUTEPILOT_TEST_SET_DELAYS", "[]"))
log_path = os.environ["ROUTEPILOT_TEST_LOG"]


def handle(request):
    global active_sets, set_number
    action = request["action"]
    received_at = time.monotonic()
    with lock:
        action_counts[action] = action_counts.get(action, 0) + 1
        fail = action_counts[action] in fail_requests.get(action, [])
        if action == "set":
            active_sets += 1
            set_number += 1
        sequence = set_number
        event = {"udid": request.get("udid"), "action": action, "active_sets": active_sets,
                 "latitude": request.get("latitude"), "longitude": request.get("longitude"),
                 "speed": request.get("speed"), "points": len(request.get("waypoints") or []),
                 "received_at": received_at}
    if action == "set":
        time.sleep(set_delays[min(sequence - 1, len(set_delays) - 1)] if set_delays else 0.8)
    event["applied_at"] = time.monotonic()
    with lock:
        with open(log_path, "a") as log:
            log.write(json.dumps(event) + "\n")
    result = [] if action == "devices" else {"sent": True}
    if action == "clear":
        result = {"restore_sent": True, "session_closed": True, "verified": False}
    if action == "connect":
        result = {"name": "Test phone", "version": "27.0.1", "sensor": os.environ.get("ROUTEPILOT_TEST_NO_SENSOR") != "1"}
    if action == "route":
        result = {"points": len(request.get("waypoints") or []), "speed": request.get("speed"), "sensor": True}
    with lock:
        reply = {"id": request["id"], "ok": True, "result": result}
        if fail:
            reply = {"id": request["id"], "ok": False, "error": "Injected " + action + " failure"}
        sys.stdout.write(json.dumps(reply) + "\n")
        sys.stdout.flush()
        if action == "set":
            active_sets -= 1


threads = []
for line in sys.stdin:
    request = json.loads(line)
    thread = threading.Thread(target=handle, args=(request,))
    thread.start()
    threads.append(thread)
    if request["action"] == "shutdown":
        break
for thread in threads:
    thread.join()
