import Foundation
import RouteCore

@main struct CoreTests {
    static func main() throws {
        var count = 0
        func check(_ condition: @autoclosure () -> Bool, _ name: String) {
            guard condition() else { fatalError("FAIL: \(name)") }
            count += 1
            print("PASS: \(name)")
        }
        func rejects(_ action: () throws -> Void, _ name: String) {
            do { try action(); fatalError("FAIL: \(name)") }
            catch { count += 1; print("PASS: \(name)") }
        }
        let a = GeoPoint(latitude: 0, longitude: 0)
        let b = GeoPoint(latitude: 0, longitude: 0.01)
        let beijing = GeoPoint(latitude: 39.915, longitude: 116.404)
        let shifted = MapCoordinates.toGCJ02(beijing)
        check(abs(shifted.latitude - 39.9164042815) < 1e-7 && abs(shifted.longitude - 116.4102444992) < 1e-7, "mainland map conversion reference")
        check(MapCoordinates.toWGS84(shifted).distance(to: beijing) < 0.02, "mainland conversion round trip")
        let newYork = GeoPoint(latitude: 40.7681, longitude: -73.9819)
        check(MapCoordinates.toGCJ02(newYork) == newYork, "outside mainland unchanged")
        let bounce = try Route(points: [a, b], mode: .bounce)
        check(abs(bounce.length - 1111.9508) < 0.1, "WGS-84 sphere distance")
        check(abs(bounce.sample(distance: bounce.length * 1.5).longitude - 0.005) < 1e-6, "return along same route")
        check(bounce.sample(distance: bounce.length * 2) == a, "bounce endpoint")
        let c = GeoPoint(latitude: 0.01, longitude: 0.01)
        let loop = try Route(points: [a, b, c], mode: .loop)
        check(loop.length > a.distance(to: b) + b.distance(to: c), "loop includes closing segment")
        check(loop.sample(distance: loop.length - 0.1).distance(to: loop.sample(distance: loop.length + 0.1)) < 0.21, "loop has no teleport")
        let crossing = try Route(points: [.init(latitude: 10, longitude: 179.9), .init(latitude: 10, longitude: -179.9)], mode: .bounce)
        check(abs(crossing.sample(distance: crossing.length / 2).longitude) > 179.99, "short path across antimeridian")
        let duplicates = try Route(points: [a, a, b, b], mode: .bounce)
        check(abs(duplicates.sample(distance: duplicates.length / 2).longitude - 0.005) < 1e-6, "duplicate vertices")
        rejects({ _ = try Route(points: [a], mode: .bounce) }, "reject single point")
        rejects({ _ = try Route(points: [a, a], mode: .bounce) }, "reject zero length")
        rejects({ _ = try Route(points: [a, .init(latitude: .nan, longitude: 0)], mode: .bounce) }, "reject NaN coordinate")
        rejects({ _ = try Route(points: [a, .init(latitude: 91, longitude: 0)], mode: .bounce) }, "reject invalid latitude")
        let plan = try MotionPlan(distanceKM: 5, paceMinutes: 6)
        check(plan.durationSeconds == 1800, "5 km at 6 min/km is 30 minutes")
        check(abs(plan.speedMetresPerSecond - 1000 / 360) < 0.001, "pace to speed")
        let timed = try MotionPlan(distanceKM: 5, durationMinutes: 30)
        check(timed.paceMinutes == 6, "duration to pace")
        rejects({ _ = try MotionPlan(distanceKM: 0, paceMinutes: 6) }, "reject zero distance")
        rejects({ _ = try MotionPlan(distanceKM: 5, paceMinutes: .infinity) }, "reject infinite pace")
        let fixedMotion = try MotionProfile(plan: plan, settings: MotionSettings(), seed: 7)
        let fixedSample = fixedMotion.sample(elapsed: 60)
        check(abs(fixedSample.distanceMetres - plan.speedMetresPerSecond * 60) < 1e-8 && fixedSample.cadence == 180 && fixedSample.steps == 180, "disabled variation gives constant pace and cadence")
        let humanSettings = MotionSettings(cadence: 180, humanVariation: true, paceVariationSeconds: 15, cadenceVariation: 8)
        let humanMotion = try MotionProfile(plan: plan, settings: humanSettings, seed: 7)
        let samples = (0...18000).map { humanMotion.sample(elapsed: Double($0) / 10) }
        check(samples.contains { abs($0.paceMinutes - 6) > 0.01 }, "human variation changes the actual pace")
        check(samples.allSatisfy { $0.paceMinutes >= 5.75 - 1e-9 && $0.paceMinutes <= 6.25 + 1e-9 }, "all instantaneous paces stay inside the configured range")
        check(samples.contains { abs($0.cadence - 180) > 1 } && samples.allSatisfy { $0.cadence >= 172 - 1e-9 && $0.cadence <= 188 + 1e-9 }, "cadence varies inside the configured range")
        check(zip(samples, samples.dropFirst()).allSatisfy { $1.distanceMetres >= $0.distanceMetres && abs($1.cadence - $0.cadence) < 1 }, "motion advances smoothly without jumps or reverse movement")
        check(abs(samples.last!.distanceMetres - 5000) < 1e-8 && abs(samples.last!.steps - 5400) < 1e-8, "variable motion preserves total time distance and average cadence")
        let clampedEnd = humanMotion.sample(elapsed: 2000)
        check(clampedEnd.distanceMetres == 5000 && clampedEnd.steps == 5400 && humanMotion.sample(elapsed: -10).distanceMetres == 0, "motion clamps times at the start and finish")
        let t = 7.0, epsilon = 0.0001
        let observedSpeed = (humanMotion.sample(elapsed: t + epsilon).distanceMetres - humanMotion.sample(elapsed: t - epsilon).distanceMetres) / (2 * epsilon)
        let observedCadence = (humanMotion.sample(elapsed: t + epsilon).steps - humanMotion.sample(elapsed: t - epsilon).steps) / (2 * epsilon) * 60
        check(abs(observedSpeed - 1000 / (humanMotion.sample(elapsed: t).paceMinutes * 60)) < 1e-6 && abs(observedCadence - humanMotion.sample(elapsed: t).cadence) < 1e-6, "distance and step integrals agree with instantaneous pace and cadence")
        let sameMotion = try MotionProfile(plan: plan, settings: humanSettings, seed: 7)
        let otherMotion = try MotionProfile(plan: plan, settings: humanSettings, seed: 8)
        check(sameMotion.sample(elapsed: t) == humanMotion.sample(elapsed: t) && otherMotion.sample(elapsed: t) != humanMotion.sample(elapsed: t), "seed preserves replay while new seed changes variation")
        for range in [-1.0, 360.0, Double.nan] {
            rejects({ _ = try MotionProfile(plan: plan, settings: MotionSettings(cadence: 180, humanVariation: true, paceVariationSeconds: range, cadenceVariation: 5), seed: 0) }, "reject invalid pace fluctuation range")
        }
        rejects({ _ = try MotionProfile(plan: plan, settings: MotionSettings(cadence: 180, humanVariation: true, paceVariationSeconds: 5, cadenceVariation: 180), seed: 0) }, "reject cadence range that reaches zero")
        rejects({ _ = try MotionProfile(plan: plan, settings: MotionSettings(cadence: .infinity), seed: 0) }, "reject non-finite cadence")
        let zeroRange = try MotionProfile(plan: plan, settings: MotionSettings(cadence: 160, humanVariation: true, paceVariationSeconds: 0, cadenceVariation: 0), seed: 0)
        check(zeroRange.sample(elapsed: 17).paceMinutes == 6 && zeroRange.sample(elapsed: 17).cadence == 160, "zero ranges give a stable human mode")
        var clock = PlaybackClock()
        clock.start(at: 100)
        clock.pause(at: 110)
        check(clock.elapsed(at: 200) == 10, "pause excludes idle time")
        clock.resume(at: 200)
        check(clock.elapsed(at: 205) == 15, "resume accumulates active time")
        clock.freeze(atElapsed: 7)
        check(clock.elapsed(at: 300) == 7, "failure retains confirmed elapsed time")
        clock.resume(at: 300)
        check(clock.elapsed(at: 301) == 8, "recovery starts from confirmed position")
        print("\(count) core checks passed.")
    }
}
