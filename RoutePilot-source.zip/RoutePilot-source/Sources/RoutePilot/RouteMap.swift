import SwiftUI
import MapKit
import RouteCore

final class RouteAnnotation: NSObject, MKAnnotation {
    @objc dynamic var coordinate: CLLocationCoordinate2D
    var title: String?
    let waypointID: UUID?
    let number: Int
    init(point: GeoPoint, title: String, waypointID: UUID? = nil, number: Int = 0) {
        coordinate = point.coordinate
        self.title = title; self.waypointID = waypointID; self.number = number
    }
}

struct RouteMap: NSViewRepresentable {
    @ObservedObject var model: AppModel
    var blockedAreas: [CGRect] = []

    func makeCoordinator() -> Coordinator { Coordinator(model: model) }

    func makeNSView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.delegate = context.coordinator
        map.preferredConfiguration = MKHybridMapConfiguration(elevationStyle: .flat)
        map.showsCompass = true
        map.showsScale = true
        map.showsZoomControls = true
        map.isRotateEnabled = false
        map.setRegion(MKCoordinateRegion(center: .init(latitude: 31.2304, longitude: 121.4737), span: .init(latitudeDelta: 0.04, longitudeDelta: 0.05)), animated: false)
        let click = NSClickGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.clicked(_:)))
        click.delegate = context.coordinator
        map.addGestureRecognizer(click)
        context.coordinator.map = map
        return map
    }

    func updateNSView(_ map: MKMapView, context: Context) {
        let coordinator = context.coordinator
        coordinator.model = model
        coordinator.blockedAreas = blockedAreas
        if coordinator.lastLayer != model.mapLayer {
            coordinator.lastLayer = model.mapLayer
            switch model.mapLayer {
            case .hybrid: map.preferredConfiguration = MKHybridMapConfiguration(elevationStyle: .flat)
            case .satellite: map.preferredConfiguration = MKImageryMapConfiguration(elevationStyle: .flat)
            case .standard: map.preferredConfiguration = MKStandardMapConfiguration(elevationStyle: .flat)
            }
        }
        if coordinator.lastWaypoints != model.waypoints {
            coordinator.lastWaypoints = model.waypoints
            map.removeAnnotations(map.annotations.filter { ($0 as? RouteAnnotation)?.waypointID != nil })
            let annotations = model.waypoints.enumerated().map { index, waypoint in
                RouteAnnotation(point: model.mapPoint(waypoint.point), title: waypoint.name, waypointID: waypoint.id, number: index + 1)
            }
            map.addAnnotations(annotations)
        }
        let line = (model.route?.points ?? model.path).map(model.mapPoint)
        if coordinator.lastPath != line {
            coordinator.lastPath = line
            map.removeOverlays(map.overlays)
            if line.count > 1 {
                let coordinates = line.map(\.coordinate)
                map.addOverlay(MKPolyline(coordinates: coordinates, count: coordinates.count))
            }
        }
        for annotation in map.annotations {
            if let marker = map.view(for: annotation) as? MKMarkerAnnotationView {
                marker.isDraggable = model.editable && (annotation as? RouteAnnotation)?.waypointID != nil
            }
        }
        if let point = model.currentPoint {
            if let marker = coordinator.moving {
                marker.coordinate = model.mapPoint(point).coordinate
            } else {
                let marker = RouteAnnotation(point: model.mapPoint(point), title: model.previewOnly ? "预览位置" : "已确认的 iPhone 位置")
                coordinator.moving = marker
                map.addAnnotation(marker)
            }
        } else if let marker = coordinator.moving {
            map.removeAnnotation(marker)
            coordinator.moving = nil
        }
        if coordinator.lastFit != model.fitRequest {
            coordinator.lastFit = model.fitRequest
            if !line.isEmpty {
                let coordinates = line.map(\.coordinate)
                let overlay = MKPolyline(coordinates: coordinates, count: coordinates.count)
                map.setVisibleMapRect(overlay.boundingMapRect, edgePadding: NSEdgeInsets(top: 100, left: 70, bottom: 100, right: 70), animated: true)
            }
        }
        if (coordinator.lastFocus != model.focusedPoint || coordinator.lastFocusRequest != model.focusRequest), let point = model.focusedPoint {
            coordinator.lastFocus = point
            coordinator.lastFocusRequest = model.focusRequest
            let center = model.mapPoint(point).coordinate
            let oldRect = map.visibleMapRect
            let scale = min(1, 250 * MKMapPointsPerMeterAtLatitude(center.latitude) / oldRect.height)
            let width = oldRect.width * scale, height = oldRect.height * scale
            let mapPoint = MKMapPoint(center)
            map.setVisibleMapRect(MKMapRect(x: mapPoint.x - width / 2, y: mapPoint.y - height / 2, width: width, height: height), animated: true)
        }
    }

    @MainActor final class Coordinator: NSObject, MKMapViewDelegate, NSGestureRecognizerDelegate {
        var model: AppModel
        weak var map: MKMapView?
        var lastWaypoints: [Waypoint] = []
        var lastPath: [GeoPoint] = []
        var lastFit: UUID?
        var lastFocus: GeoPoint?
        var lastFocusRequest: UUID?
        var lastLayer: MapLayer?
        var blockedAreas: [CGRect] = []
        var moving: RouteAnnotation?
        init(model: AppModel) { self.model = model }

        @objc func clicked(_ gesture: NSClickGestureRecognizer) {
            guard model.editable, let map, gesture.state == .ended else { return }
            let location = gesture.location(in: map)
            let topLeftPoint = CGPoint(x: location.x, y: map.isFlipped ? location.y : map.bounds.height - location.y)
            guard !blockedAreas.contains(where: { $0.contains(topLeftPoint) }) else { return }
            var hit = map.hitTest(location)
            while let view = hit {
                if view is MKAnnotationView || view is NSControl { return }
                hit = view.superview
            }
            let coordinate = map.convert(location, toCoordinateFrom: map)
            model.addPoint(model.gpsPoint(.init(latitude: coordinate.latitude, longitude: coordinate.longitude)))
        }

        func gestureRecognizer(_ gestureRecognizer: NSGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: NSGestureRecognizer) -> Bool { true }

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            let renderer = MKPolylineRenderer(overlay: overlay)
            renderer.strokeColor = NSColor.systemTeal
            renderer.lineWidth = 5
            renderer.lineCap = .round
            renderer.lineJoin = .round
            return renderer
        }

        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            guard let point = annotation as? RouteAnnotation else { return nil }
            let identifier = point.waypointID == nil ? "moving" : "waypoint"
            let marker = (mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKMarkerAnnotationView)
                ?? MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            marker.annotation = annotation
            marker.canShowCallout = true
            marker.isDraggable = model.editable && point.waypointID != nil
            marker.markerTintColor = point.waypointID == nil ? .systemBlue : .systemTeal
            marker.glyphText = point.waypointID == nil ? nil : String(point.number)
            marker.glyphImage = point.waypointID == nil ? NSImage(systemSymbolName: "figure.walk", accessibilityDescription: "当前位置") : nil
            marker.displayPriority = .required
            return marker
        }

        func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, didChange newState: MKAnnotationView.DragState, fromOldState oldState: MKAnnotationView.DragState) {
            guard newState == .ending, let annotation = view.annotation as? RouteAnnotation, let id = annotation.waypointID else { return }
            model.updatePoint(id: id, point: model.gpsPoint(.init(latitude: annotation.coordinate.latitude, longitude: annotation.coordinate.longitude)))
            view.dragState = .none
        }

        func mapViewDidFailLoadingMap(_ mapView: MKMapView, withError error: Error) {
            model.errorMessage = "地图加载失败，请检查网络连接。\n" + error.localizedDescription
        }

        func mapViewDidChangeVisibleRegion(_ mapView: MKMapView) {
            let center = mapView.centerCoordinate
            model.mapCenterCoordinate = .init(latitude: center.latitude, longitude: center.longitude)
        }
    }
}
