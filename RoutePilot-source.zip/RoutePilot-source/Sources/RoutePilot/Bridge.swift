import Foundation

struct BridgeError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

@MainActor final class DeviceBridge {
    private struct Pending {
        let continuation: CheckedContinuation<Any, Error>
        let deadline: Task<Void, Never>
    }
    private var process: Process?
    private var input: FileHandle?
    private var output: FileHandle?
    private var stderr: FileHandle?
    private var buffer = Data()
    private var pending: [String: Pending] = [:]
    private var generation = 0
    private var errorTail = ""
    var onFailure: ((String) -> Void)?
    var isRunning: Bool { process?.isRunning == true }

    func launch() throws {
        if isRunning { return }
        generation += 1
        let token = generation
        let worker = Process()
        if let override = ProcessInfo.processInfo.environment["ROUTEPILOT_WORKER"] {
            worker.executableURL = URL(fileURLWithPath: override)
        } else if let url = Bundle.main.url(forResource: "routepilot-worker", withExtension: nil, subdirectory: "worker") {
            worker.executableURL = url
        } else {
            throw BridgeError(message: "连接模块缺失，请使用完整的“路行 RoutePilot.app”。")
        }
        let stdinPipe = Pipe(), stdoutPipe = Pipe(), errorPipe = Pipe()
        worker.standardInput = stdinPipe
        worker.standardOutput = stdoutPipe
        worker.standardError = errorPipe
        worker.environment = ProcessInfo.processInfo.environment.merging(["PYTHONUNBUFFERED": "1"]) { _, new in new }
        worker.currentDirectoryURL = worker.executableURL?.deletingLastPathComponent()
        buffer = Data()
        errorTail = ""
        stdoutPipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let bytes = handle.availableData
            DispatchQueue.main.async { self?.consume(bytes, token: token) }
        }
        errorPipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let bytes = handle.availableData
            DispatchQueue.main.async {
                guard let self, self.generation == token else { return }
                self.errorTail = String((self.errorTail + String(decoding: bytes, as: UTF8.self)).suffix(2500))
            }
        }
        worker.terminationHandler = { [weak self] process in
            DispatchQueue.main.async {
                guard let self, self.generation == token else { return }
                let detail = self.errorTail.trimmingCharacters(in: .whitespacesAndNewlines)
                let message = "连接模块已退出（\(process.terminationStatus)）。" + (detail.isEmpty ? "" : "\n" + detail)
                self.releaseHandles()
                self.failPending(message)
                self.onFailure?(message)
            }
        }
        do { try worker.run() }
        catch {
            stdoutPipe.fileHandleForReading.readabilityHandler = nil
            errorPipe.fileHandleForReading.readabilityHandler = nil
            throw error
        }
        process = worker
        input = stdinPipe.fileHandleForWriting
        output = stdoutPipe.fileHandleForReading
        stderr = errorPipe.fileHandleForReading
    }

    func request(_ action: String, _ fields: [String: Any] = [:], timeout: Double = 15) async throws -> Any {
        try launch()
        let id = UUID().uuidString
        var request = fields
        request["id"] = id
        request["action"] = action
        var bytes = try JSONSerialization.data(withJSONObject: request)
        bytes.append(10)
        return try await withCheckedThrowingContinuation { continuation in
            let timer = Task { [weak self] in
                do { try await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000)) }
                catch { return }
                guard let self, self.pending[id] != nil else { return }
                let message = "设备操作超时。请解锁 iPhone、检查数据线，再重新连接；当前无法确认定位是否恢复。"
                self.reset(message: message)
                self.onFailure?(message)
            }
            pending[id] = Pending(continuation: continuation, deadline: timer)
            do { try input?.write(contentsOf: bytes) }
            catch { resolve(id, .failure(error)) }
        }
    }

    private func consume(_ bytes: Data, token: Int) {
        guard token == generation else { return }
        buffer.append(bytes)
        if buffer.count > 1_048_576 {
            reset(message: "连接模块返回的数据异常，请重新连接。")
            return
        }
        while let newline = buffer.firstIndex(of: 10) {
            let line = buffer.prefix(upTo: newline)
            buffer.removeSubrange(...newline)
            guard let object = try? JSONSerialization.jsonObject(with: line) as? [String: Any],
                  let id = object["id"] as? String else { continue }
            if object["ok"] as? Bool == true {
                resolve(id, .success(object["result"] ?? NSNull()))
            } else {
                resolve(id, .failure(BridgeError(message: object["error"] as? String ?? "设备操作失败。")))
            }
        }
    }

    private func resolve(_ id: String, _ result: Result<Any, Error>) {
        guard let entry = pending.removeValue(forKey: id) else { return }
        entry.deadline.cancel()
        entry.continuation.resume(with: result)
    }

    private func failPending(_ message: String) {
        let entries = pending.values
        pending.removeAll()
        for entry in entries {
            entry.deadline.cancel()
            entry.continuation.resume(throwing: BridgeError(message: message))
        }
    }

    private func releaseHandles() {
        output?.readabilityHandler = nil
        stderr?.readabilityHandler = nil
        try? input?.close()
        input = nil
        output = nil
        stderr = nil
        process = nil
    }

    func reset(message: String = "连接会话已重置，请重新连接 iPhone。") {
        generation += 1
        let old = process
        old?.terminationHandler = nil
        if old?.isRunning == true { old?.terminate() }
        releaseHandles()
        failPending(message)
        buffer = Data()
    }
}
