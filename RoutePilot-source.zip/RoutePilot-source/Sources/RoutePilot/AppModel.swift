import SwiftUI
import MapKit
import UniformTypeIdentifiers
import RouteCore

struct Waypoint: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var point: GeoPoint
}

struct Phone: Identifiable {
    let udid: String
    let name: String
    let version: String
    let trusted: Bool
    var id: String { udid }
}

enum RunState { case idle, running, paused, finished }

enum MapLayer: String, CaseIterable, Identifiable {
    case hybrid = "卫星 + 路名", satellite = "纯卫星", standard = "普通地图"
    var id: String { rawValue }
}

struct SavedRoute: Codable {
    var schema = 4
    var waypoints: [Waypoint]
    var path: [GeoPoint]
    var mode: RouteMode
    var distanceKM: Double
    var paceMinutes: Double
    var motion: MotionSettings? = nil
}

@MainActor final class AppModel: ObservableObject {
    @Published var waypoints: [Waypoint] = []
    @Published var walkingPath: [GeoPoint] = []
    private var walkingRouteMode: RouteMode?
    @Published var routeMode: RouteMode = .bounce
    @Published var distanceKM = 5.0
    @Published var paceMinutes = 6.0
    @Published var durationMinutes = 30.0
    @Published var parameterMode = 1
    @Published var motionSettings = MotionSettings(cadenceAutomatic: true)
    @Published var livePaceMinutes = 0.0
    @Published var liveCadence = 0.0
    @Published var estimatedSteps = 0.0
    @Published var previewOnly = true
    @Published var phones: [Phone] = []
    @Published var selectedUDID = ""
    @Published var deviceConnected = false
    @Published var deviceBusy = false
    @Published var routingBusy = false
    /// Apple's own on-device location simulation (the engine behind the
    /// Simulator's "City Run" scenario) plays a whole route and reports a real
    /// speed field, instead of one raw coordinate per USB round trip.
    @Published var sensorAvailable = false
    @Published var sensorMode = true
    private(set) var sensorRun = false
    @Published var state: RunState = .idle
    @Published var status = "点击地图添加点位，设置参数后开始预览。"
    @Published var errorMessage: String?
    @Published var confirmedElapsed = 0.0
    @Published var travelledMetres = 0.0
    @Published var currentPoint: GeoPoint?
    @Published var needsRestore = false
    @Published var locationBusy = false
    @Published var restoreSent = false
    @Published private(set) var preparedStartPoint: GeoPoint?
    @Published var fitRequest = UUID()
    @Published var focusedPoint: GeoPoint?
    @Published var focusRequest = UUID()
    @Published var mapLayer: MapLayer = .hybrid
    @Published var mapCenterCoordinate: GeoPoint?
    @Published var searchText = ""
    @Published var searchResults: [MKMapItem] = []
    @Published var searching = false
    @Published var showHelp = false
    let bridge = DeviceBridge()
    private var clock = PlaybackClock()
    private var playbackTask: Task<Void, Never>?
    private var playRoute: Route?
    private var playPlan: MotionPlan?
    private var playProfile: MotionProfile?
    private var motionSeed = UInt64.random(in: 0...UInt64.max)
    private var sessionVersion = 0
    private var search: MKLocalSearch?
    private var directions: MKDirections?
    private var searchVersion = 0
    private var previewSession = true
    private var preparedPhone = ""

    var editable: Bool { state == .idle && !needsRestore && !deviceBusy && !routingBusy }
    var active: Bool { state == .running || state == .paused }
    var path: [GeoPoint] { walkingPath.isEmpty ? waypoints.map(\.point) : walkingPath }
    var route: Route? { try? Route(points: path, mode: routeMode) }
    var routeLengthKM: Double { (route?.length ?? 0) / 1000 }
    var plan: MotionPlan? {
        parameterMode == 0 ? try? MotionPlan(distanceKM: distanceKM, paceMinutes: paceMinutes)
            : try? MotionPlan(distanceKM: distanceKM, durationMinutes: durationMinutes)
    }
    var totalSeconds: Double { playPlan?.durationSeconds ?? plan?.durationSeconds ?? 0 }
    var progress: Double { totalSeconds > 0 ? min(1, confirmedElapsed / totalSeconds) : 0 }
    var effectivePace: Double { plan?.paceMinutes ?? 0 }
    var effectiveDuration: Double { (plan?.durationSeconds ?? 0) / 60 }
    var motionProfile: MotionProfile? {
        guard let plan else { return nil }
        return try? MotionProfile(plan: plan, settings: motionSettings, seed: motionSeed)
    }
    /// Sensor playback runs at one speed chosen by the phone, so the planned
    /// pace/cadence variation is flattened to keep the app and the phone aligned.
    var sensorSettings: MotionSettings {
        var settings = motionSettings
        settings.humanVariation = false
        return settings
    }
    var useSensorPlayback: Bool { sensorMode && sensorAvailable }
    var sensorProfile: MotionProfile? {
        guard let plan else { return nil }
        return try? MotionProfile(plan: plan, settings: sensorSettings, seed: motionSeed)
    }
    var motionError: String? {
        guard let plan else { return "请输入有效的正数距离、配速或时间。" }
        do { _ = try MotionProfile(plan: plan, settings: motionSettings, seed: motionSeed); return nil }
        catch { return error.localizedDescription }
    }
    /// Values that run but do not add up (kept out of ``motionError`` so a run is
    /// not blocked, e.g. a stride typed next to an inconsistent cadence).
    var motionWarning: String? {
        guard let plan, motionSettings.stepsAutomatic, !motionSettings.strideAutomatic,
              motionSettings.strideMetres > 0,
              let resolved = try? MotionProfile.resolve(plan: plan, settings: motionSettings) else { return nil }
        let implied = HumanGait.stride(speedMetresPerSecond: plan.speedMetresPerSecond, cadence: resolved.cadence)
        guard implied > 0, abs(implied - resolved.strideMetres) > implied * 0.05 else { return nil }
        return String(format: "步频与步幅跟配速不一致：该配速下步幅应为 %.2f 米。发给手机的是配速，步频/步幅只用于记录与导出。", implied)
    }
    /// Everything the plan implies after automatic resolution; distance and
    /// finish time are the only numbers the user has to supply.
    var humanMetrics: HumanMetrics? {
        guard let plan, let profile = try? MotionProfile(plan: plan, settings: motionSettings, seed: motionSeed) else { return nil }
        return profile.metrics
    }
    var canSaveRoute: Bool { route != nil && motionProfile != nil }
    var startPointReady: Bool {
        deviceConnected && !preparedPhone.isEmpty && preparedPhone == selectedUDID
            && preparedStartPoint == route?.sample(distance: 0) && preparedStartPoint != nil
    }
    var canPrepareStartPoint: Bool {
        (state == .idle || state == .finished) && !previewOnly && !selectedUDID.isEmpty
            && !deviceBusy && !locationBusy && !routingBusy && !startPointReady
            && route != nil && motionProfile != nil
    }
    var canStart: Bool {
        state == .idle && !deviceBusy && !routingBusy && route != nil && motionProfile != nil
            && (previewOnly ? !needsRestore : startPointReady)
    }
    var canResume: Bool { state == .paused && !deviceBusy && !locationBusy && (previewSession || deviceConnected) }

    // MapKit handles the provider's datum internally. Converting the SDK coordinate
    // again displaces USB output while the inverse display conversion hides it.
    func mapPoint(_ point: GeoPoint) -> GeoPoint { point }
    func gpsPoint(_ point: GeoPoint) -> GeoPoint { point }
    var mapCenterPoint: GeoPoint? { mapCenterCoordinate.map(gpsPoint) }

    init() {
        bridge.onFailure = { [weak self] message in
            guard let self else { return }
            self.deviceConnected = false
            if self.state == .running { self.pauseAtConfirmedPosition() }
            self.errorMessage = message
        }
    }

    func refreshDevices() async {
        guard !deviceBusy else { return }
        deviceBusy = true
        defer { deviceBusy = false }
        do {
            let result = try await bridge.request("devices", timeout: 25)
            let records = result as? [[String: Any]] ?? []
            phones = records.compactMap { item in
                guard let udid = item["udid"] as? String else { return nil }
                return Phone(udid: udid, name: item["name"] as? String ?? "iPhone", version: item["version"] as? String ?? "", trusted: item["trusted"] as? Bool ?? false)
            }
            if !deviceConnected && !needsRestore && !phones.contains(where: { $0.udid == selectedUDID }) {
                selectedUDID = phones.first?.udid ?? ""
            }
            if phones.isEmpty { status = "未发现 USB iPhone。可先使用仅地图预览。" }
        } catch { errorMessage = error.localizedDescription }
    }

    func prepareDevice() async {
        guard !selectedUDID.isEmpty, !deviceBusy, !deviceConnected else { return }
        deviceBusy = true
        errorMessage = nil
        status = "正在准备开发者组件，首次下载可能需要几分钟…"
        defer { deviceBusy = false }
        do {
            _ = try await bridge.request("prepare", ["udid": selectedUDID], timeout: 600)
            status = "开发者组件已准备好，可以连接定位会话。"
        } catch { status = "设备准备失败。"; errorMessage = error.localizedDescription }
    }

    func connectDevice() async {
        guard !selectedUDID.isEmpty, !deviceBusy, !deviceConnected else { return }
        deviceBusy = true
        errorMessage = nil
        status = "正在连接 USB 定位会话…"
        defer { deviceBusy = false }
        do {
            preparedStartPoint = nil; preparedPhone = ""
            bridge.reset()
            let reply = try await bridge.request("connect", ["udid": selectedUDID], timeout: 40) as? [String: Any]
            sensorAvailable = reply?["sensor"] as? Bool ?? false
            deviceConnected = true
            if !active && !needsRestore { previewOnly = false }
            if needsRestore {
                status = "已重新连接，请恢复真实定位，或继续此前路线。"
            } else if sensorAvailable {
                status = sensorMode ? "iPhone 定位会话已连接；开启 Apple 定位仿真。" : "iPhone 定位会话已连接。"
            } else {
                status = "iPhone 定位会话已连接；这台手机未提供 Apple 定位仿真，将逐点发送坐标。"
            }
        } catch {
            sensorAvailable = false
            status = "连接失败。请确认开发者模式，并先点击“准备设备”。"
            errorMessage = error.localizedDescription
        }
    }

    func disconnectDevice() async {
        guard !deviceBusy else { return }
        deviceBusy = true
        defer { deviceBusy = false }
        do {
            _ = try await bridge.request("disconnect")
            deviceConnected = false
            needsRestore = false
            sensorAvailable = false
            sensorRun = false
            preparedStartPoint = nil; preparedPhone = ""
            status = "已断开设备。"
        } catch { errorMessage = error.localizedDescription }
    }

    func addPoint(_ point: GeoPoint, name: String? = nil) {
        guard editable, point.isValid else { return }
        waypoints.append(Waypoint(name: name ?? "点位 \(waypoints.count + 1)", point: point))
        walkingPath = []
        currentPoint = nil
        errorMessage = nil
        status = "已添加 \(waypoints.count) 个点位。拖动图钉可调整位置。"
    }

    func updatePoint(id: UUID, point: GeoPoint) {
        guard editable, point.isValid, let index = waypoints.firstIndex(where: { $0.id == id }) else { return }
        waypoints[index].point = point
        walkingPath = []
    }

    func focusPoint(_ point: GeoPoint) {
        focusedPoint = point
        focusRequest = UUID()
    }

    func removePoint(id: UUID) {
        guard editable else { return }
        waypoints.removeAll { $0.id == id }
        walkingPath = []
    }

    func movePoint(id: UUID, offset: Int) {
        guard editable, let index = waypoints.firstIndex(where: { $0.id == id }),
              waypoints.indices.contains(index + offset) else { return }
        waypoints.swapAt(index, index + offset)
        walkingPath = []
    }

    func clearRoute() {
        guard editable else { return }
        waypoints = []; walkingPath = []; currentPoint = nil
        travelledMetres = 0; confirmedElapsed = 0
        livePaceMinutes = 0; liveCadence = 0; estimatedSteps = 0
        playPlan = nil; playRoute = nil; playProfile = nil
    }

    func useRouteDistance() {
        if routeLengthKM > 0 { distanceKM = routeLengthKM }
    }

    func loadExample() {
        guard editable else { return }
        waypoints = [
            Waypoint(name: "中央公园 · 南端", point: .init(latitude: 40.7681, longitude: -73.9819)),
            Waypoint(name: "林荫步道", point: .init(latitude: 40.7725, longitude: -73.9731)),
            Waypoint(name: "贝塞斯达喷泉", point: .init(latitude: 40.7743, longitude: -73.9708)),
            Waypoint(name: "湖边", point: .init(latitude: 40.7774, longitude: -73.9746))
        ]
        walkingPath = []
        distanceKM = 1; paceMinutes = 6; durationMinutes = 6
        previewOnly = true
        fitRequest = UUID()
        status = "示例路线已加载；仅地图预览不会更改 iPhone 定位。"
    }

    func searchPlaces() async {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return }
        search?.cancel()
        searchVersion += 1
        let token = searchVersion
        searching = true
        defer { if token == searchVersion { searching = false } }
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        let operation = MKLocalSearch(request: request)
        search = operation
        do {
            let response = try await operation.start()
            guard token == searchVersion else { return }
            searchResults = Array(response.mapItems.prefix(6))
            if searchResults.isEmpty { errorMessage = "没有找到地点，请使用城市名加地点名重试。" }
        } catch { if token == searchVersion { errorMessage = "地点搜索失败：" + error.localizedDescription } }
    }

    func selectSearchResult(_ item: MKMapItem) {
        let coordinate = item.placemark.coordinate
        let point = gpsPoint(GeoPoint(latitude: coordinate.latitude, longitude: coordinate.longitude))
        focusedPoint = point
        addPoint(point, name: item.name ?? "搜索地点")
        searchResults = []
    }

    func generateWalkingRoute() async {
        guard editable, waypoints.count >= 2 else { return }
        routingBusy = true
        errorMessage = nil
        defer { routingBusy = false; directions = nil }
        var points = waypoints.map(\.point)
        if routeMode == .loop && points.first != points.last { points.append(points[0]) }
        var result: [GeoPoint] = []
        do {
            for index in 1..<points.count {
                let request = MKDirections.Request()
                request.source = MKMapItem(placemark: MKPlacemark(coordinate: mapPoint(points[index - 1]).coordinate))
                request.destination = MKMapItem(placemark: MKPlacemark(coordinate: mapPoint(points[index]).coordinate))
                request.transportType = .walking
                let operation = MKDirections(request: request)
                directions = operation
                let response = try await operation.calculate()
                guard let route = response.routes.first else { throw BridgeError(message: "这两个点位之间没有可用的步行路线。") }
                let polyline = route.polyline
                let vertices = polyline.points()
                for vertex in 0..<polyline.pointCount {
                    let coordinate = vertices[vertex].coordinate
                    result.append(gpsPoint(.init(latitude: coordinate.latitude, longitude: coordinate.longitude)))
                }
            }
            walkingPath = result
            walkingRouteMode = routeMode
            fitRequest = UUID()
            status = "已生成沿道路的步行路线。"
        } catch { errorMessage = "步行路线生成失败，原路线已保留。\n" + error.localizedDescription }
    }

    func prepareStartPoint() async {
        guard canPrepareStartPoint, let route, let plan else { return }
        let point = route.sample(distance: 0)
        let phone = selectedUDID
        deviceBusy = true
        sessionVersion += 1
        playbackTask?.cancel()
        playbackTask = nil
        clock.freeze(atElapsed: confirmedElapsed)
        preparedStartPoint = nil; preparedPhone = ""
        errorMessage = nil
        defer { deviceBusy = false }
        do {
            // Keep the entire cleanup/reconnect/set transaction exclusive.
            // A failed cleanup must never be hidden by a fresh simulated position.
            if needsRestore {
                if !deviceConnected {
                    status = "正在重新连接，清理上一轮定位…"
                    bridge.reset()
                    _ = try await bridge.request("connect", ["udid": phone], timeout: 40)
                    deviceConnected = true
                }
                status = "正在清理上一轮定位会话…"
                try await clearLocationSession()
                state = .idle
                sensorRun = false
                currentPoint = nil
                playPlan = nil; playRoute = nil; playProfile = nil
            }
            if !deviceConnected {
                status = "正在连接 USB 定位会话…"
                bridge.reset()
                _ = try await bridge.request("connect", ["udid": phone], timeout: 40)
                deviceConnected = true
            }
            needsRestore = true // A lost set reply still leaves a recovery obligation.
            restoreSent = false
            status = "正在定位到路线起点…"
            let action = useSensorPlayback ? "hold" : "set"
            _ = try await bridge.request(action, ["latitude": point.latitude, "longitude": point.longitude], timeout: 12)
            preparedPhone = phone
            preparedStartPoint = point
            state = .idle
            sensorRun = false
            playPlan = nil; playRoute = nil; playProfile = nil
            clock.freeze(atElapsed: 0)
            currentPoint = point
            confirmedElapsed = 0; travelledMetres = 0; estimatedSteps = 0
            livePaceMinutes = plan.paceMinutes; liveCadence = motionSettings.cadence
            status = "起点指令已发送，位置保持不动。请在手机核对起点，再开始运动记录和移动。"
        } catch {
            preparedStartPoint = nil; preparedPhone = ""
            deviceConnected = false
            errorMessage = "起点定位失败：" + error.localizedDescription
                + (needsRestore ? "\n模拟定位尚未确认清除。可重试定位到起点，或点击恢复真实定位。"
                                : "\n请检查数据线、信任和开发者模式，再重试定位到起点。")
            status = "起点尚未准备完成。"
        }
    }

    private func clearLocationSession() async throws {
        let reply = try await bridge.request("clear", timeout: 30) as? [String: Any]
        guard reply?["restore_sent"] as? Bool == true && reply?["session_closed"] as? Bool == true else {
            throw BridgeError(message: "连接模块没有确认清除指令和会话关闭，请重试恢复定位。")
        }
        needsRestore = false
        deviceConnected = false
        restoreSent = true
        preparedStartPoint = nil; preparedPhone = ""
    }

    func start() {
        guard canStart, let route, let plan else { return }
        motionSeed = UInt64.random(in: 0...UInt64.max)
        if !previewOnly, useSensorPlayback, let profile = sensorProfile {
            startSensorRun(route: route, plan: plan, profile: profile)
            return
        }
        guard let profile = try? MotionProfile(plan: plan, settings: motionSettings, seed: motionSeed) else { return }
        sessionVersion += 1
        preparedStartPoint = nil; preparedPhone = ""
        playRoute = route; playPlan = plan; playProfile = profile; previewSession = previewOnly
        sensorRun = false
        livePaceMinutes = plan.paceMinutes; liveCadence = motionSettings.cadence; estimatedSteps = 0
        restoreSent = false
        confirmedElapsed = 0; travelledMetres = 0; currentPoint = nil
        errorMessage = nil
        state = .running
        // Start the clock after the first acknowledged coordinate, not during connection latency.
        clock.freeze(atElapsed: 0)
        runLoop(version: sessionVersion, initial: true)
    }

    /// Hand the whole planned route to the phone and let Apple's simulation
    /// controller move along it. Fixes are then produced on-device at a steady
    /// one per second with a valid speed field, instead of one raw coordinate
    /// per USB round trip.
    private func startSensorRun(route: Route, plan: MotionPlan, profile: MotionProfile) {
        sessionVersion += 1
        preparedStartPoint = nil; preparedPhone = ""
        playRoute = route; playPlan = plan; playProfile = profile; previewSession = false
        sensorRun = true
        livePaceMinutes = plan.paceMinutes
        liveCadence = motionSettings.cadence
        estimatedSteps = 0
        restoreSent = false
        confirmedElapsed = 0; travelledMetres = 0
        currentPoint = route.sample(distance: 0)
        errorMessage = nil
        state = .running
        clock.freeze(atElapsed: 0)
        let version = sessionVersion
        status = "正在把路线交给手机的定位仿真引擎…"
        locationBusy = true
        Task { [weak self] in
            guard let self else { return }
            var failure: Error?
            do { try await self.sendSensorRoute(from: 0, version: version) } catch { failure = error }
            self.locationBusy = false
            guard version == self.sessionVersion else { return }
            if let failure {
                self.sensorAvailable = false
                self.sensorMode = false
                self.sensorRun = false
                self.playRoute = nil; self.playPlan = nil; self.playProfile = nil
                self.clock.freeze(atElapsed: 0)
                self.state = .idle
                self.errorMessage = "Apple 定位仿真不可用，已改用逐点定位：" + failure.localizedDescription
                await self.prepareStartPoint()
                if self.startPointReady { self.start() }
                return
            }
            self.clock.resume(at: ProcessInfo.processInfo.systemUptime)
            self.status = "Apple 定位仿真 · 手机沿路线连续运动"
            self.tickSensorRun(version: version)
        }
    }

    private func sendSensorRoute(from startMetres: Double, version: Int) async throws {
        guard let plan = playPlan, let route = playRoute else { return }
        let points = sensorWaypoints(route: route, from: startMetres, to: plan.distanceKM * 1000,
                                     speed: plan.speedMetresPerSecond)
        guard points.count >= 2 else { return }
        needsRestore = true
        _ = try await bridge.request("route", [
            "speed": plan.speedMetresPerSecond,
            "waypoints": points.map { ["latitude": $0.latitude, "longitude": $0.longitude] }
        ], timeout: 40)
    }

    /// Waypoints for the on-device engine.
    ///
    /// The phone advances its simulated position at the requested speed and
    /// emits one fix per second, but it also stops at every waypoint until the
    /// next whole second. A spacing that is an exact whole number of seconds of
    /// travel therefore reproduces the planned pace exactly; any other spacing
    /// rounds up and makes the phone slower than planned. The whole number of
    /// seconds grows only when a route would need more points than the worker
    /// accepts.
    func sensorWaypoints(route: Route, from startMetres: Double, to endMetres: Double, speed: Double) -> [GeoPoint] {
        guard endMetres > startMetres, speed.isFinite, speed > 0.05 else { return [] }
        let secondsPerPoint = max(1, ceil((endMetres - startMetres) / speed / 4000))
        let spacing = speed * secondsPerPoint
        var distances: [Double] = []
        var distance = startMetres
        while distance < endMetres - 0.001 {
            distances.append(distance)
            distance += spacing
        }
        distances.append(endMetres)
        return distances.map { route.sample(distance: $0) }
    }

    private func tickSensorRun(version: Int) {
        playbackTask = Task { [weak self] in
            guard let self, let plan = self.playPlan, let profile = self.playProfile else { return }
            defer { if version == self.sessionVersion { self.playbackTask = nil } }
            while (self.state == .running || self.state == .paused) && version == self.sessionVersion && !Task.isCancelled {
                if self.state == .running {
                    let elapsed = min(plan.durationSeconds, self.clock.elapsed(at: ProcessInfo.processInfo.systemUptime))
                    let motion = profile.sample(elapsed: elapsed)
                    if let route = self.playRoute { self.currentPoint = route.sample(distance: motion.distanceMetres) }
                    self.confirmedElapsed = elapsed
                    self.travelledMetres = motion.distanceMetres
                    self.livePaceMinutes = motion.paceMinutes
                    self.liveCadence = motion.cadence
                    self.estimatedSteps = motion.steps
                    if elapsed >= plan.durationSeconds {
                        self.clock.freeze(atElapsed: plan.durationSeconds)
                        self.state = .finished
                        self.status = "路线已完成，手机定位保持在终点。请点击“恢复真实定位”。"
                        return
                    }
                }
                do { try await Task.sleep(nanoseconds: 500_000_000) } catch { return }
            }
        }
    }

    private func runLoop(version: Int, initial: Bool) {
        playbackTask = Task { [weak self] in
            guard let self, let route = self.playRoute, let plan = self.playPlan, let profile = self.playProfile else { return }
            defer { if version == self.sessionVersion { self.playbackTask = nil } }
            var first = initial
            while (self.state == .running || self.state == .paused) && version == self.sessionVersion && !Task.isCancelled {
                if self.state == .paused {
                    do { try await Task.sleep(nanoseconds: 100_000_000) } catch { return }
                    continue
                }
                let clockElapsed = self.clock.elapsed(at: ProcessInfo.processInfo.systemUptime)
                // Waiting for USB or a stalled Mac must never be sent as catch-up movement.
                let elapsed = first ? 0 : min(plan.durationSeconds, self.previewSession ? clockElapsed
                    : self.confirmedElapsed + min(1, max(0, clockElapsed - self.confirmedElapsed)))
                let motion = profile.sample(elapsed: elapsed)
                let distance = motion.distanceMetres
                let point = route.sample(distance: distance)
                do {
                    if !self.previewSession {
                        self.needsRestore = true
                        self.locationBusy = true
                        defer { self.locationBusy = false }
                        _ = try await self.bridge.request("set", ["latitude": point.latitude, "longitude": point.longitude], timeout: 12)
                    }
                    guard version == self.sessionVersion else { return }
                    self.currentPoint = point
                    self.confirmedElapsed = elapsed
                    self.travelledMetres = distance
                    self.livePaceMinutes = motion.paceMinutes
                    self.liveCadence = motion.cadence
                    self.estimatedSteps = motion.steps
                    if first || !self.previewSession {
                        self.clock.freeze(atElapsed: elapsed)
                        if self.state == .running { self.clock.resume(at: ProcessInfo.processInfo.systemUptime) }
                        first = false
                    }
                    if elapsed >= plan.durationSeconds {
                        self.clock.freeze(atElapsed: plan.durationSeconds)
                        self.state = .finished
                        self.status = self.previewSession ? "地图预览已完成。点击“结束预览”可继续编辑。" : "路线已完成，定位保持在终点。请点击“恢复真实定位”。"
                        return
                    }
                    if self.state == .paused {
                        self.clock.freeze(atElapsed: elapsed)
                        self.status = self.previewSession ? "地图预览已暂停。" : "已暂停，iPhone 定位保持在当前点。"
                    } else {
                        self.status = self.previewSession ? "仅地图预览 · 正在沿路线移动" : "iPhone 模拟定位 · 正在沿路线移动"
                    }
                } catch {
                    guard version == self.sessionVersion else { return }
                    self.deviceConnected = false
                    self.pauseAtConfirmedPosition()
                    self.status = "连接中断，已在上一次确认的位置暂停。"
                    self.errorMessage = error.localizedDescription + "\n重新连接后可继续，或恢复真实定位。"
                    return
                }
                do { try await Task.sleep(nanoseconds: 1_000_000_000) }
                catch { return }
            }
        }
    }

    func pause() {
        guard state == .running else { return }
        clock.pause(at: ProcessInfo.processInfo.systemUptime)
        state = .paused
        guard !previewSession else {
            status = "地图预览已暂停。"
            return
        }
        if sensorRun, let point = currentPoint {
            // Pinning the current coordinate stops the phone without releasing
            // the simulation, so the target app never sees the real position.
            let version = sessionVersion
            status = "正在暂停，等待手机停在当前点…"
            locationBusy = true
            Task { [weak self] in
                guard let self else { return }
                var failure: Error?
                do {
                    self.needsRestore = true
                    _ = try await self.bridge.request("hold", ["latitude": point.latitude, "longitude": point.longitude], timeout: 12)
                } catch { failure = error }
                self.locationBusy = false
                guard version == self.sessionVersion else { return }
                if let failure {
                    self.errorMessage = "暂停失败：" + failure.localizedDescription
                    self.status = "已暂停，但未确认手机位置保持。"
                } else {
                    self.status = "已暂停，手机保持在当前点。"
                }
            }
        } else {
            status = locationBusy ? "正在暂停，等待当前定位更新完成…" : "已暂停，iPhone 定位保持在当前点。"
        }
    }

    private func pauseAtConfirmedPosition() {
        clock.freeze(atElapsed: confirmedElapsed)
        state = .paused
    }

    func resume() {
        guard canResume else { return }
        clock.resume(at: ProcessInfo.processInfo.systemUptime)
        state = .running
        errorMessage = nil
        if sensorRun {
            let version = sessionVersion
            let startDistance = travelledMetres
            status = "正在继续 Apple 定位仿真…"
            locationBusy = true
            Task { [weak self] in
                guard let self else { return }
                var failure: Error?
                do { try await self.sendSensorRoute(from: startDistance, version: version) } catch { failure = error }
                self.locationBusy = false
                guard version == self.sessionVersion else { return }
                if let failure {
                    self.clock.pause(at: ProcessInfo.processInfo.systemUptime)
                    self.state = .paused
                    self.errorMessage = "继续失败：" + failure.localizedDescription
                    self.status = "已暂停，手机保持在上一次位置。"
                } else {
                    self.status = "Apple 定位仿真 · 手机沿路线连续运动"
                    if self.playbackTask == nil { self.tickSensorRun(version: version) }
                }
            }
        } else if playbackTask == nil {
            runLoop(version: sessionVersion, initial: false)
        }
    }

    func stop(forceRestore: Bool = false) async {
        guard !deviceBusy else { return }
        sessionVersion += 1
        playbackTask?.cancel()
        playbackTask = nil
        clock.freeze(atElapsed: confirmedElapsed)
        if state == .running { state = .paused }
        deviceBusy = true
        defer { deviceBusy = false }
        if needsRestore || forceRestore {
            guard !selectedUDID.isEmpty else {
                errorMessage = "请先选择需要恢复定位的 USB iPhone。"
                return
            }
            if !deviceConnected {
                guard forceRestore else {
                    errorMessage = "设备未连接，无法确认恢复真实定位。请连接同一台 iPhone 后重试。"
                    return
                }
                do {
                    bridge.reset()
                    _ = try await bridge.request("connect", ["udid": selectedUDID], timeout: 40)
                    deviceConnected = true
                } catch {
                    errorMessage = "恢复前连接失败：" + error.localizedDescription
                    return
                }
            }
            needsRestore = true
            status = "正在清除模拟定位并关闭定位会话…"
            do {
                try await clearLocationSession()
                errorMessage = nil
                status = "清除指令已发送，定位会话已关闭。请在 iPhone 核对；仍不对可再次恢复。"
            } catch {
                errorMessage = "恢复真实定位失败：" + error.localizedDescription
                deviceConnected = false
                return
            }
        } else { status = "预览已结束，可以继续编辑路线。" }
        state = .idle
        sensorRun = false
        currentPoint = nil
        playPlan = nil; playRoute = nil; playProfile = nil
    }

    func shutdown() async throws {
        sessionVersion += 1
        playbackTask?.cancel()
        playbackTask = nil
        clock.freeze(atElapsed: confirmedElapsed)
        if state == .running { state = .paused }
        if needsRestore && !deviceConnected {
            throw BridgeError(message: "iPhone 未连接，无法确认模拟定位已清除。请重新连接并恢复真实定位；必要时重启 iPhone。")
        }
        if bridge.isRunning {
            _ = try await bridge.request("shutdown", ["restore": needsRestore], timeout: 30)
            needsRestore = false
            deviceConnected = false
            bridge.reset()
        }
    }

    func saveRoute() {
        guard canSaveRoute, let plan else { return }
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.json]
        panel.nameFieldStringValue = "我的路线.json"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let saved = SavedRoute(waypoints: waypoints, path: walkingPath, mode: routeMode, distanceKM: plan.distanceKM, paceMinutes: plan.paceMinutes, motion: motionSettings)
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(saved).write(to: url, options: .atomic)
            status = "路线已保存。"
        } catch { errorMessage = error.localizedDescription }
    }

    func openRoute() {
        guard editable else { return }
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.json]; panel.allowsMultipleSelection = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let data = try Data(contentsOf: url)
            guard data.count < 10_000_000 else { throw BridgeError(message: "路线文件过大。") }
            let saved = try JSONDecoder().decode(SavedRoute.self, from: data)
            var repairLegacy = false
            if saved.schema == 1 {
                let alert = NSAlert()
                alert.messageText = "这条路线由旧版保存"
                alert.informativeText = "旧版没有记录地图校正设置。\n如果绘图时“中国大陆地图偏移校正”保持开启，请选择“恢复原来地图选点”，修正几百米的偏移。\n如果当时关闭了校正，或点位是手动输入的 GPS 坐标，请选择“保留 GPS 坐标”。"
                alert.addButton(withTitle: "恢复原来地图选点")
                alert.addButton(withTitle: "保留 GPS 坐标")
                alert.addButton(withTitle: "取消")
                let response = alert.runModal()
                guard response != .alertThirdButtonReturn else { return }
                repairLegacy = response == .alertFirstButtonReturn
            }
            try loadSavedRoute(saved, repairLegacyMapPoints: repairLegacy)
        } catch { errorMessage = "打开路线失败：" + error.localizedDescription }
    }

    func loadSavedRoute(_ saved: SavedRoute, repairLegacyMapPoints: Bool) throws {
        guard editable else { throw BridgeError(message: "请先停止移动并恢复真实定位，再打开路线。") }
        guard (1...4).contains(saved.schema), saved.waypoints.count <= 1000, saved.path.count <= 100_000,
              Set(saved.waypoints.map(\.id)).count == saved.waypoints.count,
              saved.waypoints.allSatisfy({ $0.point.isValid }), saved.path.allSatisfy(\.isValid) else {
            throw BridgeError(message: "路线文件含有无效点位或不支持的格式。")
        }
        let importedPlan = try MotionPlan(distanceKM: saved.distanceKM, paceMinutes: saved.paceMinutes)
        let importedSettings = saved.motion ?? MotionSettings()
        _ = try MotionProfile(plan: importedPlan, settings: importedSettings, seed: motionSeed)
        var points = saved.waypoints
        var vertices = saved.path
        if saved.schema == 1 && repairLegacyMapPoints {
            points = points.map { waypoint in
                var restored = waypoint
                restored.point = MapCoordinates.toGCJ02(waypoint.point)
                return restored
            }
            vertices = vertices.map(MapCoordinates.toGCJ02)
        }
        _ = try Route(points: vertices.isEmpty ? points.map(\.point) : vertices, mode: saved.mode)
        waypoints = points; walkingPath = vertices; walkingRouteMode = saved.mode; routeMode = saved.mode
        distanceKM = saved.distanceKM; paceMinutes = saved.paceMinutes
        motionSettings = importedSettings
        livePaceMinutes = 0; liveCadence = 0; estimatedSteps = 0
        playPlan = nil; playRoute = nil; playProfile = nil
        durationMinutes = saved.distanceKM * saved.paceMinutes; parameterMode = 0
        confirmedElapsed = 0; travelledMetres = 0; currentPoint = nil
        focusedPoint = nil
        fitRequest = UUID()
        status = saved.schema == 1 && repairLegacyMapPoints ? "已恢复旧版地图选点位置。请保存为新版路线，并在 iPhone 上核对。" : "路线已打开。"
    }

    func exportGPX() {
        guard let route, let plan, let profile = playProfile ?? motionProfile else { return }
        let panel = NSSavePanel()
        panel.allowedContentTypes = [UTType(filenameExtension: "gpx") ?? .xml]
        panel.nameFieldStringValue = "我的路线.gpx"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let xml = Self.gpxDocument(route: route, plan: plan, profile: profile, start: Date())
        do { try xml.write(to: url, atomically: true, encoding: .utf8); status = "GPX 已导出，包含路线和时间戳。" }
        catch { errorMessage = error.localizedDescription }
    }

    static func gpxDocument(route: Route, plan: MotionPlan, profile: MotionProfile, start: Date) -> String {
        let count = Int(min(100_000, ceil(plan.durationSeconds)))
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        var xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"RoutePilot\" xmlns=\"http://www.topografix.com/GPX/1/1\" xmlns:rp=\"urn:routepilot:motion:1\"><trk><name>RoutePilot</name><trkseg>\n"
        for index in 0...count {
            let elapsed = plan.durationSeconds * Double(index) / Double(count)
            let motion = profile.sample(elapsed: elapsed)
            let point = route.sample(distance: motion.distanceMetres)
            xml += "<trkpt lat=\"\(point.latitude)\" lon=\"\(point.longitude)\"><time>\(formatter.string(from: start.addingTimeInterval(elapsed)))</time><extensions><rp:cadence unit=\"steps/min\">\(motion.cadence)</rp:cadence><rp:steps>\(floor(motion.steps))</rp:steps></extensions></trkpt>\n"
        }
        xml += "</trkseg></trk></gpx>\n"
        return xml
    }

    func routeModeChanged() {
        if !walkingPath.isEmpty && walkingRouteMode != routeMode {
            walkingPath = []; status = "模式已更改，请重新生成步行路线。"
        }
    }

    static func timeLabel(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "--:--" }
        let value = Int(min(seconds, 3_600_000_000))
        return value >= 3600 ? String(format: "%02d:%02d:%02d", value / 3600, value / 60 % 60, value % 60)
            : String(format: "%02d:%02d", value / 60, value % 60)
    }
}

extension GeoPoint {
    var coordinate: CLLocationCoordinate2D { .init(latitude: latitude, longitude: longitude) }
}
