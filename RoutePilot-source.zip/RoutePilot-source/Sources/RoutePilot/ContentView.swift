import SwiftUI
import MapKit
import RouteCore

private let accent = Color(red: 0.05, green: 0.57, blue: 0.52)

struct ContentView: View {
    @ObservedObject var model: AppModel
    @State private var editingWaypoint: Waypoint?
    @State private var blockedMapAreas: [CGRect] = []

    var body: some View {
        HStack(spacing: 0) {
            sidebar.frame(width: 338)
            Divider()
            ZStack(alignment: .topLeading) {
                RouteMap(model: model, blockedAreas: blockedMapAreas)
                Image(systemName: "plus").font(.system(size: 24, weight: .light))
                    .foregroundStyle(.white).shadow(color: .black, radius: 1)
                    .frame(maxWidth: .infinity, maxHeight: .infinity).allowsHitTesting(false)
                VStack(alignment: .leading, spacing: 12) {
                    searchPanel.excludeMapClicks()
                    mapTools.excludeMapClicks()
                    if model.waypoints.isEmpty {
                        Label("点击地图，添加你的第一个点位", systemImage: "mappin.and.ellipse")
                            .font(.callout).padding(12).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                            .excludeMapClicks()
                    }
                    Spacer()
                    if model.previewOnly {
                        Label("仅地图预览 · 不更改 iPhone 定位", systemImage: "eye")
                            .font(.callout.weight(.medium)).padding(11)
                            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                            .excludeMapClicks()
                    }
                    mapStatus.excludeMapClicks()
                }.padding(20)
            }
            .coordinateSpace(name: "routeMap")
            .onPreferenceChange(MapControlBounds.self) { blockedMapAreas = $0 }
        }
        .frame(minWidth: 1000, minHeight: 720)
        .tint(accent)
        .sheet(isPresented: $model.showHelp) { helpSheet }
        .sheet(item: $editingWaypoint) { waypoint in
            WaypointEditor(model: model, waypoint: waypoint)
        }
        .task {
            AppDelegate.model = model
            await model.refreshDevices()
        }
    }

    private var sidebar: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "point.topleft.down.to.point.bottomright.curvepath")
                    .font(.system(size: 24, weight: .medium)).foregroundStyle(accent)
                    .frame(width: 42, height: 42).background(accent.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 2) {
                    Text("路行").font(.title2.bold())
                    Text("RoutePilot · iPhone 定位模拟").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Button { model.showHelp = true } label: { Image(systemName: "questionmark.circle") }
                    .buttonStyle(.plain).help("使用说明")
            }.padding(20)
            Divider()
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    deviceSection
                    routeSection
                    parameterSection
                }.padding(20)
            }
            Divider()
            playbackControls.padding(20)
        }
        .background(Color(nsColor: .windowBackgroundColor))
    }

    private func sectionTitle(_ title: String, icon: String, trailing: String? = nil) -> some View {
        HStack {
            Label(title, systemImage: icon).font(.headline)
            Spacer()
            if let trailing { Text(trailing).font(.caption).foregroundStyle(.secondary) }
        }
    }

    private var deviceSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("连接设备", icon: "cable.connector", trailing: "USB")
            HStack {
                Circle().fill(model.deviceConnected ? accent : Color.secondary.opacity(0.5)).frame(width: 7, height: 7)
                Text(model.deviceConnected ? "定位会话已连接" : "未连接定位会话").font(.subheadline)
                Spacer()
                if model.deviceBusy { ProgressView().controlSize(.small) }
                Button { Task { await model.refreshDevices() } } label: { Image(systemName: "arrow.clockwise") }
                    .buttonStyle(.plain).disabled(model.deviceBusy || model.state == .running).help("刷新 USB 设备")
            }
            Picker("iPhone", selection: $model.selectedUDID) {
                Text("选择 USB iPhone").tag("")
                ForEach(model.phones) { phone in
                    Text(phone.name + (phone.version.isEmpty ? "" : " · iOS " + phone.version)).tag(phone.udid)
                }
                if !model.selectedUDID.isEmpty && !model.phones.contains(where: { $0.udid == model.selectedUDID }) {
                    Text("此前的 iPhone（请重新连接）").tag(model.selectedUDID)
                }
            }.labelsHidden().disabled(model.deviceBusy || model.active || model.deviceConnected || model.needsRestore)
            HStack {
                Button("准备设备") { Task { await model.prepareDevice() } }
                    .disabled(model.selectedUDID.isEmpty || model.deviceBusy || model.deviceConnected)
                if model.deviceConnected {
                    Button("断开") { Task { await model.disconnectDevice() } }
                        .disabled(model.deviceBusy || model.active || model.needsRestore)
                } else {
                    Button("连接") { Task { await model.connectDevice() } }
                        .disabled(model.selectedUDID.isEmpty || model.deviceBusy)
                }
            }.controlSize(.large)
            Text("首次连接：解锁并信任此电脑，开启开发者模式，然后准备设备。")
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            Button(model.restoreSent ? "再次恢复定位" : "恢复真实定位") {
                Task { await model.stop(forceRestore: true) }
            }.disabled(model.selectedUDID.isEmpty || model.deviceBusy)
            if model.restoreSent {
                Text("清除指令已发送，会话已关闭。请在 iPhone 地图点击当前位置核对。")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            Toggle("仅地图预览", isOn: $model.previewOnly).disabled(!model.editable)
            if !model.previewOnly {
                Divider()
                Toggle("运动传感器仿真（Apple 定位引擎）", isOn: $model.sensorMode)
                    .disabled(!model.editable || !model.sensorAvailable)
                Text(model.sensorAvailable
                     ? "把整条路线交给手机自带的定位仿真引擎（与 Apple 模拟器的“City Run”同一套），手机每秒生成一个带速度字段的定位，不再逐条发送坐标。"
                     : "连接 iPhone 后可用；需要先“准备设备”并挂载开发者组件。")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var routeSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("地图路线", icon: "point.3.connected.trianglepath.dotted", trailing: "\(model.waypoints.count) 个点")
            if model.waypoints.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("在右侧地图上点击添加点位，或搜索地点。").font(.subheadline).foregroundStyle(.secondary)
                    Button("载入示例路线") { model.loadExample() }.disabled(!model.editable)
                }.padding(12).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.primary.opacity(0.035), in: RoundedRectangle(cornerRadius: 10))
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(model.waypoints.enumerated()), id: \.element.id) { index, waypoint in
                        HStack(spacing: 8) {
                            Text("\(index + 1)").font(.caption.bold()).foregroundStyle(accent)
                                .frame(width: 23, height: 23).background(accent.opacity(0.12), in: Circle())
                            VStack(alignment: .leading, spacing: 3) {
                                Text(waypoint.name).font(.subheadline).lineLimit(1)
                                Text(String(format: "%.6f, %.6f", waypoint.point.latitude, waypoint.point.longitude))
                                    .font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary)
                            }.onTapGesture { model.focusPoint(waypoint.point) }
                            Spacer(minLength: 0)
                            Button { editingWaypoint = waypoint } label: { Image(systemName: "scope").font(.system(size: 12)) }
                                .buttonStyle(.plain).disabled(!model.editable).help("精确编辑经纬度")
                            VStack(spacing: 3) {
                                Button { model.movePoint(id: waypoint.id, offset: -1) } label: { Image(systemName: "chevron.up").font(.system(size: 9)) }
                                    .disabled(!model.editable || index == 0).help("上移点位")
                                Button { model.movePoint(id: waypoint.id, offset: 1) } label: { Image(systemName: "chevron.down").font(.system(size: 9)) }
                                    .disabled(!model.editable || index == model.waypoints.count - 1).help("下移点位")
                            }.buttonStyle(.plain)
                            Button { model.removePoint(id: waypoint.id) } label: { Image(systemName: "xmark").font(.system(size: 10)) }
                                .buttonStyle(.plain).disabled(!model.editable).help("删除点位")
                        }.padding(.vertical, 9)
                        if index < model.waypoints.count - 1 { Divider() }
                    }
                }.padding(.horizontal, 10).background(Color.primary.opacity(0.035), in: RoundedRectangle(cornerRadius: 10))
            }
            HStack {
                Text("路线长度").foregroundStyle(.secondary)
                Spacer()
                Text(String(format: "%.3f km", model.routeLengthKM)).fontWeight(.semibold).monospacedDigit()
            }.font(.subheadline)
            Picker("重复方式", selection: $model.routeMode) {
                Text("往返").tag(RouteMode.bounce)
                Text("闭合循环").tag(RouteMode.loop)
            }.pickerStyle(.segmented).disabled(!model.editable)
                .onChange(of: model.routeMode) { model.routeModeChanged() }
            Text(model.routeMode == .bounce ? "到达终点后沿原路返回，直到达到目标距离。" : "连接终点与起点，沿闭合路线循环。")
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            HStack {
                Button(model.routingBusy ? "规划中…" : "沿道路步行") { Task { await model.generateWalkingRoute() } }
                    .disabled(!model.editable || model.waypoints.count < 2)
                Button("直线连接") { model.walkingPath = [] }.disabled(!model.editable || model.walkingPath.isEmpty)
                Spacer()
                Button { model.fitRequest = UUID() } label: { Image(systemName: "arrow.up.left.and.arrow.down.right") }
                    .help("显示整条路线").disabled(model.waypoints.isEmpty)
            }
            HStack {
                Button("打开") { model.openRoute() }.disabled(!model.editable)
                Button("保存") { model.saveRoute() }.disabled(!model.canSaveRoute)
                Button("GPX") { model.exportGPX() }.disabled(!model.canSaveRoute)
                Spacer()
                Button("清空") { model.clearRoute() }.disabled(!model.editable || model.waypoints.isEmpty)
            }.font(.caption)
            Text("地图选点直接对应模拟位置。旧版路线打开时可恢复原来选点。")
                .font(.system(size: 10)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
    }

    private var parameterSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionTitle("运动参数", icon: "figure.run")
            Picker("设置方式", selection: $model.parameterMode) {
                Text("距离 + 完成时间").tag(1)
                Text("距离 + 配速").tag(0)
            }.pickerStyle(.segmented).disabled(!model.editable)
                .onChange(of: model.parameterMode) { _, new in
                    if new == 1 { model.durationMinutes = model.distanceKM * model.paceMinutes }
                    else if model.distanceKM > 0 { model.paceMinutes = model.durationMinutes / model.distanceKM }
                }
            numberInput("目标距离", value: $model.distanceKM, unit: "公里")
            if model.parameterMode == 0 {
                numberInput("配速", value: $model.paceMinutes, unit: "分/公里")
            } else {
                numberInput("完成时间", value: $model.durationMinutes, unit: "分钟")
            }
            Text(model.parameterMode == 1
                 ? "只填这两项即可：配速、步频、步幅、步数、爬升都由下面自动生成，也可以逐项覆盖。"
                 : "配速与距离决定用时；步频、步幅、步数、爬升由下面自动生成，也可以逐项覆盖。")
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            Divider()
            HStack {
                Label("步态与爬升", systemImage: "figure.walk.motion").font(.subheadline.weight(.medium))
                Spacer()
                Text("自动 / 手动").font(.caption).foregroundStyle(.secondary)
            }
            let metrics = model.humanMetrics
            autoNumberInput("步频", value: $model.motionSettings.cadence,
                            automatic: $model.motionSettings.cadenceAutomatic,
                            derived: metrics?.cadence ?? 0, unit: "步/分")
            autoNumberInput("步幅", value: $model.motionSettings.strideMetres,
                            automatic: $model.motionSettings.strideAutomatic,
                            derived: metrics?.strideMetres ?? 0, unit: "米")
            autoNumberInput("步数", value: $model.motionSettings.steps,
                            automatic: $model.motionSettings.stepsAutomatic,
                            derived: metrics?.steps ?? 0, unit: "步")
            autoNumberInput("爬升", value: $model.motionSettings.climbMetres,
                            automatic: $model.motionSettings.climbAutomatic,
                            derived: metrics?.climbMetres ?? 0, unit: "米")
            if let metrics {
                VStack(alignment: .leading, spacing: 4) {
                    Text("自动生成的这次跑步").font(.caption.bold())
                    Text(String(format: "配速 %@ /km · 用时 %@", AppModel.timeLabel(metrics.paceMinutes * 60),
                                AppModel.timeLabel(metrics.durationSeconds)))
                    Text(String(format: "步频 %.0f 步/分 · 步幅 %.2f 米 · 步数 %.0f 步 · 爬升 %.0f 米",
                                metrics.cadence, metrics.strideMetres, metrics.steps, metrics.climbMetres))
                }
                .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(9).frame(maxWidth: .infinity, alignment: .leading)
                .background(accent.opacity(0.07), in: RoundedRectangle(cornerRadius: 8))
            }
            if let warning = model.motionWarning {
                Text(warning).font(.caption).foregroundStyle(.orange).fixedSize(horizontal: false, vertical: true)
            }
            Toggle("模拟真人波动", isOn: $model.motionSettings.humanVariation).disabled(!model.editable)
            if model.motionSettings.humanVariation {
                numberInput("配速波动 ±", value: $model.motionSettings.paceVariationSeconds, unit: "秒/公里")
                numberInput("步频波动 ±", value: $model.motionSettings.cadenceVariation, unit: "步/分钟")
                Text("围绕设定值缓慢变化，保持目标时间和距离；步幅随步频与配速同步变化。")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            if model.motionSettings.humanVariation && !model.previewOnly && model.sensorMode {
                Text("传感器仿真使用恒定配速；关闭本模式才会应用配速波动。")
                    .font(.caption).foregroundStyle(.orange).fixedSize(horizontal: false, vertical: true)
            }
            Text("步频、步幅、步数、爬升是本程序算出的记录值，不会进入 iPhone 的运动传感器；手机只接收配速。")
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            VStack(alignment: .leading, spacing: 2) {
                Label("手机端步频要靠手机自身运动产生", systemImage: "iphone.gen3.radiowaves.left.and.right")
                    .font(.caption.bold())
                Text("开始移动后请让手机持续晃动（摇步器、跑步机、装在口袋里跑），系统计步才会给出步频。程序无法代替运动传感器写入步数。")
            }
            .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            .padding(9).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 8))
            Button("使用路线长度作为目标距离") { model.useRouteDistance() }
                .font(.caption).disabled(!model.editable || model.routeLengthKM <= 0)
            HStack {
                Text(model.parameterMode == 0 ? "计划运动用时" : "计算配速").foregroundStyle(.secondary)
                Spacer()
                Text(model.parameterMode == 0 ? AppModel.timeLabel(model.effectiveDuration * 60)
                     : AppModel.timeLabel(model.effectivePace * 60) + " /km")
                    .fontWeight(.semibold).monospacedDigit()
            }.font(.subheadline).padding(11).background(accent.opacity(0.08), in: RoundedRectangle(cornerRadius: 9))
            if !model.previewOnly {
                Text("连接较慢时完成时间会延长，不会突然加速补进度。")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    /// A number that is generated automatically unless the user turns the
    /// switch off; while it is automatic the field simply shows the generated value.
    private func autoNumberInput(_ label: String, value: Binding<Double>, automatic: Binding<Bool>,
                                 derived: Double, unit: String) -> some View {
        HStack {
            Text(label).font(.subheadline)
            Spacer()
            Toggle("自动", isOn: automatic).toggleStyle(.switch).controlSize(.mini)
                .disabled(!model.editable).help("关闭后可手动填写")
            TextField(label, value: Binding(get: { automatic.wrappedValue ? derived : value.wrappedValue },
                                            set: { value.wrappedValue = $0 }),
                      format: .number.precision(.fractionLength(0...2)))
                .textFieldStyle(.roundedBorder).multilineTextAlignment(.trailing).frame(width: 78)
                .disabled(!model.editable || automatic.wrappedValue)
            Text(unit).font(.caption).foregroundStyle(.secondary).frame(width: 46, alignment: .trailing)
        }
    }

    private func numberInput(_ label: String, value: Binding<Double>, unit: String) -> some View {
        HStack {
            Text(label).font(.subheadline)
            Spacer()
            TextField(label, value: value, format: .number.precision(.fractionLength(0...3)))
                .textFieldStyle(.roundedBorder).multilineTextAlignment(.trailing).frame(width: 85)
                .disabled(!model.editable)
            Text(unit).font(.caption).foregroundStyle(.secondary).frame(width: 48, alignment: .trailing)
        }
    }

    private var playbackControls: some View {
        VStack(spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(String(format: "%.3f", model.travelledMetres / 1000)).font(.system(size: 27, weight: .semibold, design: .rounded)).monospacedDigit()
                    Text("已移动 · 公里").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 3) {
                    Text(AppModel.timeLabel(model.confirmedElapsed)).font(.system(size: 24, weight: .medium, design: .rounded)).monospacedDigit()
                    Text("运动时间").font(.caption).foregroundStyle(.secondary)
                }
            }
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(AppModel.timeLabel((model.state == .idle ? model.effectivePace : model.livePaceMinutes) * 60))
                        .monospacedDigit().fontWeight(.medium)
                    Text("当前配速 /km").font(.system(size: 10)).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(spacing: 2) {
                    Text(String(format: "%.0f", model.state == .idle ? model.motionSettings.cadence : model.liveCadence))
                        .monospacedDigit().fontWeight(.medium)
                    Text("计划步频 /min").font(.system(size: 10)).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text(String(format: "%.0f", floor(model.estimatedSteps))).monospacedDigit().fontWeight(.medium)
                    Text("预计步数").font(.system(size: 10)).foregroundStyle(.secondary)
                }
            }.font(.subheadline)
            if !model.previewOnly {
                Text(model.sensorMode && model.sensorAvailable
                     ? "手机定位由 Apple 仿真引擎在机内生成；步频与预计步数仍是本程序的模拟指标，不会进入手机的运动传感器。"
                     : "USB 仅发送定位；计划步频和预计步数不会传入手机的运动传感器。")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                if model.state == .running, model.liveCadence > 0 {
                    Text(String(format: "目标步频 %.0f 步/分：请同时让手机自身持续运动，系统计步才会给出步频。", model.liveCadence))
                        .font(.caption).foregroundStyle(.orange).fixedSize(horizontal: false, vertical: true)
                }
            }
            ProgressView(value: model.progress)
            if !model.previewOnly && (model.state == .idle || model.state == .finished) {
                Button(model.startPointReady ? "起点已定位" : "定位到起点") {
                    Task { await model.prepareStartPoint() }
                }.disabled(!model.canPrepareStartPoint).controlSize(.large)
                Text(model.startPointReady
                     ? "请在手机核对起点，再开始运动记录，然后点击开始移动。"
                     : "先结束手机的上一条运动记录，再定位到起点；程序会自动重连。")
                    .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                Text(model.sensorMode && model.sensorAvailable
                     ? "开始移动后，整条路线由手机自带的定位仿真引擎播放；暂停会把手机固定在当前点。"
                     : "开始移动后，程序每秒向手机写入一个坐标。")
                    .font(.system(size: 10)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            HStack(spacing: 8) {
                if model.state == .running {
                    Button { model.pause() } label: { Label("暂停", systemImage: "pause.fill").frame(maxWidth: .infinity) }
                        .buttonStyle(.borderedProminent).controlSize(.large)
                } else if model.state == .paused {
                    Button { model.resume() } label: { Label("继续", systemImage: "play.fill").frame(maxWidth: .infinity) }
                        .buttonStyle(.borderedProminent).controlSize(.large).disabled(!model.canResume)
                } else {
                    Button { model.start() } label: { Label(model.previewOnly ? "开始预览" : "开始移动", systemImage: "play.fill").frame(maxWidth: .infinity) }
                        .buttonStyle(.borderedProminent).controlSize(.large).disabled(!model.canStart)
                }
                Button { Task { await model.stop() } } label: { Image(systemName: "stop.fill") }
                    .controlSize(.large).disabled(model.state == .idle && !model.needsRestore || model.deviceBusy).help("停止并恢复真实定位")
            }
            if model.needsRestore || model.state == .finished {
                Button(model.needsRestore ? "恢复真实定位" : "结束预览") { Task { await model.stop(forceRestore: model.needsRestore) } }
                    .font(.subheadline.weight(.medium)).disabled(model.deviceBusy)
            }
            if model.route != nil, let error = model.motionError {
                Text(error)
                    .font(.caption).foregroundStyle(.red)
            }
        }
    }

    private var searchPanel: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("搜索城市、地点或地址", text: $model.searchText)
                    .textFieldStyle(.plain).onSubmit { Task { await model.searchPlaces() } }
                if model.searching { ProgressView().controlSize(.small) }
                Button("搜索") { Task { await model.searchPlaces() } }.disabled(model.searching || !model.editable)
            }.padding(12)
            if !model.searchResults.isEmpty {
                Divider()
                ForEach(Array(model.searchResults.enumerated()), id: \.offset) { _, item in
                    Button { model.selectSearchResult(item) } label: {
                        HStack {
                            Image(systemName: "mappin")
                            VStack(alignment: .leading) {
                                Text(item.name ?? "地点")
                                Text(item.placemark.title ?? "").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            Image(systemName: "plus.circle").foregroundStyle(accent)
                        }.padding(10).contentShape(Rectangle())
                    }.buttonStyle(.plain).disabled(!model.editable)
                }
            }
        }.frame(width: 430).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 13))
            .overlay(RoundedRectangle(cornerRadius: 13).stroke(Color.primary.opacity(0.08)))
    }

    private var mapTools: some View {
        VStack(alignment: .leading, spacing: 8) {
            Picker("地图图层", selection: $model.mapLayer) {
                ForEach(MapLayer.allCases) { layer in Text(layer.rawValue).tag(layer) }
            }.pickerStyle(.segmented)
            HStack {
                Button { if let point = model.mapCenterPoint { model.addPoint(point) } } label: {
                    Label("在中心添加点位", systemImage: "plus.viewfinder")
                }.disabled(!model.editable || model.mapCenterPoint == nil)
                Spacer()
                Text("对准十字准星后添加").font(.caption).foregroundStyle(.secondary)
            }
        }.padding(10).frame(width: 410)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
    }

    private var mapStatus: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top) {
                Image(systemName: model.state == .running ? "location.fill" : "info.circle").foregroundStyle(accent)
                Text(model.status).font(.callout)
                Spacer()
            }
            if let error = model.errorMessage {
                HStack(alignment: .top) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                    Text(error).font(.caption).textSelection(.enabled).lineLimit(6)
                    Spacer()
                    Button { model.errorMessage = nil } label: { Image(systemName: "xmark") }.buttonStyle(.plain)
                }
            }
            if let point = model.currentPoint {
                Text(String(format: "WGS-84  %.6f, %.6f", point.latitude, point.longitude))
                    .font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary).textSelection(.enabled)
            }
        }.padding(14).frame(maxWidth: .infinity, alignment: .leading)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 13))
    }

    private var helpSheet: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { Text("使用路行").font(.title2.bold()); Spacer(); Button("完成") { model.showHelp = false } }
            Text("1. 用数据线连接 iPhone，解锁后选择“信任此电脑”。\n2. 在“设置 → 隐私与安全性”开启开发者模式，按手机提示重启并确认。\n3. 点击刷新，选择 iPhone，点击“准备设备”；首次下载组件需要联网。\n4. 点击“连接”，关闭“仅地图预览”。\n5. 搜索或点击地图添加点位，拖动图钉调整；也可规划步行路线。\n6. 设置配速、距离或时长，先点击“定位到起点”，再点击“开始移动”。\n7. 保持“运动传感器仿真”开启时，路线由手机自带的定位仿真引擎播放，定位带真实速度字段；关闭它则逐点发送坐标。\n8. 用完点击“恢复真实定位”。")
                .font(.body).lineSpacing(8)
            Divider()
            Text("暂停会保持当前位置。路线结束会保持终点，直到恢复真实定位。断线时重新连接同一台手机后再恢复；如仍无法恢复，可重启 iPhone。")
                .foregroundStyle(.secondary)
            Text("手机计步来自运动协处理器，USB 开发者服务没有写入步数或步频的接口；如果目标软件要求步频，需要让手机真的动起来。")
                .font(.caption).foregroundStyle(.secondary)
            Text("此构建面向 Apple Silicon Mac 和 iOS 17.4+。iOS 27.0.1 尚未在你的手机上验证；目标应用是否采纳模拟位置，需要实际测试。")
                .font(.caption).foregroundStyle(.secondary)
        }.padding(26).frame(width: 580)
    }
}

private struct MapControlBounds: PreferenceKey {
    static var defaultValue: [CGRect] = []
    static func reduce(value: inout [CGRect], nextValue: () -> [CGRect]) { value.append(contentsOf: nextValue()) }
}

private extension View {
    func excludeMapClicks() -> some View {
        background(GeometryReader { proxy in
            Color.clear.preference(key: MapControlBounds.self, value: [proxy.frame(in: .named("routeMap"))])
        })
    }
}

private struct WaypointEditor: View {
    @ObservedObject var model: AppModel
    let waypoint: Waypoint
    @Environment(\.dismiss) private var dismiss
    @State private var latitude: String
    @State private var longitude: String

    init(model: AppModel, waypoint: Waypoint) {
        self.model = model; self.waypoint = waypoint
        _latitude = State(initialValue: String(format: "%.6f", waypoint.point.latitude))
        _longitude = State(initialValue: String(format: "%.6f", waypoint.point.longitude))
    }

    private var point: GeoPoint? {
        guard let lat = Double(latitude.trimmingCharacters(in: .whitespacesAndNewlines)),
              let lon = Double(longitude.trimmingCharacters(in: .whitespacesAndNewlines)) else { return nil }
        let value = GeoPoint(latitude: lat, longitude: lon)
        return value.isValid ? value : nil
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("精确调整点位").font(.title2.bold())
            Text(waypoint.name).foregroundStyle(.secondary)
            Text("输入 GPS 经纬度（WGS-84）。地图选点与模拟位置使用同一坐标；小数位数不代表实际定位精度。")
                .font(.caption).foregroundStyle(.secondary)
            HStack { Text("纬度").frame(width: 45, alignment: .leading); TextField("-90 至 90", text: $latitude).textFieldStyle(.roundedBorder) }
            HStack { Text("经度").frame(width: 45, alignment: .leading); TextField("-180 至 180", text: $longitude).textFieldStyle(.roundedBorder) }
            if point == nil { Text("请输入有效的纬度（±90）和经度（±180）。").font(.caption).foregroundStyle(.red) }
            HStack {
                Spacer()
                Button("取消") { dismiss() }.keyboardShortcut(.cancelAction)
                Button("应用并放大") {
                    guard let point, model.editable else { return }
                    model.updatePoint(id: waypoint.id, point: point)
                    model.focusPoint(point)
                    dismiss()
                }.keyboardShortcut(.defaultAction).disabled(point == nil || !model.editable)
            }
        }.padding(24).frame(width: 420)
    }
}
