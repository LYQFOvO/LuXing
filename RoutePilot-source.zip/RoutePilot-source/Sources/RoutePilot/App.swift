import SwiftUI
import AppKit

@main struct RoutePilotApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var model = AppModel()

    var body: some Scene {
        WindowGroup("路行 RoutePilot") {
            ContentView(model: model)
        }.defaultSize(width: 1200, height: 850)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("打开路线…") { model.openRoute() }.keyboardShortcut("o").disabled(!model.editable)
                Button("保存路线…") { model.saveRoute() }.keyboardShortcut("s").disabled(!model.canSaveRoute)
                Button("导出 GPX…") { model.exportGPX() }.disabled(!model.canSaveRoute)
            }
            CommandGroup(replacing: .help) { Button("路行使用说明") { model.showHelp = true } }
        }
    }
}

@MainActor final class AppDelegate: NSObject, NSApplicationDelegate {
    static weak var model: AppModel?
    private var terminating = false

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard let model = Self.model else { return .terminateNow }
        if terminating { return .terminateLater }
        terminating = true
        Task {
            do {
                try await model.shutdown()
                sender.reply(toApplicationShouldTerminate: true)
            } catch {
                let alert = NSAlert()
                alert.messageText = "无法确认 iPhone 已恢复真实定位"
                alert.informativeText = error.localizedDescription
                alert.addButton(withTitle: "取消退出")
                alert.addButton(withTitle: "仍然退出")
                let quit = alert.runModal() == .alertSecondButtonReturn
                if quit { model.bridge.reset() }
                terminating = false
                sender.reply(toApplicationShouldTerminate: quit)
            }
        }
        return .terminateLater
    }
}
