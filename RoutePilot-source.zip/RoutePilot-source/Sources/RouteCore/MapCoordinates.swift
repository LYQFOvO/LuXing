import Foundation

/// Approximate GCJ-02 conversion retained for explicit recovery of schema 1 routes.
/// Never apply to live MapKit coordinates: the SDK handles the provider internally.
/// Mathematical reference: https://github.com/wandergis/coordtransform (MIT).
public enum MapCoordinates {
    private static let axis = 6_378_245.0
    private static let eccentricity = 0.006693421622965943

    private static func applies(_ point: GeoPoint) -> Bool {
        point.longitude >= 72.004 && point.longitude <= 137.8347
            && point.latitude >= 0.8293 && point.latitude <= 55.8271
    }

    public static func toGCJ02(_ point: GeoPoint) -> GeoPoint {
        guard point.isValid, applies(point) else { return point }
        let x = point.longitude - 105, y = point.latitude - 35
        var lat = -100 + 2*x + 3*y + 0.2*y*y + 0.1*x*y + 0.2*sqrt(abs(x))
        var lon = 300 + x + 2*y + 0.1*x*x + 0.1*x*y + 0.1*sqrt(abs(x))
        let common = (20*sin(6*x * .pi) + 20*sin(2*x * .pi)) * 2/3
        lat += common + (20*sin(y * .pi) + 40*sin(y * .pi/3)) * 2/3
        lat += (160*sin(y * .pi/12) + 320*sin(y * .pi/30)) * 2/3
        lon += common + (20*sin(x * .pi) + 40*sin(x * .pi/3)) * 2/3
        lon += (150*sin(x * .pi/12) + 300*sin(x * .pi/30)) * 2/3
        let rad = point.latitude * .pi / 180
        let magic = 1 - eccentricity * pow(sin(rad), 2)
        let root = sqrt(magic)
        lat = lat * 180 / ((axis * (1 - eccentricity)) / (magic * root) * .pi)
        lon = lon * 180 / (axis / root * cos(rad) * .pi)
        return .init(latitude: point.latitude + lat, longitude: point.longitude + lon)
    }

    public static func toWGS84(_ point: GeoPoint) -> GeoPoint {
        guard point.isValid, applies(point) else { return point }
        var estimate = point
        for _ in 0..<12 {
            let projected = toGCJ02(estimate)
            let latError = projected.latitude - point.latitude
            let lonError = projected.longitude - point.longitude
            estimate.latitude -= latError
            estimate.longitude -= lonError
            if max(abs(latError), abs(lonError)) < 1e-10 { break }
        }
        return estimate
    }
}
