import Foundation

public struct PlaybackClock: Sendable {
    private var accumulated = 0.0
    private var startedAt: Double?

    public init() {}
    public mutating func start(at instant: Double) {
        accumulated = 0
        startedAt = instant
    }
    public func elapsed(at instant: Double) -> Double {
        accumulated + (startedAt.map { max(0, instant - $0) } ?? 0)
    }
    public mutating func pause(at instant: Double) {
        accumulated = elapsed(at: instant)
        startedAt = nil
    }
    public mutating func resume(at instant: Double) {
        if startedAt == nil { startedAt = instant }
    }
    public mutating func freeze(atElapsed elapsed: Double) {
        accumulated = max(0, elapsed)
        startedAt = nil
    }
}
