import Foundation

public struct GeoPoint: Codable, Equatable, Sendable {
    public var latitude: Double
    public var longitude: Double

    public init(latitude: Double, longitude: Double) {
        self.latitude = latitude
        self.longitude = longitude
    }

    public var isValid: Bool {
        latitude.isFinite && longitude.isFinite && abs(latitude) <= 90 && abs(longitude) <= 180
    }

    public func distance(to other: GeoPoint) -> Double {
        let p1 = latitude * .pi / 180, p2 = other.latitude * .pi / 180
        let dp = p2 - p1, dl = (other.longitude - longitude) * .pi / 180
        let h = pow(sin(dp / 2), 2) + cos(p1) * cos(p2) * pow(sin(dl / 2), 2)
        return 6_371_008.8 * 2 * atan2(sqrt(max(0, min(1, h))), sqrt(max(0, 1 - h)))
    }

    public func interpolated(to other: GeoPoint, fraction: Double) -> GeoPoint {
        if fraction <= 0 { return self }
        if fraction >= 1 { return other }
        let p1 = latitude * .pi / 180, l1 = longitude * .pi / 180
        let p2 = other.latitude * .pi / 180, l2 = other.longitude * .pi / 180
        let v1 = (cos(p1) * cos(l1), cos(p1) * sin(l1), sin(p1))
        let v2 = (cos(p2) * cos(l2), cos(p2) * sin(l2), sin(p2))
        let angle = acos(max(-1, min(1, v1.0 * v2.0 + v1.1 * v2.1 + v1.2 * v2.2)))
        if abs(sin(angle)) < 1e-10 {
            let delta = (other.longitude - longitude + 540).truncatingRemainder(dividingBy: 360) - 180
            let lon = (longitude + fraction * delta + 540).truncatingRemainder(dividingBy: 360) - 180
            return GeoPoint(latitude: latitude + fraction * (other.latitude - latitude), longitude: lon)
        }
        let a = sin((1 - fraction) * angle) / sin(angle), b = sin(fraction * angle) / sin(angle)
        let x = a * v1.0 + b * v2.0, y = a * v1.1 + b * v2.1, z = a * v1.2 + b * v2.2
        return GeoPoint(latitude: atan2(z, hypot(x, y)) * 180 / .pi, longitude: atan2(y, x) * 180 / .pi)
    }
}

public enum RouteMode: String, Codable, CaseIterable, Sendable {
    case bounce, loop
}

public enum RouteError: LocalizedError {
    case invalidRoute, invalidParameters
    public var errorDescription: String? {
        switch self {
        case .invalidRoute: return "至少添加两个不同的有效点位。"
        case .invalidParameters: return "配速、距离和时间必须是大于零的有限数值。"
        }
    }
}

public struct Route: Sendable {
    public let points: [GeoPoint]
    public let mode: RouteMode
    public let length: Double
    private let cumulative: [Double]

    public init(points: [GeoPoint], mode: RouteMode) throws {
        guard points.count >= 2, points.allSatisfy(\.isValid) else { throw RouteError.invalidRoute }
        var path = points
        if mode == .loop, path.first != path.last { path.append(path[0]) }
        var lengths = [0.0]
        for index in 1..<path.count {
            lengths.append(lengths.last! + path[index - 1].distance(to: path[index]))
        }
        guard let total = lengths.last, total.isFinite, total > 0.001 else { throw RouteError.invalidRoute }
        self.points = path
        self.mode = mode
        self.length = total
        self.cumulative = lengths
    }

    public func sample(distance: Double) -> GeoPoint {
        let d = distance.isFinite ? max(0, distance) : 0
        var local = d.truncatingRemainder(dividingBy: mode == .loop ? length : 2 * length)
        if mode == .bounce, local > length { local = 2 * length - local }
        if local <= 0 { return points[0] }
        if local >= length { return points.last! }
        // Binary search matters for walking routes containing thousands of vertices.
        var low = 1, high = cumulative.count - 1
        while low < high {
            let middle = (low + high) / 2
            if cumulative[middle] < local { low = middle + 1 } else { high = middle }
        }
        let segment = cumulative[low] - cumulative[low - 1]
        guard segment > 0 else { return points[low] }
        return points[low - 1].interpolated(to: points[low], fraction: (local - cumulative[low - 1]) / segment)
    }
}

public struct MotionPlan: Sendable {
    public let distanceKM: Double
    public let paceMinutes: Double
    public var durationSeconds: Double { distanceKM * paceMinutes * 60 }
    public var speedMetresPerSecond: Double { 1000 / (paceMinutes * 60) }

    public init(distanceKM: Double, paceMinutes: Double) throws {
        guard distanceKM.isFinite, paceMinutes.isFinite, distanceKM > 0, paceMinutes > 0,
              (distanceKM * paceMinutes * 60).isFinite,
              (1000 / (paceMinutes * 60)).isFinite else { throw RouteError.invalidParameters }
        self.distanceKM = distanceKM
        self.paceMinutes = paceMinutes
    }

    public init(distanceKM: Double, durationMinutes: Double) throws {
        try self.init(distanceKM: distanceKM, paceMinutes: durationMinutes / distanceKM)
    }
}
