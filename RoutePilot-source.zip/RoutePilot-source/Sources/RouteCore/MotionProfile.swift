import Foundation

public struct MotionSettings: Codable, Equatable, Sendable {
    public var cadence: Double
    public var humanVariation: Bool
    public var paceVariationSeconds: Double
    public var cadenceVariation: Double
    /// Derive cadence from the planned pace instead of using ``cadence``.
    public var cadenceAutomatic: Bool
    public var strideMetres: Double
    /// Derive stride from speed and cadence instead of using ``strideMetres``.
    public var strideAutomatic: Bool
    public var steps: Double
    /// Derive the step count from cadence and duration instead of ``steps``.
    public var stepsAutomatic: Bool
    public var climbMetres: Double
    /// Derive climb from the distance instead of ``climbMetres``.
    public var climbAutomatic: Bool

    public init(cadence: Double = 180, humanVariation: Bool = false, paceVariationSeconds: Double = 10,
                cadenceVariation: Double = 5, cadenceAutomatic: Bool = false, strideMetres: Double = 0,
                strideAutomatic: Bool = true, steps: Double = 0, stepsAutomatic: Bool = true,
                climbMetres: Double = 0, climbAutomatic: Bool = true) {
        self.cadence = cadence; self.humanVariation = humanVariation
        self.paceVariationSeconds = paceVariationSeconds; self.cadenceVariation = cadenceVariation
        self.cadenceAutomatic = cadenceAutomatic; self.strideMetres = strideMetres
        self.strideAutomatic = strideAutomatic; self.steps = steps; self.stepsAutomatic = stepsAutomatic
        self.climbMetres = climbMetres; self.climbAutomatic = climbAutomatic
    }

    private enum CodingKeys: String, CodingKey {
        case cadence, humanVariation, paceVariationSeconds, cadenceVariation
        case cadenceAutomatic, strideMetres, strideAutomatic, steps, stepsAutomatic, climbMetres, climbAutomatic
    }

    /// Files written before 0.1.7 carry only the first four keys, so every newer
    /// key falls back to its default instead of failing the import.
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let fallback = MotionSettings()
        cadence = try container.decodeIfPresent(Double.self, forKey: .cadence) ?? fallback.cadence
        humanVariation = try container.decodeIfPresent(Bool.self, forKey: .humanVariation) ?? fallback.humanVariation
        paceVariationSeconds = try container.decodeIfPresent(Double.self, forKey: .paceVariationSeconds) ?? fallback.paceVariationSeconds
        cadenceVariation = try container.decodeIfPresent(Double.self, forKey: .cadenceVariation) ?? fallback.cadenceVariation
        cadenceAutomatic = try container.decodeIfPresent(Bool.self, forKey: .cadenceAutomatic) ?? fallback.cadenceAutomatic
        strideMetres = try container.decodeIfPresent(Double.self, forKey: .strideMetres) ?? fallback.strideMetres
        strideAutomatic = try container.decodeIfPresent(Bool.self, forKey: .strideAutomatic) ?? fallback.strideAutomatic
        steps = try container.decodeIfPresent(Double.self, forKey: .steps) ?? fallback.steps
        stepsAutomatic = try container.decodeIfPresent(Bool.self, forKey: .stepsAutomatic) ?? fallback.stepsAutomatic
        climbMetres = try container.decodeIfPresent(Double.self, forKey: .climbMetres) ?? fallback.climbMetres
        climbAutomatic = try container.decodeIfPresent(Bool.self, forKey: .climbAutomatic) ?? fallback.climbAutomatic
    }
}

public enum MotionSettingsError: LocalizedError {
    case cadence, paceRange, cadenceRange, size, stride, steps, climb
    public var errorDescription: String? {
        switch self {
        case .cadence: return "步频必须是大于零的有限数值。"
        case .paceRange: return "配速波动须为非负数；开启波动时须小于基准配速的秒数。"
        case .cadenceRange: return "步频波动须为非负数；开启波动时须小于基准步频。"
        case .size: return "距离、时间或步数过大，无法生成运动曲线。"
        case .stride: return "步幅须在 0.30 至 2.50 米之间，或交给自动计算。"
        case .steps: return "步数必须是大于零的有限数值，或交给自动计算。"
        case .climb: return "爬升高度须为 0 至 100000 米之间的有限数值。"
        }
    }
}

public struct MotionSnapshot: Equatable, Sendable {
    public let distanceMetres: Double
    public let paceMinutes: Double
    public let cadence: Double
    public let steps: Double
    public let strideMetres: Double
    public let climbMetres: Double
}

/// Smooth, seeded motion whose distance and step count are analytic integrals.
/// Each complete cycle has zero-mean variation, retaining the requested total time and distance.
public struct MotionProfile: Sendable {
    public let plan: MotionPlan
    /// The settings actually used, with every automatic value already resolved.
    public let settings: MotionSettings
    private let seed: UInt64
    private let period: Double
    private let speedAmplitude: Double

    public init(plan: MotionPlan, settings: MotionSettings, seed: UInt64) throws {
        let resolved = try MotionProfile.resolve(plan: plan, settings: settings)
        guard resolved.cadence.isFinite, resolved.cadence > 0 else { throw MotionSettingsError.cadence }
        guard settings.paceVariationSeconds.isFinite, settings.paceVariationSeconds >= 0,
              !settings.humanVariation || settings.paceVariationSeconds < plan.paceMinutes * 60 else {
            throw MotionSettingsError.paceRange
        }
        guard settings.cadenceVariation.isFinite, settings.cadenceVariation >= 0,
              !settings.humanVariation || settings.cadenceVariation < resolved.cadence else {
            throw MotionSettingsError.cadenceRange
        }
        guard (plan.distanceKM * 1000).isFinite, (resolved.cadence * plan.durationSeconds / 60).isFinite,
              plan.durationSeconds > 0 else { throw MotionSettingsError.size }
        self.plan = plan; self.settings = resolved; self.seed = seed
        period = plan.durationSeconds / max(1, ceil(plan.durationSeconds / 30))
        // Symmetric speed fluctuations must respect the slower pace boundary too.
        // This conservative amplitude keeps both fast and slow pace within ±range.
        speedAmplitude = settings.humanVariation
            ? plan.speedMetresPerSecond * (settings.paceVariationSeconds / (plan.paceMinutes * 60 + settings.paceVariationSeconds)) : 0
    }

    /// Resolve the automatic values so that the model, the interface and the
    /// exported files all describe the same run.
    public static func resolve(plan: MotionPlan, settings: MotionSettings) throws -> MotionSettings {
        var resolved = settings
        let speed = plan.speedMetresPerSecond
        if !settings.stepsAutomatic, settings.steps > 0 {
            guard settings.steps.isFinite, settings.steps <= 1e9 else { throw MotionSettingsError.steps }
            resolved.cadence = HumanGait.cadence(steps: settings.steps, durationSeconds: plan.durationSeconds) ?? resolved.cadence
        } else if settings.cadenceAutomatic {
            resolved.cadence = HumanGait.automaticCadence(speedMetresPerSecond: speed)
        }
        if settings.strideAutomatic || !(settings.strideMetres > 0) {
            resolved.strideMetres = HumanGait.stride(speedMetresPerSecond: speed, cadence: resolved.cadence)
        } else {
            guard settings.strideMetres.isFinite, HumanGait.strideRange.contains(settings.strideMetres) else {
                throw MotionSettingsError.stride
            }
            // A stride the user pinned defines its own cadence unless cadence was
            // pinned as well; then both stand and the mismatch is reported to the user.
            if settings.cadenceAutomatic {
                resolved.cadence = 60 * speed / settings.strideMetres
            }
        }
        if settings.climbAutomatic {
            resolved.climbMetres = HumanGait.automaticClimb(distanceMetres: plan.distanceKM * 1000)
        } else {
            guard settings.climbMetres.isFinite, HumanGait.climbRange.contains(settings.climbMetres) else {
                throw MotionSettingsError.climb
            }
        }
        if settings.stepsAutomatic {
            resolved.steps = resolved.cadence * plan.durationSeconds / 60
        }
        return resolved
    }

    /// Everything the plan implies, after automatic resolution.
    public var metrics: HumanMetrics {
        HumanMetrics(distanceMetres: plan.distanceKM * 1000, durationSeconds: plan.durationSeconds,
                     paceMinutes: plan.paceMinutes, speedMetresPerSecond: plan.speedMetresPerSecond,
                     cadence: settings.cadence, strideMetres: settings.strideMetres,
                     steps: settings.steps, climbMetres: settings.climbMetres)
    }

    private func amplitude(cycle: Double, salt: UInt64) -> Double {
        var bits = seed &+ cycle.bitPattern &+ salt
        bits = (bits ^ (bits >> 30)) &* 0xbf58476d1ce4e5b9
        bits = (bits ^ (bits >> 27)) &* 0x94d049bb133111eb
        bits ^= bits >> 31
        let magnitude = 0.35 + 0.65 * Double(bits >> 11) / 9_007_199_254_740_992
        return bits & 1 == 0 ? magnitude : -magnitude
    }

    public func sample(elapsed: Double) -> MotionSnapshot {
        let time = elapsed.isFinite ? min(plan.durationSeconds, max(0, elapsed)) : 0
        let finished = time >= plan.durationSeconds
        let cycle = floor(time / period)
        let phase = finished ? 0 : time.truncatingRemainder(dividingBy: period) / period
        let angle = 2 * Double.pi * phase
        let wave = pow(sin(angle), 3)
        let cosine = cos(angle)
        let area = phase == 0 ? 0 : (2.0 / 3 - cosine + pow(cosine, 3) / 3) / (2 * Double.pi)
        let speedOffset = speedAmplitude * amplitude(cycle: cycle, salt: 0x9e3779b97f4a7c15)
        // Cadence follows the direction of the pace change but uses its own bounded amplitude.
        let cadenceOffset = settings.humanVariation
            ? settings.cadenceVariation * abs(amplitude(cycle: cycle, salt: 0xd1b54a32d192ed03)) * (speedOffset < 0 ? -1 : 1) : 0
        let speed = plan.speedMetresPerSecond + speedOffset * wave
        let distance = finished ? plan.distanceKM * 1000 : time * plan.speedMetresPerSecond + speedOffset * period * area
        let steps = finished ? settings.steps : (settings.cadence * time + cadenceOffset * period * area) / 60
        let cadence = max(1, settings.cadence + cadenceOffset * wave)
        let boundedDistance = max(0, min(plan.distanceKM * 1000, distance))
        return MotionSnapshot(distanceMetres: boundedDistance,
                              paceMinutes: speedAmplitude == 0 ? plan.paceMinutes : 1000 / (speed * 60),
                              cadence: cadence,
                              steps: max(0, steps),
                              // Stride always satisfies speed = cadence x stride,
                              // so the three numbers stay consistent while the pace varies.
                              strideMetres: HumanGait.stride(speedMetresPerSecond: max(0.1, speed), cadence: cadence),
                              climbMetres: plan.distanceKM > 0
                                  ? settings.climbMetres * min(1, boundedDistance / (plan.distanceKM * 1000)) : 0)
    }
}
