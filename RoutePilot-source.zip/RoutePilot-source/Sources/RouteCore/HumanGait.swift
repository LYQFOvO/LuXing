import Foundation

/// Human gait relationships used to fill in the metrics the user does not type.
///
/// The relations are the ones coaches and gait labs use:
/// ``speed = cadence x stride``, cadence rises with speed and saturates, and a
/// step count is the time integral of cadence. Nothing here is measured from the
/// phone: the numbers describe the planned run so that a route can be described
/// with two inputs only (distance and finish time).
public enum HumanGait {
    /// Cadence rises with speed and flattens out. 6:00 min/km (2.78 m/s) lands
    /// on the widespread coaching value of about 180 steps per minute.
    public static func automaticCadence(speedMetresPerSecond speed: Double) -> Double {
        guard speed.isFinite, speed > 0 else { return 180 }
        return min(196, max(150, 158 + 8 * speed))
    }

    /// Stride follows from the physical relation between speed and cadence.
    public static func stride(speedMetresPerSecond speed: Double, cadence: Double) -> Double {
        guard speed.isFinite, speed > 0, cadence.isFinite, cadence > 0 else { return 0 }
        return speed / (cadence / 60)
    }

    /// The cadence that produces a given step count over a given duration.
    public static func cadence(steps: Double, durationSeconds: Double) -> Double? {
        guard steps.isFinite, steps > 0, durationSeconds.isFinite, durationSeconds > 0 else { return nil }
        return steps / (durationSeconds / 60)
    }

    /// Total climb for a planned run.
    ///
    /// The app cannot read terrain height and the USB location interface does
    /// not carry altitude, so the automatic value stays at zero rather than
    /// inventing a profile; the user can type a value for the record and GPX.
    public static func automaticClimb(distanceMetres _: Double) -> Double { 0 }

    /// Plausible bounds for values a user types by hand.
    public static let cadenceRange = 100.0 ... 240.0
    public static let strideRange = 0.30 ... 2.50
    public static let climbRange = 0.0 ... 100_000.0
}

/// The metrics produced by a planned run; every value is derived from the plan
/// plus the user's overrides.
public struct HumanMetrics: Equatable, Sendable {
    public let distanceMetres: Double
    public let durationSeconds: Double
    public let paceMinutes: Double
    public let speedMetresPerSecond: Double
    public let cadence: Double
    public let strideMetres: Double
    public let steps: Double
    public let climbMetres: Double

    public init(distanceMetres: Double, durationSeconds: Double, paceMinutes: Double,
                speedMetresPerSecond: Double, cadence: Double, strideMetres: Double,
                steps: Double, climbMetres: Double) {
        self.distanceMetres = distanceMetres
        self.durationSeconds = durationSeconds
        self.paceMinutes = paceMinutes
        self.speedMetresPerSecond = speedMetresPerSecond
        self.cadence = cadence
        self.strideMetres = strideMetres
        self.steps = steps
        self.climbMetres = climbMetres
    }
}
