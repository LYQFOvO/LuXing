# 路行 RoutePilot

Native SwiftUI + MapKit macOS route editor with a bundled Python/pymobiledevice3 USB location worker.

See [使用说明.md](使用说明.md) for setup, motion parameters, recovery behavior and the real-device validation limitation.

## Build and tests

An existing .app requires no development tools. To rebuild source, install Apple's Command Line Tools (Swift 5.9+), [uv](https://docs.astral.sh/uv/) and use an Apple Silicon Mac on macOS 14+.

```sh
bash scripts/run-tests.sh
bash scripts/build-app.sh
```

The build script creates a project-local working environment, installs pinned Python dependencies from `backend/requirements.lock`, builds Swift directly with `swiftc`, bundles Python with PyInstaller and ad-hoc signs the application. Direct compiler scripts avoid requiring Xcode/SwiftPM test frameworks. Default build output is the parent folder's “路行 RoutePilot.app”. Set `ROUTEPILOT_BUILD_DIR` to choose a scratch directory; pass a destination app path as the first argument. For native development only, run `scripts/build-native.sh` and set `ROUTEPILOT_WORKER` to a bundled worker executable.

## Files

- `Sources/RouteCore`: spherical sampling, closed loops/bounce paths, motion plans, pause clock, mainland map conversion.
- `Sources/RoutePilot`: native UI, MapKit route editing/search/directions, device bridge and playback lifecycle.
- `backend/device.py`: USB-only device enumeration, Developer Mode checks, personalized/Cryptex preparation and persistent DVT location session.
- `backend/worker.py`: serialized JSON Lines requests through pipes, bounded coordinate validation and error responses.
- `Tests/CoreTests.swift`: numerical and motion acceptance checks, without an XCTest dependency.
- `Tests/ModelTests.swift`, `Tests/fake-worker.py`: native bridge/state integration tests against a deliberately slow peer; no phone involved.
- `backend/test_worker.py`: protocol and lifecycle tests with an injectable device adapter.
- `scripts`: reproducible native/worker build, packaging and icon generation.

## Private worker protocol

One request per line: `{"id":"unique-string","action":"set","latitude":31.2,"longitude":121.4}`.

Responses: `{"id":"unique-string","ok":true,"result":{...}}`, or `{"id":"unique-string","ok":false,"error":"message"}`. Actions are `hello`, `devices`, `prepare`, `connect`, `set`, `clear`, `disconnect`, `shutdown`. `prepare/connect` require selected USB `udid`; `shutdown` accepts `restore:true` for an outstanding restore obligation after reconnect. No TCP/HTTP listener is exposed.

Set awaits the DVT response. Clear is fire-and-forget in the pinned library, so it returns `restore_sent:true, verified:false`; neither action reads back the location from target apps. The native UI keeps one position request in flight and pauses on errors. Timeouts reset the worker and preserve the native recovery warning.

## Known limits

Apple Silicon build; no App Store sandbox, Developer ID signature or notarization. USB transport is implemented for iOS 17.4+; target iOS 27.0.1 is untested on real hardware. First device preparation needs network access and Apple's matching developer components/signing services. Map search and walking directions depend on MapKit availability. GCJ-02 correction uses an approximate bounding region and is optional for Hong Kong, Macao, Taiwan or WGS-84 map providers. Device apps may ignore or cache simulated locations.

GPL-3.0-or-later. Dependency licenses and corresponding GPL source distributions are included in `third-party`.

## Coordinate repair (0.1.2)

MapKit coordinates now pass through unchanged. Manual GCJ conversion is used only when explicitly restoring schema 1 map selections; schema 2 never repeats that repair. Native regression tests inspect the actual USB bridge request coordinates. Hardware target-app reception remains unverified after this repair.

## Automatic human gait (0.1.7)

Distance and finish time are now the only required inputs. `HumanGait` derives cadence from speed
(`158 + 8 v`, clamped to 150–196 steps per minute), stride from the physical relation
`speed = cadence x stride`, steps from the cadence integral, and leaves climb at zero because no
terrain height is available. Every value can be pinned in the interface instead; pinning a stride
derives its cadence, pinning a step count derives cadence, and an inconsistent pair warns without
blocking the run. Sensor playback waypoints are now one whole second of travel apart, which the
device requires because it waits for the next whole second at every waypoint: measured ground speed
over a 120 m route was 1.68 m/s for the old fixed 5 m spacing at a requested 2.0 m/s, and 2.03 m/s /
4.12 m/s once the spacing matched the per-second distance. Saved routes move to schema 4; older
files load with automatic stride, steps and climb.

## Apple simulation engine (0.1.6)

`com.apple.coredevice.locationservice` (`simulatelocation` feature) drives the phone's own
`CLSimulationManager` — the engine behind the Simulator's "City Run" scenario. RoutePilot now hands
the whole planned route to the phone as waypoints plus a speed, so fixes are generated on-device at
1 Hz with a valid `speed` field instead of one raw coordinate per USB round trip. On a connected
iPhone (iOS 27.0.1) the per-coordinate DVT channel reported `speed,-1.000` on every fix and emitted
two fixes a few milliseconds apart whose timestamps were not monotonic; the on-device route reported
`speed,2.778` for a 6:00 min/km plan. Pausing pins the current coordinate through the same service
(no clear, so the target app never sees the real position) and resuming replays only the remaining
waypoints. If the service is missing or rejects a route, playback falls back to coordinate mode.
Pedometer data still cannot be written: the phone's motion coprocessor keeps reporting a stationary
device, so a target app that requires steps may still complain.

## Motion and restoration (0.1.3)

Restore clears the simulated location and closes the developer session; a repeatable restore action can open a fresh session without moving the phone. Device log evidence can show simulation stopped, but is not a proof of restored GPS accuracy. MotionProfile provides bounded smooth seeded speed and cadence with analytic distance/step integrals; total target time and distance stay exact. Cadence is local simulation metadata, not Core Motion injection. Schema3 saves optional MotionSettings and remains able to import schema1/2 routes. GPX shares the playback curve with optional custom simulated cadence/steps extensions.

0.1.4: serial USB updates rebase at acknowledgments and advance at most one second without catching up after delays/stalls. A stationary starting-point preparation is required before USB movement. Device cadence/speed fields remain outside the USB coordinate API; third-party acceptance is unverified.

0.1.5 allows preparing the starting point again after finishing or restoring. It serializes cleanup, reconnect to the selected USB phone, and stationary preparation; failed cleanup blocks a new position. Cadence remains a local planned metric, not injected Core Motion data.
