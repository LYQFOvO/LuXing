# Third-party notices

RoutePilot uses pymobiledevice3 11.26.0 and its pinned dependencies. Distribution metadata and shipped licenses are in licenses/; corresponding source distributions for GPL/LGPL dependencies are in sources/. Full versions are in dependencies.json and ../backend/requirements.lock. PyInstaller has a bundling exception; its license is included.

GCJ-02 conversion formulas follow the MIT-licensed mathematical reference at https://github.com/wandergis/coordtransform. Its license is included as coordtransform-LICENSE.

Upstream: https://github.com/doronz88/pymobiledevice3
