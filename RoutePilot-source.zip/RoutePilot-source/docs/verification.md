# 交付验证记录

版本 0.1.1，2026-10-10。验证环境为 Apple Silicon、macOS 27.0.1、Swift 6.3；应用最低系统设为 macOS 14，较低系统尚未实测。

## 自动验证

源码通过 38 项检查：23 项 Swift 路线核心检查、7 项原生模型与独立延迟进程集成检查、8 项 Python 协议检查。新增检查覆盖无效经纬度不破坏点位与步行路径、有效小数坐标更新清除旧步行路径，以及播放时禁止编辑点位。

覆盖距离与跨日界线插值、往返和循环、无效参数、地图坐标近似转换、暂停时钟、快速暂停继续时仅有一个定位请求、停止失败后的重新连接继续、停止清除、纯预览不写入设备，以及重建会话后的退出恢复义务。连接测试使用替身设备，不代表真机通过。

原生优化构建成功，核心静态链接。应用和捆绑连接模块为 arm64；原生可执行文件没有指向工作目录的动态库依赖。Info.plist 格式检查和应用深层临时签名验证通过。Python 环境与依赖随应用分发。

捆绑模块的 hello、USB 发现和 shutdown 协议检查通过；未连接手机时 USB 结果为空。捆绑模块的开发者组件安装和 DVT 模拟定位命令帮助可加载，覆盖深层依赖导入。

## 界面操作

已打开实际应用并检查地图瓦片加载、示例路线、地图点击添加点位、地点搜索、配速/时间/距离换算、预览、暂停、停止、保存与 GPX 导出。JSON 保存结果包含有效 WGS-84 点位和参数；GPX 导出包含 1,801 个有效点与覆盖 30 分钟的时间戳。

当前测试地点的步行规划返回服务不可用，界面保留原路线并显示错误。因此沿道路步行功能的成功返回尚未验证。最终构建重新打开成功，可加载示例路线。

0.1.1 最终界面验证：默认带路名卫星图、纯卫星和普通地图切换成功，测试地点（上海人民广场附近）可加载清晰道路、建筑和车辆影像。修复图层控件点击穿透后，连续切换三个图层保持 0 点位；点击中心添加后恰好增加 1 个点位。经纬度编辑中纬度 91 会禁用应用按钮，合法六位小数可应用。点位聚焦后比例尺为 50 米，重复点击同一点位三次保持相同倍率。选择搜索结果后点位数从 2 增至 3，动态搜索面板收起时没有额外落点。

## 待真机验证

用户当前无法连接 iPhone。iOS 27.0.1 的设备准备、USB 开发者会话、定位更新及目标应用接收效果均未验证。恢复接口没有设备确认响应，应用只提示指令已发送，实际恢复需在手机上检查。

当前应用使用本机临时签名，未进行 Apple 开发者签名或公证。当前交付仅含 Apple Silicon 构建。

## 0.1.2 coordinate repair, 2026-10-10

- Regression initially failed because an unmodified MapKit coordinate was inverted a second time (red.log).
- green.log: 23 core + 15 native + 8 Python checks pass (46 total). Native transport peer inspects the exact first latitude/longitude payload.
- Native build completed; active app copy passed deep strict signing verification at version 0.1.2.
- Public landmark MKLocalSearch raw coordinate and visible satellite point now agree with the app stored coordinate. Removed manual conversion formerly displaced this example 478.5 metres.
- Native schema 1 import prompt observed. The user's saved 27-point route was recovered with the old correction-on setting previously observed; all IDs, names, loop mode, 5 km target and 6 min/km pace retained. Recovered route stays on the original satellite track outline; saved schema 2 positions checked against previous visual positions with error 0 metres. Original file remains untouched.
- USB session reconnected successfully after the repair. Movement has not been started in the repaired app and no iPhone target-map alignment claim is made.
- Independent reviewer found no material issues.


## 0.1.3 步频、配速波动与定位恢复，2026-10-10

- 最终检查通过：38 项路线核心、21 项原生模型集成、12 项 Python 协议，共 71 项。新增回归先复现失败，再确认修正通过；最终日志位于工作目录 motion-update/final-test.log。
- 配速曲线改变实际路线距离积分，配速与步频均限制在设置范围内。约 30 秒周期平滑变化，总距离、时间与平均步频保持设定值。暂停冻结距离、时间和累计预计步数。
- 清除模拟位置后关闭开发者定位及 USB 会话，下一次位置写入须重新连接。清除或会话关闭失败保留恢复义务；位置响应丢失也保留恢复义务。恢复按钮可从空闲状态重新连接、清除和关闭。
- GPX 保留小数秒，覆盖 1.001 km / 6 min/km 的 360.36 秒非整数时长；包含明确命名空间的模拟步频和预计步数扩展。
- 原生优化构建和捆绑 Python 模块构建完成。最终应用版本 0.1.3/build 4，深层严格临时签名与 Info.plist 检查通过。
- 实际打包应用界面验证：180 步/分钟、配速 ±10 秒/公里、步频 ±5；预览 4 秒时显示 05:58、182 步/分钟及 12 步，暂停后数值不增加。配速波动 360 秒在 6 min/km 设置下禁用开始并显示原因；改回 10 秒后恢复。
- 打包应用 GPX 导出解析通过：361 点、严格递增时间戳、360 秒、模拟步频在 175–185 以内、终点预计步数 1080。
- 打包应用在连接的 iPhone 上从未连接状态执行恢复两次，均返回清除已发送、会话已关闭，界面保持未连接并保留再次恢复入口。此验证只清除定位，没有向手机发送测试路线坐标。
- 独立诊断记录中，手机 locationd 收到停止模拟请求，并报告 fSimulationRunning=0、模拟控制器关闭。该证据不等于高德缓存已更新或真实 GPS 精度已恢复。
- 用户 schema 2 坐标修正版路线直接打开；新保存 schema 3 波动版与原文件逐字段比对，27 点坐标、ID、名称、闭合模式、5 km 和 6 min/km 均未改变；新增 180 步/分钟、真人波动开启、±10 秒/公里与 ±5 步/分钟。
- 独立审查发现会话关闭失败的恢复标记和 GPX 小数秒问题，均已修正，复核通过。
- 系统 Core Motion 步频/步数写入未实现：当前 USB 定位接口只支持位置与清除，程序指标和 GPX 扩展不能让第三方运动软件获得指定传感器数据。新版手机沿路线定位及高德显示精度仍需用户核对。


## 0.1.4 USB 速度尖峰，2026-10-10

- 旧版复现：设定固定 6 min/km，即 10 km/h；替身设备一次 2 秒响应后返回 0.01 秒响应，8.511 m 在 1.074 s 交付，28.53 km/h。回归失败后实现每次响应重新计时及单次最多推进 1 秒；同一案例的最终交付速度分别约 3.30、9.51、9.54 km/h，均不超过设定值。原始与最终日志在 work/speed-fix/red.log、final-test.log。
- 最终全套通过 38 项路线核心、26 项原生模型集成和 12 项 Python 协议，共 76 项。覆盖准备起点保持零运动、USB 开始门槛、首条移动重复准备坐标、准备后可恢复、重连须重新准备、不均匀连接响应、主循环阻塞后不追赶、暂停继续与断线恢复。
- 起点门槛用旧模型额外复现失败（start-guard-red.log）。第一次手动测试使用相对路径导致连接失败，其日志 start-red.log 不作为行为回归证据。
- 独立审查未发现新的重要问题；审查只读，未独立实测手机或运动世界。
- 原生优化构建完成，应用版本 0.1.4/build5，捆绑 Python worker 与 0.1.3 一致，未改动设备接口或依赖。
- 实际打包应用 UI：用户原 27 点 schema3 路线直接加载，5 km、6 min/km、180 步/分钟、±10 秒/公里、±5 步/分钟保持。USB 模式显示定位到起点和说明；未连接时起点与开始移动均禁用。预览仍可直接开始、暂停及停止，15 秒时约 0.044 km、47 预计步数，路线仍沿原跑道。
- 本次 UI 验证未发现 USB iPhone，因此新版实际起点准备及运动世界接收尚未验证。没有向任何手机发送测试坐标。0.1.3 的清除真机证据仅支持同一未变更 backend 的清除动作，不能证明新移动流程被第三方接受。
- 计划运动时间和总距离的积分不变，USB 响应等待及调度卡顿不计入路线运动时间，实际墙钟完成时间可能延长。预览/GPX 保持理想计划曲线；不能把其计划时间解释为手机真实收到的时间。
- 当前 API 无系统步频/步数或速度字段写入：程序模拟值不会成为运动世界的传感器数据。其具体“过快”判定和无数据原因未取得日志，不能声称已经消除此提示，也不以增加空间随机抖动冒充修复。


## 0.1.6 Apple 定位引擎（运动传感器仿真），2026-10-10

- 用户报告两项：结束后无法再次“定位到起点”；一点“开始移动”手机就提示配速过快、步频过低，并希望让目标软件把数据当作运动传感器数据解读。
- 复查 0.1.5 的重复准备事务：源码允许 idle/finished 再次准备，并已通过 31 项原生集成中的完成态回归；本轮在真机上按同样的顺序执行了 connect → hold → route → clear → connect → hold → route，第二轮全部成功，确认设备层可用（此前两次交付均未在真机上跑过该流程）。
- 通过 `developer core-device location available-scenarios` 与 DDI 中的 `dtlocationd` 确认设备提供 `com.apple.coredevice.feature.simulatelocation`：`setsimulatedlocation`、`startlocationsimulation`（waypoints + pacing + speed）、`clearsimulatedlocation`。逐个尝试输入形状后确定：`pacing` 必须是单键字典，`{"distance": {"_0": m}}` 或 `{"interval": {"_0": s}}`，顶层另有必填的 `speed`。
- 真机对照（同一台 iPhone，iOS 27.0.1，locationd 日志）：逐点 DVT 写入每条模拟定位都是 `speed,-1.000`、`course,-1.0`，并在同一次写入后出现两条相隔约 6 毫秒、位置差 2.8 米的定位，时间戳还不单调；Apple 引擎模式设定 6 min/km 时每条定位为 `speed,2.778`，每秒一条。City Run 场景同为引擎播放，`speed,3.500`。
- 引擎行为核对：路线播放期间按设定速度推进；走到最后一个路径点后继续每秒给出同一位置（不回退到真实定位）；再次下发路线会先停止旧仿真并从新路线的第一个点重新开始，因此运行中不做分块追加，暂停改为 `setsimulatedlocation` 固定当前点。
- 步频仍不可写：模拟定位期间 locationd 的计步链路持续报告零步增量（`CMStepArbitrator`、`RunningSpeedKF feedStepCountEntry - zero deltaPedDist`），说明手机的运动协处理器看到的是一台静止的设备。USB 开发者服务没有写入步数/步频的接口，因此“步频过低”只能靠让手机真的移动解决，已在说明与界面中写明。
- 自动检查 86 项：38 项路线核心、31 项原生集成（新增传感器起点固定、整条路线下发与速度、按计划推进、停止清理、暂停固定/继续只补剩余路线、路线被拒回退、缺少服务时保持逐点模式）、17 项 Python 协议（新增 route/hold/route_stop 校验、清除先停路线、失败保留恢复义务）。
- 打包应用 0.1.6/build 7 通过深层严格签名校验，Info.plist 与应用内说明一致；捆绑 `routepilot-worker` 在真机上完成 hello、devices、connect(sensor: true)、hold、route(40 点)、route_stop、clear、shutdown。
- 未验证：运动世界是否因此不再提示，高德位置显示精度，恢复后的真实 GPS 精度，以及目标应用是否读取速度字段。


## 0.1.7 自动步态与配速精度，2026-10-10

- 用户反馈：运动世界已经能读到配速，但读不到步频；要求增加步幅、爬升高度、步数选项，并由算法按“只填距离和完成时间”生成真人数据。
- 定位接口能力复核：`setlocationscenario` 的输入枚举只有内置场景（`named`），没有自定义文件/URL 分支，因此无法通过自定义场景注入高度；`setsimulatedlocation` 与路线路径点只有经纬度。爬升高度只能作为本程序的记录值，不能写进手机。
- 步频/步数仍是手机运动协处理器的数据：模拟定位期间计步链路持续报告零步增量，USB 开发者服务没有写入接口；DDI 内只有守护进程与框架，没有可用于写入系统偏好的工具，因此“造步数”在本项目支持范围内不可实现。0.1.7 把步频/步幅/步数做成算法生成的记录值，并再次在说明与界面中写明。
- 标定实验（iPhone 17,2 / iOS 27.0.1，120 米直线，locationd 日志计时）：路径点间距 5 米、速度 2.0 m/s → 71.3 秒（1.68 m/s，偏慢 16%）；间距 4.0 米、速度 4.0 m/s → 47.2 秒（2.54 m/s，偏慢 36%）。规律是设备在每个路径点等待下一个整秒，因此地面速度 = 段长 ÷ ceil(段长 ÷ 每秒位移)。
- 按“路径点间距 = 每秒位移的整数倍”修正后的实测：间距 2.0 米 / 2.0 m/s → 59.2 秒（2.03 m/s）；间距 4.0 米 / 4.0 m/s → 29.1 秒（4.12 m/s）；打包 worker 端到端 300 米 / 2.5 m/s → 119.5 秒（2.511 m/s），120 条定位，速度字段全部为 2.5。手机侧坐标速度与设定配速、与定位速度字段三者一致。
- 新增 `HumanGait`：`步频 = clamp(158 + 8 × 速度, 150, 196)`（6:00/km ≈ 180.2 步/分）、`步幅 = 速度 ÷ (步频/60)`（6:00/km ≈ 0.93 米）、`步数 = 步频 × 时间`、自动爬升 = 0。参数默认改为“距离 + 完成时间”，步频/步幅/步数/爬升各带自动开关；手填步幅反推步频、手填步数反推步频，两者与配速冲突时提示但不阻止开始，不可实现的步幅会阻止开始。
- 保存格式升到 schema 4；旧 schema 1/2/3 文件继续可打开，旧 motion 字段缺项按自动默认值补齐（有专项回归）。
- 自动检查 93 项全部通过：38 项路线核心、38 项原生集成、17 项 Python 协议。新增覆盖步态算法、覆盖与冲突提示、旧设置兼容、路径点间距与 4000 点上限。
- 打包应用 0.1.7/build 8 通过深层严格签名校验并实际启动（原生进程与捆绑 worker 均正常）。捆绑 worker 在真机上完成 connect / hold / route(121 点) / clear / shutdown，手机模拟定位已清除。
- 未验证：运动世界是否接受这次的数据，高德显示精度，恢复后的真实 GPS 精度。


## 0.1.8 运动传感器写入通道逐项实测，2026-10-10

用户要求“想办法模拟传感器把步频写进去”。本轮把设备端所有可能的写入通道逐一实测，结论是未越狱、未监管的 iPhone 上无法写入计步数据：

- 单点定位 `setsimulatedlocation`：输入只有 `latitude`/`longitude`，多键即报解码错误；路线路径点同样只有经纬度；`setlocationscenario` 枚举只有内置场景（`named`），无自定义文件分支。
- Apple 官方仿真清单只有 `simulatelocation`、`simulatefaceid`、`simulateopticid`、`simulatetouchid`，没有运动/计步仿真。
- CoreDevice 描述文件安装 `com.apple.coredevice.action.configurationprofile.install`：输入形状为 `profileData` + `payloadIdentifier` + `payloadUUID` + `displayName` + `options{forceRemoval,replaceExisting}`；一页无害的 Web Clip 描述文件同样返回 `code 22600`，说明该通道只接受 MDM 签名描述文件。
- 经典 `com.apple.mobile.MCInstall` 服务 `install_profile`：手机返回错误链 `MCProfileErrorDomain 1000 → MCPayloadErrorDomain 2000 → MCPayloadErrorDomain 2003：字段 “DefaultsData” 无效`，即未受监管设备直接拒绝托管默认值负载。
- DDI 内可执行文件仅守护进程与框架，无 shell 或可写系统偏好的工具；`mobile_config` 的静默安装需要监管身份（`escalate` + 监管证书），本机没有。
- locationd 内确有内部步数仿真开关（`SimulateStepsOnAPWake`、`SimulatedStepCadencePerMinute`、`SimulatedStepSpeedMps`、`SimulatedStepLengthCM`、`SimulateStepsUseFixedDuration`、`SimulatedStepBatchDurationSeconds` 等，属 `com.apple.locationd` 偏好域），但写入需要监管+描述文件、越狱或 root 代码执行，本机都不具备；模拟定位期间计步链路仍报告零步增量。
- 交付 `RoutePilot-步数仿真.mobileconfig`（`com.apple.defaults.managed`）供受监管的备用设备实验，说明中标注未经验证且需要抹机监管。
- 界面增加提示：手机端步频需要手机自身持续运动，运行中显示目标步频。自动检查仍为 93 项（38 核心 + 38 原生 + 17 Python），打包应用 0.1.8/build 9 通过严格签名校验。
