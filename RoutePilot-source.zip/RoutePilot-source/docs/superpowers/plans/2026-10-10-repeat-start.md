# 重复定位到起点 Implementation Plan

**Goal:** 完成或停止后可以再次定位到起点，准确说明运动传感器能力。
**Architecture:** AppModel 内准备事务持有 deviceBusy，复用 clear 回执验证；界面根据运行状态显示操作。
**Tech Stack:** SwiftUI、MapKit、Python JSON Lines worker。

## Constraints

保持坐标恒等映射和逐次确认发送；失败保留恢复义务；不声称注入步频/加速度；没有 Git 仓库，不创建提交。

- [ ] 在 Tests/ModelTests.swift 添加完成态、恢复断连、失败清理/连接/set 的回归测试；fake-worker.py 支持按动作次数失败，并记录 udid。运行 scripts/run-tests.sh，确认原实现因 completed movement must allow another preparation 失败。
- [ ] AppModel.swift 放宽 canPrepareStartPoint 为 idle/finished、非预览、有手机/路线/计划、无操作且未准备；prepareStartPoint 串行清除/重连/set 并重置完成状态，抽取 clearLocationSession() 验证两个回执供 stop 复用。失败不跳过清理。
- [ ] ContentView.swift 在 finished 显示定位到起点，显示仅发送定位、步频不是手机传感器数据。保持运动中禁用准备。
- [ ] 全量测试、独立代码审查、原生构建、界面检查。升级版本 0.1.5/build 6，更新使用说明和测试记录。
- [ ] 重新打包应用和源码，验证签名、ZIP、版本、worker 协议；交付时明确运动世界传感器注入未实现。
