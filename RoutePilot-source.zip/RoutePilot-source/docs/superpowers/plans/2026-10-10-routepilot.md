# RoutePilot Implementation Plan

> **For agentic workers:** Execute inline in this session with executing-plans; the user has requested implementation now.

**Goal:** Deliver an Apple Silicon macOS application for drawing routes and sending paced simulated iPhone locations over USB.

**Architecture:** SwiftUI and MapKit own the native interface. A tested Swift core provides spherical route sampling and a monotonic playback clock. A persistent Python worker uses JSON Lines over pipes and owns one USB, userspace RSD and DVT location session.

**Tech Stack:** Swift 6 (Swift 5 language mode), direct swiftc build, macOS 14+, MapKit, Python 3.13, pymobiledevice3 11.26.0, PyInstaller.

## Global Constraints

- Apple Silicon Mac、macOS 14 及以上；主要目标设备 iOS 27.0.1。
- USB device selection only; no network-device fallback.
- Preview must be visibly marked and must never call a device.
- Location set requires a DVT response; fire-and-forget clear is reported only as sent, never as verified restoration.
- User cannot attach an iPhone now; report real-device validation as outstanding.

## Task 1 — Route core
Files: `Sources/RouteCore/Route.swift`, `Sources/RouteCore/Playback.swift`, `Sources/RouteCore/MapCoordinates.swift`, `Tests/CoreTests.swift`.
Interfaces: `GeoPoint(latitude:longitude:)`, `Route(points:mode:)`, `Route.sample(distance:)`, `MotionPlan(distanceKM:paceMinutes:)`, `PlaybackClock.start(at:)`, `pause(at:)`, `resume(at:)`, `elapsed(at:)`.

- [x] Write standalone Swift acceptance cases using `Route(points: [GeoPoint(latitude: 0, longitude: 0), GeoPoint(latitude: 0, longitude: 0.01)], mode: .bounce)`; assert 1111.95 m ± 1 m and the position at 1.5 route lengths returns halfway.
- [x] Add 5 km at 6 min/km = 1800 s; reject nonpositive and nonfinite inputs; paused time must not advance; antimeridian midpoint must remain near ±180°.
- [x] Run the core check executable; record missing implementation and reproduce the paused-clock nil failure before correcting it. Initial SwiftPM manifest mismatch and unavailable XCTest led to direct compiler/test scripts, without changing product behavior.
- [x] Implement spherical interpolation and route closure for loops, guarded zero-length routes, derived motion parameters and monotonic clock with confirmed-distance tracking.
- [x] Run `bash scripts/run-tests.sh`; 23 core numerical checks must pass.

## Task 2 — Persistent USB worker
Files: `backend/worker.py`, `backend/device.py`, `backend/test_worker.py`, `backend/requirements.txt`.
Interface: requests `{id, action, ...}` and replies `{id, ok, result}` or `{id, ok:false, error}`; actions `hello`, `devices`, `prepare`, `connect`, `set`, `clear`, `disconnect`, `shutdown`.

- [x] Write async unittest cases that assert invalid latitude is rejected, unconnected set fails, USB filtering excludes Network, clear failure is surfaced and set requests reuse a connected session.
- [x] Run `python -m unittest discover -s backend`; record missing-module failure.
- [x] Implement async serialized request dispatch and stdout isolation. Use `create_using_usbmux(connection_type="USB")`, explicit selected UDID, finite coordinates, persistent `AsyncExitStack`, USB-only `UserspaceRsdTunnel(remotepairing_fallback=False)` and `LocationSimulation`.
- [x] Implement preparation with the pinned library API, selected USB UDID, userspace RSD and auto_mount_personalized; return actionable developer-mode errors.
- [x] Run tests, actual library import check, and `hello`/`devices` protocol checks without a phone.

## Task 3 — Native application
Files: `Sources/RoutePilot/App.swift`, `Bridge.swift`, `AppModel.swift`, `ContentView.swift`, `RouteMap.swift`.
Consumes RouteCore and worker protocol; produces native executable `RoutePilot`.

- [x] Build native interface with device selector, search, ordered draggable pins, walking-route generation, linked parameters, preview toggle and transport controls.
- [x] Ensure start waits for connection and set acknowledgement; pause freezes active time; stop awaits successful clear submission and describes it as unverified; transport error pauses and retains last confirmed progress.
- [x] Handle request timeout, worker exit and application quit; no hung response continuations. A delayed-peer native regression test must reject simultaneous set requests during rapid pause/resume.
- [x] Compile `bash scripts/build-native.sh` and run app smoke verification; fix compiler diagnostics and inspect actual UI.

## Task 4 — Bundle and handoff
Files: `scripts/build-app.sh`, `scripts/run-tests.sh`, `README.md`, `使用说明.md`, app Info.plist; output `../路行 RoutePilot.app` and source zip.

- [x] Bundle Python worker and dependencies with PyInstaller; package native executable and resources in .app; create native AppKit icon and ad-hoc sign.
- [x] Run final Swift/Python tests; validate Info.plist and executable architectures; run bundled worker `hello` and USB discovery; inspect UI preview.
- [x] Write installation, trust/developer mode, route/playback, recovery and known-limit instructions. Note original Apple/pymobiledevice3 references and pinned dependency licenses.
- [x] Save final deliverables and state exact validation scope.

## Verification record

23 core checks, 4 native delayed-peer checks and 8 Python tests pass. The native .app opens and previews a route on actual MapKit tiles. The bundled worker successfully responds to hello and USB discovery (empty without a phone). Real iPhone connection and target-app reception remain unverified by user constraint. See ../../verification.md for the final delivery checks.
