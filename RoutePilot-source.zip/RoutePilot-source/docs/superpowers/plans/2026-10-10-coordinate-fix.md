# Coordinate Fix Implementation Plan

> **For agentic workers:** Use executing-plans to implement this focused repair inline.

**Goal:** Remove the extra transformation between MapKit selection and USB output.
**Architecture:** SDK coordinates flow unchanged; the existing GCJ converter is retained solely for explicit migration of schema 1 routes.
**Tech Stack:** SwiftUI / MapKit / RouteCore / Python bridge.

## Global Constraints
- macOS 14+, Apple Silicon; preserve motion controls and USB protocol.
- Do not silently alter legacy GPS files; ask which old map setting produced the file.
- Do not claim phone accuracy based on bridge acknowledgment.

## Repair and verification
- [x] Add a failing native test asserting gpsPoint(rawSDKPoint) equals the raw SDK point.
- [x] Make mapPoint/gpsPoint identity, remove the old correction toggle and coordinator cache.
- [x] Encode new routes with schema 2; validate schema 1/2 and migrate all legacy points only when explicitly selected.
- [x] Verify map layers/search/USB payloads and migration round trips in native tests.
- [x] Run scripts/run-tests.sh with bundled Python; build-native.sh; reviewer audit.
- [x] Package version 0.1.2, inspect public landmark coordinates in the native UI, update instructions and ZIPs.
