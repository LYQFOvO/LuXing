# Satellite map implementation plan

> Execute inline using executing-plans; updates are authorized by the user's map change request.

**Goal:** Default to satellite imagery and improve precise waypoint selection.

**Architecture:** Native MapKit layers and existing WGS-84 waypoint model. Focus requests are independent of coordinate changes so repeated clicks recenter correctly. Coordinate editing uses the existing update method with range validation.

**Tech Stack:** SwiftUI, MapKit, direct swiftc build; existing bundled Python worker.

## Constraints

Apple Silicon, macOS 14+. No Python or USB behavior changes. No claims of increased imagery resolution or verified phone accuracy.

- [x] Add a model regression that applies an invalid coordinate and verifies original point and walking route remain unchanged; confirm it fails before fixing validation.
- [x] Add default hybrid, satellite and standard layer selector, flat elevation; update MapKit configuration only when layer changes.
- [x] Add repeated focus request and focus to at most 250 metres, retaining closer views.
- [x] Add WGS-84 coordinate editor, six decimal places, valid ranges and playback lock. Apply through updatePoint and focus request.
- [x] Run existing tests and optimized build. Check satellite imagery, layer switching and coordinate editor in actual app.
- [x] Update manual and verification, package and validate app/source archives.
