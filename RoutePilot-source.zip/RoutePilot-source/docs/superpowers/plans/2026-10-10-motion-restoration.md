# Motion and Restoration Implementation Plan

> **For agentic workers:** Use executing-plans inline, with an independent code review after implementation.

**Goal:** Release developer location sessions on restore and add bounded smooth pace/cadence simulation.
**Architecture:** Worker serializes clear then disconnect. RouteCore evaluates a deterministic smooth speed profile and its analytic integral; AppModel shares it between playback and GPX export.
**Tech Stack:** SwiftUI, MapKit, RouteCore, Python/pymobiledevice3.

## Global Constraints
- macOS14+, Apple Silicon, iOS17.4+ existing USB workflow.
- Actual device GPS reception is unverified; there is no pedometer injection API.
- Retain the exact GPS selections and existing schema1 migration choice.

## Task 1: Restore lifecycle
- [x] Write worker regression: after clear, calls end with clear+disconnect and next set fails until reconnect; error during close is reported.
- [x] Run Python tests and observe expected failure for the missing disconnect.
- [x] Close session in worker clear; preserve simulated obligation on clear failure; report session_closed and verified false.
- [x] Update AppModel stop to mark disconnected only after session closure, expose a force restore method that can connect first, and preserve retry after successful sends.
- [x] Test native stop and retry with a delayed transport peer, ensuring no late set requests after clear.

## Task 2: Motion profile
Files: Sources/RouteCore/MotionProfile.swift, Tests/CoreTests.swift.
- [x] Test a disabled profile stays constant; enabled pace is bounded, varies, and integrates to exact target distance/time; cadence is bounded and steps are its integral.
- [x] Implement MotionSettings(cadence, humanVariation, paceVariationSeconds, cadenceVariation), MotionSnapshot(distanceMetres, paceMinutes, cadence, steps), MotionProfile(plan,settings,seed).sample(elapsed:).
- [x] Use sin(2πu)^3 per ~30second cycle, signed deterministic amplitudes, analytic integral (2/3-cos(2πu)+cos(2πu)^3/3)/(2π), and bounded speed amplitude.
- [x] Validate finite positive cadence and finite nonnegative ranges; with enabled variation require paceRange < baselinePaceSeconds and cadenceRange < baselineCadence.

## Task 3: UI, storage and export
Files: AppModel.swift, ContentView.swift, Tests/ModelTests.swift.
- [x] Capture profile at playback start, evaluate it from confirmed monotonic elapsed time, preserve profile across pause/reconnect, and use exact distance target at completion.
- [x] Expose baseline cadence, variation switch and ±range numeric inputs. Display current pace, cadence and estimated steps with explicit sensor-data limitation.
- [x] Add optional MotionSettings to schema3 saved routes; accept schema1/2/3 and default older files to fixed cadence/pace. Validate all data before changing state.
- [x] Use the same profile in GPX output, with urn:routepilot:motion:1 cadence/steps extensions and explicit program simulation labels.
- [x] Run full tests, review, build worker and native executable, package0.1.3, inspect native UI and restore reconnect sequence, archive deliverables.
