# USB 速度尖峰修正计划

> 当前会话使用系统排错、TDD 和独立审查；无 Git 仓库，旧文件保存在 work/speed-fix。

**Goal:** 消除请求延迟后追赶导致的坐标速度尖峰，并拆分起点定位与移动。
**Architecture:** 现有单请求播放循环仍串行；确认后重置时钟、单周期推进上限；起点状态受设备和坐标约束。
**Tech Stack:** SwiftUI/RouteCore、现有 Python worker，无依赖变更。

- [x] 给替身连接记录接收/交付单调时间，配置 0.01/2/0.01 秒延迟，复现 6 min/km 下 28.53 km/h 的交付速度；回归失败。
- [x] 修改 AppModel.runLoop 非预览时 elapsed = min(T, confirmedElapsed + min(1, max(0, clock.elapsed(now)-confirmedElapsed)))；每次响应后 freeze(atElapsed:elapsed)，running 时 resume(now)。确认交付速度回归通过。
- [x] 测试 USB 未准备起点不能开始，prepareStartPoint 只发送首点且保留恢复义务；测试准备后首点重复无跳跃、恢复/重连失效。
- [x] 添加 prepareStartPoint、startPointReady 与 canPrepareStartPoint；准备状态锁定路线和参数；UI 显示先定位到起点、核对手机、再开始移动。
- [x] 补暂停/继续、慢连接、长间隔边界与传感器限制说明；执行全部检查、独立审查、构建 0.1.4/build5。
- [x] 验证实际原生界面，用户当前路线直接加载，严格签名及 ZIP 完整性验证。
- [ ] 真机起点准备与运动世界接收：本次未发现连接的 USB iPhone，待真机验证；不能据替身进程检查声称目标软件提示已消失。
