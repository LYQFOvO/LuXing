#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="${ROUTEPILOT_BUILD_DIR:-$PROJECT_ROOT/../../work/rebuild}"
APP_PATH="${1:-$PROJECT_ROOT/../路行 RoutePilot.app}"
mkdir -p "$BUILD_DIR"
if ! command -v uv >/dev/null 2>&1; then
  echo "Source builds require uv: https://docs.astral.sh/uv/" >&2
  exit 1
fi
if [ ! -x "$BUILD_DIR/venv/bin/python" ]; then
  uv venv --python 3.13 "$BUILD_DIR/venv"
fi
UV_NATIVE_TLS=true uv pip install --python "$BUILD_DIR/venv/bin/python" -r "$PROJECT_ROOT/backend/requirements.lock"
bash "$PROJECT_ROOT/scripts/build-native.sh" "$BUILD_DIR/native"
"$BUILD_DIR/venv/bin/python" -m PyInstaller --noconfirm --clean --onedir \
  --name routepilot-worker --distpath "$BUILD_DIR/dist" --workpath "$BUILD_DIR/pyinstaller" \
  --specpath "$BUILD_DIR" --paths "$PROJECT_ROOT/backend" \
  --recursive-copy-metadata pymobiledevice3 \
  --collect-all pymobiledevice3 --collect-all developer_disk_image --collect-all pmd_pytcp \
  --collect-all pmd_net_addr --collect-all pmd_net_proto "$PROJECT_ROOT/backend/worker.py"
bash "$PROJECT_ROOT/scripts/package-app.sh" "$BUILD_DIR/native/RoutePilot" "$BUILD_DIR/dist/routepilot-worker" "$APP_PATH"
