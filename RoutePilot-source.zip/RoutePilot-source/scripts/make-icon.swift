import AppKit

let directory = CommandLine.arguments[1]
for (size, name) in [(16, "icon_16x16"), (32, "icon_16x16@2x"), (32, "icon_32x32"), (64, "icon_32x32@2x"), (128, "icon_128x128"), (256, "icon_128x128@2x"), (256, "icon_256x256"), (512, "icon_256x256@2x"), (512, "icon_512x512"), (1024, "icon_512x512@2x")] {
    let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: size, pixelsHigh: size, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
    bitmap.size = NSSize(width: 1024, height: 1024)
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
    let tile = NSBezierPath(roundedRect: NSRect(x: 70, y: 70, width: 884, height: 884), xRadius: 205, yRadius: 205)
    NSGradient(starting: NSColor(calibratedRed: 0.06, green: 0.65, blue: 0.59, alpha: 1), ending: NSColor(calibratedRed: 0.03, green: 0.34, blue: 0.40, alpha: 1))!.draw(in: tile, angle: -60)
    NSColor.white.withAlphaComponent(0.17).setStroke()
    for x in stride(from: 240, to: 870, by: 170) {
        let grid = NSBezierPath(); grid.move(to: NSPoint(x: x, y: 170)); grid.line(to: NSPoint(x: x, y: 850)); grid.lineWidth = 3; grid.stroke()
    }
    for y in stride(from: 240, to: 870, by: 170) {
        let grid = NSBezierPath(); grid.move(to: NSPoint(x: 170, y: y)); grid.line(to: NSPoint(x: 850, y: y)); grid.lineWidth = 3; grid.stroke()
    }
    let path = NSBezierPath()
    path.move(to: NSPoint(x: 300, y: 300))
    path.curve(to: NSPoint(x: 510, y: 510), controlPoint1: NSPoint(x: 300, y: 560), controlPoint2: NSPoint(x: 510, y: 250))
    path.curve(to: NSPoint(x: 730, y: 730), controlPoint1: NSPoint(x: 510, y: 780), controlPoint2: NSPoint(x: 730, y: 470))
    path.lineWidth = 55; path.lineCapStyle = .round
    NSColor.white.setStroke(); path.stroke()
    NSColor.white.setFill(); NSBezierPath(ovalIn: NSRect(x: 225, y: 225, width: 150, height: 150)).fill()
    NSColor(calibratedRed: 0.93, green: 0.77, blue: 0.31, alpha: 1).setFill()
    NSBezierPath(ovalIn: NSRect(x: 650, y: 650, width: 160, height: 160)).fill()
    NSGraphicsContext.restoreGraphicsState()
    try bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: "\(directory)/\(name).png"))
}
