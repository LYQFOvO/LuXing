#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEST_DIR="${1:-$PROJECT_ROOT/../../work/test-build}"
mkdir -p "$TEST_DIR"
TEST_DIR="$(cd "$TEST_DIR" && pwd)"
ARCH="$(uname -m)"
xcrun swiftc -swift-version 5 -target "$ARCH-apple-macos14.0" -parse-as-library \
  -emit-library -static -emit-module -module-name RouteCore \
  "$PROJECT_ROOT"/Sources/RouteCore/*.swift -o "$TEST_DIR/libRouteCore.a" \
  -emit-module-path "$TEST_DIR/RouteCore.swiftmodule"
xcrun swiftc -swift-version 5 -target "$ARCH-apple-macos14.0" -parse-as-library \
  -I "$TEST_DIR" -L "$TEST_DIR" -lRouteCore "$PROJECT_ROOT/Tests/CoreTests.swift" -o "$TEST_DIR/core-tests"
"$TEST_DIR/core-tests"
xcrun swiftc -swift-version 5 -target "$ARCH-apple-macos14.0" -parse-as-library \
  -I "$TEST_DIR" -L "$TEST_DIR" -lRouteCore \
  "$PROJECT_ROOT/Sources/RoutePilot/Bridge.swift" "$PROJECT_ROOT/Sources/RoutePilot/AppModel.swift" \
  "$PROJECT_ROOT/Tests/ModelTests.swift" -o "$TEST_DIR/model-tests"
chmod +x "$PROJECT_ROOT/Tests/fake-worker.py"
"$TEST_DIR/model-tests" "$PROJECT_ROOT/Tests/fake-worker.py" "$TEST_DIR/model-events.jsonl"
"${ROUTEPILOT_PYTHON:-python3}" -m unittest discover -s "$PROJECT_ROOT/backend" -v
