#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="${1:-$PROJECT_ROOT/../../work/native-build}"
mkdir -p "$BUILD_DIR"
ARCH="$(uname -m)"
xcrun swiftc -swift-version 5 -target "$ARCH-apple-macos14.0" -O -parse-as-library \
  -emit-library -static -emit-module -module-name RouteCore \
  "$PROJECT_ROOT"/Sources/RouteCore/*.swift -o "$BUILD_DIR/libRouteCore.a" \
  -emit-module-path "$BUILD_DIR/RouteCore.swiftmodule"
xcrun swiftc -swift-version 5 -target "$ARCH-apple-macos14.0" -O -parse-as-library \
  -I "$BUILD_DIR" -L "$BUILD_DIR" -lRouteCore \
  "$PROJECT_ROOT"/Sources/RoutePilot/*.swift -o "$BUILD_DIR/RoutePilot"
echo "Native build ready: $BUILD_DIR/RoutePilot"
