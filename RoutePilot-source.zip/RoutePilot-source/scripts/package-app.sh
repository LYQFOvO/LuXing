#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NATIVE_BINARY="$1"
WORKER_DIR="$2"
APP_PATH="$3"
mkdir -p "$APP_PATH/Contents/MacOS" "$APP_PATH/Contents/Resources"
cp "$NATIVE_BINARY" "$APP_PATH/Contents/MacOS/RoutePilot"
ditto "$WORKER_DIR" "$APP_PATH/Contents/Resources/worker"
cp "$PROJECT_ROOT/Info.plist" "$APP_PATH/Contents/Info.plist"
cp "$PROJECT_ROOT/使用说明.md" "$APP_PATH/Contents/Resources/使用说明.md"
cp "$PROJECT_ROOT/LICENSE" "$APP_PATH/Contents/Resources/LICENSE"
if [ -d "$PROJECT_ROOT/third-party" ]; then
  ditto "$PROJECT_ROOT/third-party" "$APP_PATH/Contents/Resources/third-party"
fi
ICON_DIR="$(dirname "$NATIVE_BINARY")/RoutePilot.iconset"
mkdir -p "$ICON_DIR"
xcrun swift "$PROJECT_ROOT/scripts/make-icon.swift" "$ICON_DIR"
iconutil -c icns "$ICON_DIR" -o "$APP_PATH/Contents/Resources/RoutePilot.icns"
codesign --force --deep --sign - "$APP_PATH"
codesign --verify --deep --strict "$APP_PATH"
echo "App ready: $APP_PATH"
